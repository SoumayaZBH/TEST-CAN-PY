# Tests de validation ECO multi-bus (FIBEX)

Ce projet execute des tests de validation du mode ECO via un FIBEX et des signaux repartis sur CAN, LIN et FlexRay.
Un emulateur est fourni pour valider le flux en local sans materiel.

## Prerequis
- Windows 11
- Python 3.10+ (recommande 3.11+)
- Vector XL Driver pour CAN (pour un vrai materiel CAN)
- Un FIBEX valide contenant vos trames et signaux CAN/LIN/FlexRay

## Installation
1. Installer les dependances Python:
   ```powershell
   python -m pip install -r requirements.txt
   ```
2. Un FIBEX d exemple fonctionnel est inclus: `fibex/example_vehicle.xml`.
   - Regenerer: `python tools/generate_example_fibex.py`
3. Modifier `config/testbench.yaml`:
   - `fibex.path`: chemin absolu ou relatif vers votre FIBEX.
   - `fibex.clusters`: mappe chaque bus logique vers le cluster FIBEX.
   - `buses`: configurer chaque adaptateur (CAN, LIN, FlexRay, UDP).
   - `signals`: mapper les noms logiques vers `bus`, `frame`, `signal`.

## Lancer les tests
Depuis `eco_mode-tests2/`:
```powershell
python run_tests.py
```
Activer les logs debug:
```powershell
python run_tests.py --debug
```
Si vous lancez pytest directement, utiliser `--eco-debug` ou `ECO_MODE_DEBUG=1`.
Les logs console ne s affichent que si un terminal interactif est detecte.

## Emulateur local (sans materiel)
1. Lancer l emulateur:
   ```powershell
   python emulator/run_emulator.py --config config/emulator.yaml
   ```
   Ajouter `--debug` pour des logs detailles.
   Les signaux recus sont journalises lorsque leur valeur change.
2. Dans un autre terminal, lancer les tests:
   ```powershell
   python run_tests.py --config config/testbench.yaml
   ```
La config emulateur utilise des ports UDP inverses par rapport a `config/testbench.yaml`.

Les rapports sont generes dans `reports/`:
- `reports/report.html`
- `reports/junit.xml`
- `reports/debug.log` (uniquement si `--debug` est actif)

## Notes
- Les configs par defaut utilisent l adaptateur UDP pour dialoguer avec l emulateur.
- Pour un vrai materiel, passer `buses.*.kind` a `can`, `lin` ou `flexray` et renseigner les parametres.
- Tous les mappings de signaux sont centralises dans `config/testbench.yaml`.
- Le code est extensible via l enregistrement d adaptateurs (voir documentation).

## Tests sur materiel reel
Un guide detaille est disponible dans `DOCUMENTATION_TECHNIQUE.md` (section "Tests sur materiel reel (hardware)").
