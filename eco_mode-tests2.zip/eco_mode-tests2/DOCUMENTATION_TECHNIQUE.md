﻿# Documentation technique - eco_mode-tests2

Ce document explique l architecture, les fichiers, et les points de configuration du projet **eco_mode-tests2**.

## Objectif
- Tester l activation du mode ECO en s appuyant sur un fichier **FIBEX**.
- Utiliser des signaux repartis sur plusieurs bus (CAN, LIN, FlexRay).
- Garder un code extensible (ouvert a l extension, ferme a la modification).

## Comment personnaliser
1. **FIBEX**
   - Exemple complet fourni: `fibex/example_vehicle.xml`.
   - Regenerer l exemple: `python tools/generate_example_fibex.py`.
   - Pour un vrai vehicule: remplacer par votre fichier FIBEX reel.
   - Mettre a jour `config/testbench.yaml` > `fibex.path`.
   - Si plusieurs clusters existent, renseigner `fibex.clusters` (bus -> nom de cluster FIBEX).

2. **Bus**
   - Dans `config/testbench.yaml` > `buses`, definir chaque bus:
     - `kind`: `can`, `lin`, `flexray`, `udp` (ou un type personnalise si vous ajoutez un adaptateur).
     - Parametres propres au bus (interface, channel, bitrate, etc.).

3. **Signaux**
   - Tous les signaux sont definis dans `config/testbench.yaml` > `signals`.
   - Chaque signal est mappe vers `bus`, `frame`, `signal`.
   - Si vous changez un signal ou un message, modifiez uniquement cette section.

4. **Debogage**
   - Lancer les tests avec `--debug` pour activer les logs detailes.
   - Les logs sont ecrits dans `reports/debug.log`.
   - Si vous lancez pytest directement, utiliser `--eco-debug` ou `ECO_MODE_DEBUG=1`.
   - Les logs console apparaissent uniquement en terminal interactif.

5. **Emulateur**
   - Lancer `python emulator/run_emulator.py --config config/emulator.yaml`.
   - Les ports UDP sont inverses entre `config/testbench.yaml` et `config/emulator.yaml`.
   - Les seuils et codes de rejet sont configurables dans `emulator:` du YAML.
   - Les codes de rejet sont des entiers (ex: 1,2,9...) utilises par les tests.
   - Les logs sont ecrits dans `reports/run.log` ou `reports/debug.log` si `--debug` est actif.
   - Les signaux recus sont journalises a chaque changement de valeur.

## Tests sur materiel reel (hardware)
Cette section explique comment utiliser le projet avec une carte/ECU reelle au lieu de l emulateur UDP.

### Materiel requis (exemples)
- Alimentation et faisceau de banc pour la carte/ECU.
- Acces aux bus requis par le FIBEX (CAN, LIN, FlexRay).
- Interface(s) bus compatibles avec les drivers locaux.
  - CAN: interface USB/PCIe (Vector XL Driver, Kvaser, PEAK, etc.).
  - LIN: interface avec fonction master + transceiver LIN.
  - FlexRay: interface FlexRay + transceiver.
- Outils d observation (optionnel mais conseille): CANalyzer/CANoe, oscilloscope.

Exemples Vector (a titre indicatif, selon votre parc):
- Interfaces CAN/LIN compatibles XL Driver (familles VN16xx / VN1630/1640, CANcaseXL).
- Interfaces FlexRay Vector (familles VN34xx / VN36xx).

### Changements de configuration (config/testbench.yaml)
1. Dupliquer la config emulateur pour conserver une base:
   - `config/testbench.yaml` -> `config/testbench_hardware.yaml`
2. Mettre votre FIBEX reel:
   - `fibex.path`: chemin vers votre FIBEX.
   - `fibex.clusters`: mapper chaque bus logique vers le nom de cluster FIBEX.
3. Remplacer les bus UDP par des bus reels:
   - `buses.*.kind`: `can`, `lin`, `flexray`
   - Pour CAN, renseigner au minimum `interface`, `channel`, `bitrate` (selon python-can).
4. Adapter le mapping des signaux:
   - `signals.*.frame` et `signals.*.signal` doivent correspondre aux noms du FIBEX reel.
5. Ajuster les timings si necessaire:
   - `timing_ms` peut devoir etre augmente selon la latence materielle.

Exemple CAN (Vector via python-can):
```yaml
buses:
  can_main:
    kind: can
    interface: vector
    channel: 0
    bitrate: 500000
    app_name: eco_mode_tests2
```

### Notes importantes pour LIN/FlexRay
- Les adaptateurs `lin` et `flexray` fournis sont des boucles locales (virtuel).
- Pour des tests materiels, implementer un adaptateur reel:
  - Creer un adaptateur qui herite de `BusAdapter` et s enregistre via `register_bus_adapter`.
  - Remplacer `src/netio/lin_adapter.py` et `src/netio/flexray_adapter.py` ou ajouter de nouveaux modules.
- Un adaptateur `lin_vector` est fourni comme facade:
  - Utiliser `kind: lin_vector` et definir `backend: module.Classe` dans le YAML.
  - Le backend doit heriter de `BusAdapter` (ex: wrapper Vector XL LIN).
- Une fois l adaptateur disponible, utiliser le bon `kind` dans le YAML (`lin`, `lin_vector`, `flexray`).

### Procedure type sur banc
1. Brancher la carte/ECU, alimenter, et verifier les terminaisons (ex: 120 ohms en CAN).
2. Verifier le trafic avec l outil constructeur (ex: CANalyzer/CANoe) et valider les IDs/signaux.
3. Lancer les tests:
   ```powershell
   python run_tests.py --config config/testbench_hardware.yaml --debug
   ```

## Architecture (vue d ensemble)
- **Adaptateurs de bus**: couche d abstraction pour CAN, LIN, FlexRay.
- **Codec FIBEX**: encode et decode les trames en se basant sur le FIBEX.
- **SignalIO**: envoi/lecture de signaux multi-bus avec cache des dernieres valeurs.
- **VcuDriveModeApi**: orchestration des preconditions, requete ECO, attente de resultat.
- **Tests**: scenarios d acceptation et de rejet bases sur les preconditions.

## Extension (ouvert/ferme)
- Pour ajouter un nouveau bus ou un driver special, creer un nouvel adaptateur qui herite de `BusAdapter`, puis l enregistrer via `register_bus_adapter`.
- Les tests et le reste du code restent inchanges: seul l adaptateur est ajoute.
- Les signaux et trames sont mappes dans le YAML, donc aucun nom proprietaire n est code en dur.

## Fichiers importants (fichier par fichier)

### eco_mode-tests2/README.md
- **But**: instructions d installation et d execution.
- **A personnaliser**: chemins, dependances, et notes sur les adaptateurs.

### eco_mode-tests2/requirements.txt
- **But**: dependances Python.
- **Contenu**: pytest, python-can, canmatrix, pyyaml, lxml, etc.

### eco_mode-tests2/run_tests.py
- **`main()`**:
  - Cree le dossier `reports/`.
  - Passe `ECO_MODE_CONFIG` et `ECO_MODE_DEBUG` a pytest.
  - Lance pytest avec rapports HTML/JUnit.
  - Si `--debug` est actif, active les logs CLI.

### eco_mode-tests2/config/testbench.yaml
- **`fibex`**: chemin FIBEX + mapping de clusters.
- **`buses`**: definition des adaptateurs.
  - Pour `udp`: `local_addr`, `local_port`, `remote_addr`, `remote_port`.
- **`signals`**: mapping logique -> (bus, frame, signal).
- **`timing_ms`**: timings utilises par l API VCU.

### eco_mode-tests2/config/emulator.yaml
- **But**: configuration de l emulateur (ports inverses).
- **`emulator`**: seuils et codes de rejet.

### eco_mode-tests2/fibex/example_vehicle.xml
- **But**: FIBEX complet et fonctionnel pour l emulateur.
- **Genere par**: `tools/generate_example_fibex.py`.
- **Note**: les trames exposees par canmatrix sont nommees `PDU_*`.

### eco_mode-tests2/tools/generate_example_fibex.py
- **But**: generer un FIBEX de test coherent avec les signaux utilises.

### eco_mode-tests2/src/netio/bus.py
- **`RawFrame`**: structure minimale d une trame.
- **`BusSpec`**: configuration normalisee d un bus.
- **`BusAdapter`**: interface abstraite (send/recv/shutdown).
- **`VirtualBusAdapter`**: boucle locale pour tests hors-ligne.
- **`register_bus_adapter()`**: enregistre un adaptateur.
- **`build_bus_adapters()`**: instancie les adaptateurs depuis le YAML.

### eco_mode-tests2/src/netio/can_adapter.py
- **`CanAdapter`**:
  - Ouvre un bus CAN via python-can.
  - Envoie/recoit des trames CAN.

### eco_mode-tests2/src/netio/lin_adapter.py
- **`LinAdapter`**:
  - Loopback en memoire.
  - A remplacer par un adaptateur LIN reel si besoin.

### eco_mode-tests2/src/netio/flexray_adapter.py
- **`FlexRayAdapter`**:
  - Loopback en memoire.
  - A remplacer par un adaptateur FlexRay reel si besoin.

### eco_mode-tests2/src/netio/udp_adapter.py
- **`UdpAdapter`**:
  - Transport UDP simple pour tests locaux et emulateur.

### eco_mode-tests2/emulator/run_emulator.py
- **But**: application qui recoit les signaux de test et renvoie l etat ECO.

### eco_mode-tests2/src/netio/fibex_codec.py
- **`FibexCodec`**:
  - Charge le FIBEX.
  - Encode les signaux en bytes.
  - Decode les trames en signaux.
- **`_resolve_cluster()`**:
  - Associe un bus logique a un cluster FIBEX.

### eco_mode-tests2/src/netio/signal_io.py
- **`SignalRef`**: reference (bus, frame, signal).
- **`SignalIO`**:
  - `set_signals()` envoie des signaux.
  - `pump()` lit les trames et met a jour le cache.
  - `get_signal()` lit la derniere valeur connue.

### eco_mode-tests2/src/netio/vcu_api.py
- **`TimingCfg`**: regroupe les timings.
- **`VcuDriveModeApi`**:
  - `apply_preconditions()` applique les preconditions.
  - `request_eco()` envoie la demande ECO.
  - `wait_for_eco_result()` attend acceptation/rejet.

### eco_mode-tests2/src/tests/conftest.py
- Charge et valide la config.
- Cree les fixtures pytest (bus, codec, sigmap, vcu).
- Active les logs via `configure_logging()` si le mode debug est actif.

### eco_mode-tests2/src/tests/test_eco_mode_acceptance.py
- Test nominal d activation ECO avec signaux multi-bus.

### eco_mode-tests2/src/tests/test_eco_mode_rejection.py
- Cas de rejet (un signal invalide a la fois).

## Conseils de maintenance
- Si un nouveau signal est ajoute, modifier uniquement `config/testbench.yaml`.
- Si un nouveau bus est ajoute, implementer un adaptateur et enregistrer le type.
- Garder les noms logiques des signaux stables pour eviter de toucher aux tests.

