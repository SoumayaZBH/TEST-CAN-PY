"""Adaptateur CAN base sur python-can."""

from __future__ import annotations

import logging
from typing import Optional

import can

from .bus import BusAdapter, BusSpec, RawFrame, register_bus_adapter

logger = logging.getLogger(__name__)


class CanAdapter(BusAdapter):
    """Adaptateur qui encapsule python-can pour le trafic CAN."""

    def __init__(self, spec: BusSpec) -> None:
        """Ouvrir un bus python-can avec les parametres fournis."""

        super().__init__(spec)
        self._bus = can.Bus(
            interface=spec.params.get("interface"),
            channel=spec.params.get("channel"),
            bitrate=spec.params.get("bitrate"),
            app_name=spec.params.get("app_name"),
        )
        logger.info("Adaptateur CAN pret sur le canal %s", spec.params.get("channel"))

    def send(self, frame: RawFrame) -> None:
        """Envoyer une trame CAN."""

        message = can.Message(
            arbitration_id=frame.frame_id,
            data=frame.data,
            is_extended_id=frame.is_extended_id,
        )
        self._bus.send(message)
        logger.debug("Envoi CAN: id=0x%X", frame.frame_id)

    def recv(self, timeout: Optional[float] = None) -> Optional[RawFrame]:
        """Recevoir une trame CAN et la convertir en RawFrame."""

        msg = self._bus.recv(timeout)
        if msg is None:
            return None
        return RawFrame(
            bus=self.name,
            frame_id=msg.arbitration_id,
            data=bytes(msg.data),
            is_extended_id=bool(msg.is_extended_id),
            timestamp=msg.timestamp,
        )

    def shutdown(self) -> None:
        """Arreter l interface CAN."""

        self._bus.shutdown()
        logger.info("Arret adaptateur CAN")


register_bus_adapter("can", CanAdapter)
