"""Aides d encodage/decodage basees sur FIBEX."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple, Union
import logging

import canmatrix.formats

from .bus import RawFrame

SignalValue = Union[int, float, bool]

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class FrameRef:
    """Metadonnees de trame FIBEX resolues pour encodage/decodage rapide."""

    name: str
    frame_id: int
    is_extended_id: bool
    frame: object


class FibexCodec:
    """Encoder et decoder des trames a partir d une base FIBEX."""

    def __init__(self, fibex_path: Path, bus_clusters: Optional[Dict[str, str]] = None) -> None:
        """Charger un FIBEX et preparer les index par bus."""

        fibex_path = Path(fibex_path)
        if not fibex_path.is_file():
            raise FileNotFoundError(f"Fichier FIBEX introuvable: {fibex_path}")
        self._dbs = canmatrix.formats.loadp(str(fibex_path), import_type="fibex")
        if not self._dbs:
            raise ValueError("Chargement FIBEX echoue ou aucun cluster retourne")
        self._bus_clusters = bus_clusters or {}
        self._frames_by_name: Dict[str, Dict[str, FrameRef]] = {}
        self._frames_by_id: Dict[str, Dict[int, FrameRef]] = {}

    def encode(self, bus: str, frame_name: str, signal_values: Dict[str, SignalValue]) -> RawFrame:
        """Encoder des signaux dans une trame brute pour le bus donne."""

        frame_ref = self._get_frame_by_name(bus, frame_name)
        data = frame_ref.frame.encode(signal_values)
        return RawFrame(
            bus=bus,
            frame_id=frame_ref.frame_id,
            data=data,
            is_extended_id=frame_ref.is_extended_id,
        )

    def decode(self, frame: RawFrame) -> Optional[Tuple[str, Dict[str, SignalValue]]]:
        """Decoder une trame brute en nom de trame et dictionnaire de signaux."""

        frame_ref = self._get_frame_by_id(frame.bus, frame.frame_id)
        if frame_ref is None:
            return None
        decoded = frame_ref.frame.decode(frame.data)
        signals: Dict[str, SignalValue] = {}
        for name, value in decoded.items():
            if hasattr(value, "phys_value"):
                signals[name] = value.phys_value
            elif hasattr(value, "raw_value"):
                signals[name] = value.raw_value
            else:
                signals[name] = value
        return frame_ref.name, signals

    def _get_frame_by_name(self, bus: str, frame_name: str) -> FrameRef:
        """Retourner un FrameRef en cache pour le bus indique."""

        if bus not in self._frames_by_name:
            self._prime_bus_cache(bus)
        try:
            return self._frames_by_name[bus][frame_name]
        except KeyError as exc:
            raise KeyError(f"Trame '{frame_name}' introuvable sur le bus '{bus}'") from exc

    def _get_frame_by_id(self, bus: str, frame_id: int) -> Optional[FrameRef]:
        """Retourner un FrameRef en cache par identifiant numerique."""

        if bus not in self._frames_by_id:
            self._prime_bus_cache(bus)
        return self._frames_by_id[bus].get(frame_id)

    def _prime_bus_cache(self, bus: str) -> None:
        """Construire les index nom/id pour un bus selon le cluster."""

        cluster = self._resolve_cluster(bus)
        matrix = self._dbs[cluster]
        by_name: Dict[str, FrameRef] = {}
        by_id: Dict[int, FrameRef] = {}
        for name, frame in matrix.frames_dict_name.items():
            frame_id, is_extended = _frame_identifier(frame)
            ref = FrameRef(name=name, frame_id=frame_id, is_extended_id=is_extended, frame=frame)
            by_name[name] = ref
            by_id[frame_id] = ref
        self._frames_by_name[bus] = by_name
        self._frames_by_id[bus] = by_id
        logger.info("Cache FIBEX pret pour le bus '%s' (cluster '%s')", bus, cluster)

    def _resolve_cluster(self, bus: str) -> str:
        """Resoudre le nom du cluster FIBEX pour un bus logique."""

        if bus in self._bus_clusters:
            cluster = self._bus_clusters[bus]
            if cluster not in self._dbs:
                raise KeyError(f"Cluster '{cluster}' introuvable dans le FIBEX")
            return cluster
        if len(self._dbs) == 1:
            return next(iter(self._dbs.keys()))
        raise KeyError(
            "Plusieurs clusters trouves dans le FIBEX. "
            "Ajouter fibex.clusters.<bus> dans config/testbench.yaml."
        )


def _frame_identifier(frame: object) -> Tuple[int, bool]:
    """Extraire l identifiant numerique et le flag extended d une trame canmatrix."""

    arb = getattr(frame, "arbitration_id", None)
    if arb is not None and getattr(arb, "id", None):
        return int(arb.id), bool(getattr(arb, "extended", False))
    header_id = getattr(frame, "header_id", None)
    if header_id is not None:
        return int(header_id), False
    raise ValueError("La trame n a ni arbitration_id ni header_id")
