"""Emulateur VCU local pour eco_mode-tests2 (UDP ou bus reels)."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys
import time
from typing import Dict, Optional

import yaml
import logging

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from netio import FibexCodec, SignalIO, SignalRef, build_bus_adapters, configure_logging

logger = logging.getLogger(__name__)


def _load_config(config_path: Path) -> dict:
    """Charger la config YAML et resoudre les chemins relatifs."""

    if not config_path.is_absolute():
        config_path = ROOT / config_path
    if not config_path.is_file():
        raise FileNotFoundError(f"Fichier de config introuvable: {config_path}")
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    if not isinstance(cfg, dict):
        raise ValueError("La racine de config doit etre un mapping")
    fibex_cfg = cfg.get("fibex", {})
    fibex_path = Path(fibex_cfg.get("path", ""))
    if not fibex_path.is_absolute():
        fibex_path = ROOT / fibex_path
    fibex_cfg["path"] = str(fibex_path)
    cfg["fibex"] = fibex_cfg
    return cfg


def _build_sigmap(signals_cfg: dict) -> Dict[str, SignalRef]:
    """Construire le mapping logique des signaux."""

    sigmap: Dict[str, SignalRef] = {}
    for name, entry in signals_cfg.items():
        sigmap[name] = SignalRef(bus=entry["bus"], frame=entry["frame"], signal=entry["signal"])
    return sigmap


def _get_signal(sio: SignalIO, sigmap: Dict[str, SignalRef], name: str) -> Optional[float]:
    """Lire un signal du cache par nom logique."""

    ref = sigmap.get(name)
    if ref is None:
        return None
    return sio.get_signal(ref)


def _log_received_signals(
    sio: SignalIO,
    sigmap: Dict[str, SignalRef],
    last_values: Dict[str, float],
) -> None:
    """Logger les signaux recus quand leur valeur change."""

    for name, ref in sigmap.items():
        value = sio.get_signal(ref)
        if value is None:
            continue
        if last_values.get(name) != value:
            last_values[name] = value
            logger.info(
                "Signal recu %s (%s/%s/%s) = %s",
                name,
                ref.bus,
                ref.frame,
                ref.signal,
                value,
            )


def _evaluate_preconditions(sio: SignalIO, sigmap: Dict[str, SignalRef], cfg: dict) -> Optional[int]:
    """Retourner 0 si accepte, code de rejet si refuse, None si incomplet."""

    thresholds = cfg.get("emulator", {}).get("thresholds", {})
    reject_codes = cfg.get("emulator", {}).get("reject_codes", {})

    checks = [
        ("ignition_state", "ignition_state_required", "ignition_state", lambda v, t: v == t),
        ("hv_ready", "hv_ready_required", "hv_ready", lambda v, t: v == t),
        ("vcu_fault_level", "vcu_fault_level_required", "vcu_fault_level", lambda v, t: v == t),
        ("degraded_mode", "degraded_mode_required", "degraded_mode", lambda v, t: v == t),
        ("gear_position", "gear_position_required", "gear_position", lambda v, t: v == t),
        ("vehicle_speed", "vehicle_speed_max", "vehicle_speed", lambda v, t: v <= t),
        ("accel_pedal_pos", "accel_pedal_max", "accel_pedal_pos", lambda v, t: v <= t),
        ("brake_pedal", "brake_pedal_required", "brake_pedal", lambda v, t: v == t),
        ("battery_soc", "battery_soc_min", "battery_soc", lambda v, t: v >= t),
        ("battery_temp", "battery_temp_min", "battery_temp", lambda v, t: v >= t),
        ("battery_temp", "battery_temp_max", "battery_temp", lambda v, t: v <= t),
    ]

    for logical, threshold_key, reject_key, predicate in checks:
        value = _get_signal(sio, sigmap, logical)
        if value is None:
            return None
        threshold = thresholds.get(threshold_key)
        if threshold is None:
            continue
        if not predicate(float(value), float(threshold)):
            return int(reject_codes.get(reject_key, 99))

    return 0


def _send_grouped(sio: SignalIO, sigmap: Dict[str, SignalRef], values: Dict[str, float]) -> None:
    """Regrouper les signaux par bus/trame et les envoyer."""

    grouped: Dict[tuple[str, str], Dict[str, float]] = {}
    for name, value in values.items():
        ref = sigmap.get(name)
        if ref is None:
            continue
        grouped.setdefault((ref.bus, ref.frame), {})[ref.signal] = value
    for (bus, frame), signals in grouped.items():
        sio.set_signals(bus, frame, signals)


def main() -> int:
    parser = argparse.ArgumentParser(description="Emulateur mode ECO")
    parser.add_argument(
        "--config",
        default="config/emulator.yaml",
        help="Chemin vers la config YAML emulateur",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Activer les logs debug",
    )
    parser.add_argument(
        "--tick",
        type=float,
        default=0.05,
        help="Pas de boucle en secondes",
    )
    args = parser.parse_args()

    os.environ["ECO_MODE_DEBUG"] = "1" if args.debug else "0"

    cfg = _load_config(Path(args.config))
    configure_logging(args.debug, ROOT / "reports")

    buses = build_bus_adapters(cfg["buses"])
    codec = FibexCodec(Path(cfg["fibex"]["path"]), bus_clusters=cfg["fibex"].get("clusters"))
    sio = SignalIO(buses, codec)
    sigmap = _build_sigmap(cfg["signals"])
    last_values: Dict[str, float] = {}

    request_active = False

    try:
        while True:
            sio.pump(args.tick)
            _log_received_signals(sio, sigmap, last_values)
            req_valid = _get_signal(sio, sigmap, "driver_mode_req_valid")
            req_mode = _get_signal(sio, sigmap, "driver_mode_request")
            if req_valid == 1 and req_mode == 1:
                if not request_active:
                    decision = _evaluate_preconditions(sio, sigmap, cfg)
                    if decision is None:
                        time.sleep(args.tick)
                        continue
                    accepted = 1 if decision == 0 else 0
                    active_mode = 1 if decision == 0 else 0
                    payload = {
                        "driving_mode_active": active_mode,
                        "drivemode_accepted": accepted,
                    }
                    if decision != 0:
                        payload["drivemode_reject_reason"] = decision
                    _send_grouped(sio, sigmap, payload)
                    logger.info("Decision ECO=%s payload=%s", decision, payload)
                    request_active = True
            else:
                request_active = False
            time.sleep(args.tick)
    except KeyboardInterrupt:
        return 0
    finally:
        for adapter in buses.values():
            adapter.shutdown()


if __name__ == "__main__":
    raise SystemExit(main())
