# Documentation technique - eco-mode-testVN7610

## 1. But
Valider les scenarios ECO en environnement materiel direct sur **Vector VN7610 / FlexRay** avec une pile Python simplifiee autour de `flexray-vector-lib`.

Les fichiers concernes sont :
- `src/tests/test_eco_mode_acceptance.py`
- `src/tests/test_eco_mode_rejection.py`

## 2. Architecture apres modification
Chaine d execution actuelle :
1. `run_tests.py` positionne `ECO_MODE_CONFIG`, `ECO_MODE_DEBUG` et le dossier de rapports.
2. `conftest.py` charge `config/testbench.yaml`.
3. `flexray-vector-lib` est fourni par le wheel `vendor/flexray_vector_lib-0.1.0-py3-none-any.whl`, installe via `requirements.txt`.
4. `src/eco_mode_harness.py` construit :
   - `ConfigurableFlexRayInjector`
   - `ObservableVectorXLBackend`
   - `FlexRayFrameCodec`
   - `EcoModeController`
5. Les tests injectent les preconditions et la requete ECO via `flexray-vector-lib`.
6. Les trames RX sont lues directement depuis Vector XL puis decodees avec le FIBEX.

## 3. Composants ajoutes
### `src/eco_mode_harness.py`
Nouveau point d entree fonctionnel pour les tests ECO.

Responsabilites :
- charger la configuration utile du testbench ;
- reutiliser `flexray-vector-lib` pour l encodage et l emission ;
- appliquer `tx_mode`, `tx_ack` et `channel_mask` du YAML ;
- lire les trames de retour FlexRay depuis le meme backend ;
- decoder les signaux de verdict a partir du FIBEX ;
- exposer une API simple :
  - `apply_preconditions()`
  - `request_eco()`
  - `wait_for_eco_result()`

### `ConfigurableFlexRayInjector`
Sous-classe locale de `FlexRayInjector`.

Role :
- conserver l usage de la librairie externe pour la resolution FIBEX et l encodage des signaux ;
- reinjecter la configuration de transmission issue du testbench :
  - `tx_mode`
  - `tx_ack`
  - `channel_mask`

### `ObservableVectorXLBackend`
Sous-classe locale de `flexray_vector_lib.vector.backend.VectorXLBackend`.

Role :
- partager le meme port Vector XL entre emission et reception ;
- ajouter l appel `xlFrReceive` absent de la librairie externe actuelle ;
- eviter l ouverture de deux ports independants sur le meme canal VN7610.

### `FlexRayFrameCodec`
Decodeur minimal base sur le FIBEX.

Role :
- resoudre les trames par slot FlexRay ;
- decoder les valeurs physiques des signaux recus ;
- rester independant de l ancienne pile locale.

## 4. Fichiers supprimes
Les fichiers Python legacy qui n etaient plus utilises ont ete retires du depot :
- `src/netio/*.py`
- `src/vector_flexray_backend.py`
- `src/vn7610_flexray_backend.py`
- `src/tests/__init__.py`

## 5. Configuration conservee
Le fichier `config/testbench.yaml` est conserve comme fichier central.

Champs desormais consommes par la nouvelle couche directe :
- `fibex.path`
- `fibex.clusters.flexray_pt`
- `buses.flexray_pt.app_name`
- `buses.flexray_pt.channel_index`
- `buses.flexray_pt.app_channel` optionnel
- `buses.flexray_pt.interface_version` optionnel
- `buses.flexray_pt.tx_mode`
- `buses.flexray_pt.tx_ack`
- `buses.flexray_pt.channel_mask`
- `signals.*`
- `timing_ms.*`

Les cles legacy non consommees par le flux direct ont ete retirees du bloc `buses.flexray_pt`.

Le FIBEX d exemple `fibex/example_vehicle.xml` est un exemple strictement FlexRay.

## 6. Details de fonctionnement
### Injection
Pour chaque signal logique demande par le scenario :
1. le mapping logique est lu depuis `signals.*` ;
2. le signal FIBEX est resolu par `flexray-vector-lib` ;
3. la charge utile de la trame est mise a jour ;
4. la trame est transmise sur le slot/cycle du FIBEX.

### Reception
Apres injection :
1. le backend lit les evenements `xlFrReceive` ;
2. seules les trames `XL_FR_RX_FRAME` sont retenues ;
3. le FIBEX est utilise pour resoudre le slot recu ;
4. les signaux decodes sont mis en cache ;
5. `wait_for_eco_result()` surveille :
   - `DrivingModeActive`
   - `DriveModeAccepted`
   - `DriveModeRejectReason`

## 7. Modifications apportees
- creation de `src/eco_mode_harness.py`
- reecriture complete de `conftest.py`
- reecriture des tests `src/tests/test_eco_mode_acceptance.py` et `src/tests/test_eco_mode_rejection.py`
- suppression du package `src/netio/`
- suppression des backends locaux `src/vector_flexray_backend.py` et `src/vn7610_flexray_backend.py`
- ajout du wheel `vendor/flexray_vector_lib-0.1.0-py3-none-any.whl` dans les dependances du projet
- correction du backend Vector XL dans la wheel :
  resolution du vrai `channelMask`, tentative d ouverture en `XL_INTERFACE_VERSION_V4` puis repli `V3`, et demande explicite de permission d initialisation
- suppression du chargement dynamique de la librairie depuis un chemin source
- nettoyage du bloc `buses.flexray_pt` pour ne garder que les parametres utilises
- ajout de `pydantic>=2.7,<3` dans `requirements.txt`
- mise a jour de `README.md`

## 8. Points d attention
- `channel_index` est maintenant obligatoire pour le flux direct ;
- `app_channel` peut etre renseigne si le canal est mappe dans Vector Hardware Config ;
- la reception depend d une extension locale car `flexray-vector-lib` ne gere pas encore le RX ;
- si le XL Driver ne remonte aucun canal FlexRay visible, aucun test materiel ne peut demarrer ;
- les validations de bon fonctionnement sur banc reel restent necessaires pour confirmer le comportement XL Driver, le mapping FIBEX et les timings reseau.

## 9. Procedure de lancement
1. installer les dependances Python ;
2. verifier la presence du wheel dans `vendor/` ;
3. verifier le FIBEX et le cluster cible ;
4. confirmer `channel_index` dans Vector Hardware Config ;
5. lancer :

```powershell
python run_tests.py --config config/testbench.yaml --debug
```

## 10. Diagnostic local XL Driver
Le script `tools/diagnose_vector_xl.py` permet de :
- lire `xlGetDriverConfig`
- lister tous les canaux vus par `vxlapi`
- filtrer les canaux compatibles FlexRay
- sonder `xlGetApplConfig` pour un `app_name`
- proposer quoi mettre dans `channel_index` ou `app_channel`

Commande :

```powershell
python tools/diagnose_vector_xl.py --config config/testbench.yaml
```

Interpretation :
- si `channelCount=0`, le XL Driver ne voit aucun canal Vector ;
- si le boitier est branche au PC mais pas au reseau FlexRay, cela peut laisser `is_on_bus=0` ;
- en revanche, l'absence de reseau ne doit pas faire disparaitre le canal du XL Driver.

## 11. Recuperation best effort
Le script `tools/recover_vector_xl.py` tente les actions systeme accessibles depuis Python :
- lecture des peripheriques `Vector-Hardware` via `pnputil`
- verification de l etat `vxlapi` avant/apres
- `pnputil /scan-devices`
- redemarrage du service `vHardwareService`
- redemarrage du peripherique VN7610

Commande :

```powershell
python tools/recover_vector_xl.py --config config/testbench.yaml
```

Commande avec actions :

```powershell
python tools/recover_vector_xl.py --config config/testbench.yaml --scan-devices --restart-vn7610 --restart-vector-service
```

Point important :
- ce script peut aider a recuperer la detection ;
- il ne peut pas forcer `vxlapi` a publier un canal si le XL Driver reste vide ;
- sur la machine analysee, Windows voit bien `VN7610`, mais `vxlapi` reste a `channelCount=0`.
- le detail des actions de reparation executees le `09/04/2026` est consigne dans `DIAGNOSTIC_INSTALLATION_VECTOR_2026_04_09.md`.

## 12. Mapping applicatif automatique
Le script `tools/map_vector_app.py` sert a ecrire un mapping `app_name` / `app_channel` via `xlSetApplConfig`.

Fonctionnement :
- lit les canaux FlexRay visibles dans `vxlapi`
- choisit un canal cible
- peut ecrire le mapping applicatif
- reverifie ensuite `xlGetApplConfig`
- affiche la configuration YAML recommandee

Commandes :

```powershell
python tools/map_vector_app.py --config config/testbench.yaml
python tools/map_vector_app.py --config config/testbench.yaml --apply
python tools/map_vector_app.py --config config/testbench.yaml --channel-index 7 --app-channel 0 --apply
```

Limite :
- si `vxlapi` ne voit aucun canal FlexRay, `xlSetApplConfig` n'a pas de cible exploitable ;
- dans ce cas, il faut d'abord resoudre la publication du VN7610 dans le XL Driver.
