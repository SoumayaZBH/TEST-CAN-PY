# Documentation technique - eco-mode-testVN7610

## 1. Objectif
Valider l activation/rejet du mode ECO en execution materielle directe, avec:
- interface Vector VN7610,
- transport FlexRay uniquement,
- interpretation signaux via FIBEX.

Le projet conserve l architecture logicielle de `eco_mode-tests2`, mais supprime la dependance emulateur.

## 2. Vue d ensemble technique
Pipeline:
1. `run_tests.py` pose `ECO_MODE_CONFIG` puis lance pytest.
2. `src/tests/conftest.py` charge `config/testbench.yaml`.
3. `build_bus_adapters()` instancie `kind: flexray_vector`.
4. `VectorFlexRayAdapter` charge le backend:
   - `vn7610_flexray_backend.VN7610FlexRayBackend`
5. Le backend dedie specialise le backend XL generique:
   - `vector_flexray_backend.VectorFlexRayBackend`
6. `SignalIO` encode/decode via `FibexCodec`.
7. `VcuDriveModeApi` pilote les scenarios ECO.

## 3. Backend dedie VN7610
Fichier: `src/vn7610_flexray_backend.py`.

Responsabilites:
- imposer `hw_type = XL_HWTYPE_VN7610`,
- fournir defaults stables:
  - `app_name: eco_mode_testVN7610`
  - `app_channel: 0`
  - `channel_mask: A`
  - `tx_mode: cyclic`
- valider les champs obligatoires:
  - `fibex_path`,
  - `cluster` (ou `cluster_name`),
  - selection de canal (`channel_index`/`channel` ou `use_appl_config=true`).

Execution IO:
- TX/RX FlexRay, resolution schedule FIBEX, activation canal et configuration cluster
  sont delegues au backend XL generique (`src/vector_flexray_backend.py`).

## 4. Configuration unique
Fichier: `config/testbench.yaml`.

Caracteristiques:
- un seul bus: `flexray_pt`,
- backend force: `vn7610_flexray_backend.VN7610FlexRayBackend`,
- aucun bloc `emulator`,
- mappings signaux identiques aux tests historiques.

Parametres a personnaliser sur banc reel:
- `fibex.path`,
- `fibex.clusters.flexray_pt`,
- `buses.flexray_pt.fibex_path`,
- `buses.flexray_pt.cluster`,
- `buses.flexray_pt.channel_index`,
- `signals.*` si vos noms FIBEX different.

## 5. Tests
Tests fonctionnels conserves:
- `src/tests/test_eco_mode_acceptance.py`
- `src/tests/test_eco_mode_rejection.py`

Tests backend dedie:
- `src/tests/test_vn7610_flexray_backend.py`

Ces tests unitaires verifient:
- defaults VN7610,
- validation de `hw_type`,
- presence des champs critiques.

## 6. Procedure de mise en route hardware
1. Connecter VN7610 en USB.
2. Ouvrir Vector Hardware Config.
3. Assigner application `eco_mode_testVN7610` / `app_channel 0` au canal FlexRay cible.
4. Relever le `channel_index` global et le renseigner dans `config/testbench.yaml`.
5. Remplacer le FIBEX exemple par votre FIBEX vehicule.
6. Verifier correspondance cluster + frames + signaux.
7. Lancer:
   - `python run_tests.py --config config/testbench.yaml --debug`

## 7. Diagnostic rapide
Symptomes frequents:
- `xlOpenPort` erreur:
  - driver XL non installe, app_name/channel non mappes, canal deja reserve.
- `Aucun cluster FlexRay detecte`:
  - FIBEX invalide ou mauvais nom de cluster.
- timeout ECO:
  - trames non recues, mauvais schedule slot/cycle, mapping signaux incoherent.

Actions recommandees:
- verifier trafic dans CANoe/CANalyzer,
- confirmer `channel_index`,
- confirmer noms `frame/signal` exacts du FIBEX.

## 8. Fichiers cle
- `run_tests.py`: bootstrap execution pytest + rapports.
- `config/testbench.yaml`: configuration unique hardware.
- `src/vn7610_flexray_backend.py`: backend specifique VN7610.
- `src/vector_flexray_backend.py`: implementation XL generique.
- `src/netio/flexray_vector_adapter.py`: facade adaptateur.
- `src/netio/fibex_codec.py`: codec FIBEX.
- `src/netio/signal_io.py`: IO signaux.
- `src/netio/vcu_api.py`: API metier ECO.
