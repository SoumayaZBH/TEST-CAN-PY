# Documentation technique - eco-mode-testVN7610

## 1. Objectif
Valider le mode ECO:
- sur banc reel via VN7610 FlexRay,
- et hors hardware via un emulator GUI UDP,
en conservant l'architecture logicielle `netio`.

## 2. Chaine technique retenue
1. `run_tests.py` lance pytest et charge `config/testbench.yaml`.
2. `build_bus_adapters()` cree l'adaptateur `kind: flexray_vector`.
3. `netio/flexray_vector_adapter.py` charge le backend `flexrayInjector.FlexRayInjectorBackend`.
4. `flexrayInjector.py`:
   - initialise le driver XL (`vector_xl.py`),
   - configure le noeud A avec les infos du FIBEX,
   - active le channel,
   - envoie en respectant la condition de cycle:
     - `(cycle_index - base_cycle) % repetition == 0`.
5. `netio/fibex_codec.py` encode/decode les signaux:
   - parsing FIBEX par `fibex_parser.py`,
   - bit-packing et conversion physique/brut par `signal_codec.py`.
6. `VcuDriveModeApi` pilote les scenarios ECO (acceptation/rejet).

## 3. Modules principaux

### 3.1 `src/vector_xl.py`
- Wrapper `ctypes` sur `vxlapi64.dll`.
- API utilisees:
  - `xlOpenDriver` / `xlCloseDriver`
  - `xlOpenPort` / `xlClosePort`
  - `xlActivateChannel` / `xlDeactivateChannel`
  - `xlFrSetConfiguration`
  - `xlFrSetMode`
  - `xlFrTransmit` / `xlFrReceive`

### 3.2 `src/fibex_parser.py`
- Parse FIBEX avec `ElementTree`.
- Extrait:
  - cluster FlexRay (cycle, static slots),
  - frame triggering (slot/base-cycle/repetition),
  - signaux (bit position, taille, factor, offset, signed).

### 3.3 `src/signal_codec.py`
- Encodage/decodage little-endian bit-level.
- Conversion:
  - `raw = (physical - offset) / factor`
  - `physical = raw * factor + offset`

### 3.4 `src/flexrayInjector.py`
- Backend `BusAdapter` concret.
- Configure le noeud A (`fr_get_channel_configuration` + `fr_set_configuration`).
- Calcule le cycle via `time.perf_counter()`.
- Envoi conditionnel conforme au scheduling FIBEX.

## 4. FIBEX fourni
Fichier: `fibex/fibex.xml`.

Contenu:
- Cluster: `cluster_flexray_pt`
- Reseaux/channels: `FR_CHANNEL_A`, `FR_CHANNEL_B`
- Frames utilises par les tests:
  - `PDU_HMI_Request`
  - `PDU_Body_Status`
  - `PDU_Chassis_Status`
  - `PDU_Powertrain_Status`
  - `PDU_VCU_Status`
  - `PDU_Trans_Status`
  - `PDU_Battery_Status`
  - `PDU_VCU_Mode`
- Signaux alignes avec `config/testbench.yaml`.

## 5. Configuration de test
Fichier: `config/testbench.yaml`.

Points critiques:
- `backend: flexrayInjector.FlexRayInjectorBackend`
- `fibex.path: fibex/fibex.xml`
- `fibex.clusters.flexray_pt: cluster_flexray_pt`
- `buses.flexray_pt.cluster: cluster_flexray_pt`
- mapping `signals.*` aligne sur les noms FIBEX.

## 6. Tests

### 6.1 Tests unitaires hors hardware
- `src/tests/test_signal_codec.py`
- `src/tests/test_fibex_parser.py`
- `src/tests/test_fibex_codec.py`
- `src/tests/test_flexray_injector_schedule.py`
- `src/tests/test_emulator_logic.py`

### 6.2 Tests ECO sur banc
- `src/tests/test_eco_mode_acceptance.py`
- `src/tests/test_eco_mode_rejection.py`

Ces tests necessitent un reseau FlexRay actif et une ECU/stack repondant sur le reseau.

## 7. Nettoyage realise
Fichiers retires car obsoletes dans cette architecture:
- `src/vector_flexray_backend.py`
- `src/vn7610_flexray_backend.py`
- `src/flexray_fibex.py`
- anciens tests unitaires associes
- anciens FIBEX examples et documentation non alignes

## 8. Mode emulator (sans carte)
Fichiers:
- `emulator/gui_emulator.py`
- `emulator/eco_mode_logic.py`
- `config/testbench_emulator.yaml`

Usage:
1. Lancer l interface GUI:
   - `python emulator/gui_emulator.py --fibex fibex/fibex.xml --cluster cluster_flexray_pt`
2. Lancer les tests avec la config UDP:
   - `python run_tests.py --config config/testbench_emulator.yaml --debug`

Fonctions du GUI:
- interception et affichage du flux sortant des tests,
- injection manuelle de trames/signaux,
- reponse automatique ECO (`PDU_VCU_Mode`) selon les preconditions observees.

## 9. Procedure de demarrage rapide (hardware)
1. Configurer `eco_mode_testVN7610` dans Vector Hardware Config.
2. Verifier le mapping app/channel vers le port VN7610.
3. Ajuster `config/testbench.yaml` si necessaire.
4. Lancer:
   - `python run_tests.py --config config/testbench.yaml --debug`
