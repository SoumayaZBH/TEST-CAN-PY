## Diagnostic installation Vector du 09/04/2026

### Objet

Corriger la detection du `VN7610` par `vxlapi` afin de permettre l'execution des tests ECO en FlexRay.

### Etat initial

- `python tools/diagnose_vector_xl.py --config config/testbench.yaml`
  - `channelCount: 0`
  - aucun canal FlexRay visible
  - tous les `xlGetApplConfig(app_channel=0..7)` retournaient `XL_ERROR`
- `Vector Hardware Manager` arrivait jusqu'au deploiement, puis journalisait:
  - `xlSetApplConfig returned: [ErrorCode: 255] Error`
- `Vector Hardware Service` journalisait:
  - `Failed opening registry key 'HKEY_LOCAL_MACHINE\SOFTWARE\VECTOR\CANDriver 1.0\Drivers'`

### Actions executees

#### 1. Verification de l'installation Windows

- verification du peripherique `VN7610`
- verification du `Vector Network Enumerator`
- verification du service `vHardwareService`
- verification de la presence de `vxlapi64.dll`
- verification des produits installes:
  - `Vector XL Driver Library 25.20.14.0`
  - `Vector Hardware Manager 26.10.14`

#### 2. Reparation elevee du XL Driver

Commande lancee:

```powershell
msiexec /fvomus "C:\Users\hamdi\AppData\Local\Downloaded Installations\{7BA5DA74-6739-4F6D-995B-E5B68A7BC0CC}\Vector XL Driver Library.msi" /L*V "C:\Users\hamdi\Desktop\DOSSIER_TEST\eco-mode-testVN7610\reports\msiexec_xl_repair_elevated.log"
```

Resultat:

- reconfiguration MSI terminee avec succes
- le journal MSI confirme:
  - `Product: Vector XL Driver Library -- Configuration completed successfully.`
  - `etat d'erreur : 0`

#### 3. Reinitialisation post-install

Actions executees en eleve:

- redemarrage du service `vHardwareService`
- redemarrage du peripherique:
  - `USB\VID_1248&PID_1300\5&192363c3&0&1`
- redemarrage du peripherique:
  - `ROOT\VECTORSYSTEMSERVICES\0006`
- `pnputil /scan-devices`

Trace:

- `reports/vector_admin_recovery_transcript.log`

### Resultat apres intervention

Le probleme persiste apres reparation et reinitialisation:

- `python tools/diagnose_vector_xl.py --config config/testbench.yaml`
  - `channelCount: 0`
  - aucun canal FlexRay visible
  - aucun mapping applicatif valide

- `python tools/map_vector_app.py --config config/testbench.yaml --apply`
  - impossible d'appliquer un mapping
  - raison: aucun canal FlexRay visible dans `vxlapi`

### Conclusion technique

La reparation logicielle locale a bien ete executee, mais elle n'a pas restaure l'exposition du `VN7610` dans `vxlapi`.

Le blocage restant n'est plus dans:

- le code du projet ECO
- le FIBEX
- la wheel `flexray_vector_lib`
- la logique de mapping applicatif

Le blocage restant est au niveau de l'environnement Vector/Windows:

- `vxlapi` ne publie toujours aucun canal
- le registre `HKLM\SOFTWARE\VECTOR\CANDriver 1.0` reste absent apres reconfiguration
- l'outil Vector ne peut donc pas materialiser le canal FlexRay attendu

### Action minimale encore requise

La prochaine action recommande est un redemarrage complet de Windows, puis une nouvelle verification:

```powershell
python tools/diagnose_vector_xl.py --config config/testbench.yaml
```

Si `channelCount` reste a `0` apres reboot, il faudra passer a une des deux actions suivantes hors projet:

1. desinstaller completement puis reinstaller `Vector XL Driver Library` depuis l'installeur Vector avec interface graphique
2. verifier dans l'ecosysteme Vector si une version de XL Driver plus recente que `25.20.14.0` est requise pour ce poste

### Fichiers de preuve

- `reports/msiexec_xl_repair_elevated.log`
- `reports/vector_admin_recovery_transcript.log`
- `reports/debug.log`
- `C:\Users\hamdi\AppData\Local\Vector\VectorHardwareManager\VHM_2026_04_09.log`
- `C:\ProgramData\Vector\VectorHardwareService\VHS_2026_04_09.log`
