"""Fixtures pytest et validation de configuration pour la couche ECO directe."""

from __future__ import annotations

from pathlib import Path
from typing import Dict
import logging
import os
import sys

import pytest
import yaml

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
LOGGER = logging.getLogger(__name__)

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

REQUIRED_SIGNALS = {
    "driver_mode_request",
    "driver_mode_req_valid",
    "ignition_state",
    "hv_ready",
    "vcu_fault_level",
    "degraded_mode",
    "gear_position",
    "vehicle_speed",
    "accel_pedal_pos",
    "brake_pedal",
    "battery_soc",
    "battery_temp",
    "driving_mode_active",
}

OPTIONAL_SIGNALS = {
    "drivemode_accepted",
    "drivemode_reject_reason",
}


def pytest_addoption(parser: pytest.Parser) -> None:
    """Ajouter les options CLI de configuration et de debug."""

    parser.addoption(
        "--config",
        action="store",
        default=os.getenv("ECO_MODE_CONFIG", str(ROOT / "config" / "testbench.yaml")),
        help="Chemin vers testbench.yaml",
    )
    parser.addoption(
        "--eco-debug",
        action="store_true",
        default=os.getenv("ECO_MODE_DEBUG", "0") == "1",
        help="Activer les logs debug ECO (evite le conflit avec pytest --debug)",
    )


def _require_mapping(cfg: dict, key: str) -> Dict:
    """Retourner une section mapping ou lever une erreur lisible."""

    entry = cfg.get(key)
    if not isinstance(entry, dict):
        raise ValueError(f"La section '{key}' doit etre un mapping")
    return entry


def _validate_signal_entry(name: str, entry: dict) -> None:
    """Valider qu un signal de testbench reference bien bus/frame/signal."""

    if not isinstance(entry, dict):
        raise ValueError(f"Le signal '{name}' doit etre un mapping")
    for field in ("bus", "frame", "signal"):
        if not entry.get(field):
            raise ValueError(f"Signal '{name}' manquant '{field}'")


def _validate_config(cfg: dict) -> None:
    """Valider la configuration minimale requise par les tests directs."""

    _require_mapping(cfg, "fibex")
    buses_cfg = _require_mapping(cfg, "buses")
    signals_cfg = _require_mapping(cfg, "signals")
    _require_mapping(cfg, "timing_ms")

    for signal_name in REQUIRED_SIGNALS:
        if signal_name not in signals_cfg:
            raise ValueError(f"Signal requis '{signal_name}' manquant dans la config")
    for signal_name in OPTIONAL_SIGNALS:
        if signal_name in signals_cfg:
            _validate_signal_entry(signal_name, signals_cfg[signal_name])
    for name, entry in signals_cfg.items():
        _validate_signal_entry(name, entry)
        bus_name = entry.get("bus")
        if bus_name not in buses_cfg:
            raise ValueError(f"Signal '{name}' reference un bus inconnu '{bus_name}'")

    for name, entry in buses_cfg.items():
        if not isinstance(entry, dict):
            raise ValueError(f"Bus '{name}' doit etre un mapping")
        if entry.get("channel_index") is None:
            raise ValueError(
                f"Bus '{name}' doit renseigner 'channel_index' pour l usage direct de flexray-vector-lib"
            )
        if not entry.get("app_name"):
            raise ValueError(f"Bus '{name}' doit renseigner 'app_name'")


def _resolve_path(path_value: str, base_dir: Path, *, fallback_dir: Path | None = None) -> Path:
    path = Path(path_value)
    if not path.is_absolute():
        primary = (base_dir / path).resolve()
        if primary.exists() or fallback_dir is None:
            return primary
        fallback = (fallback_dir / path).resolve()
        if fallback.exists():
            LOGGER.debug(
                "Chemin relatif resolu via le repertoire racine: raw=%s primary=%s fallback=%s",
                path_value,
                primary,
                fallback,
            )
            return fallback
        return primary
    return path


def _load_config(pytestconfig: pytest.Config) -> dict:
    """Charger le testbench YAML et resoudre les chemins locaux."""

    cfg_path = Path(pytestconfig.getoption("--config"))
    if not cfg_path.is_absolute():
        cfg_path = ROOT / cfg_path
    if not cfg_path.is_file():
        raise FileNotFoundError(f"Fichier de config introuvable: {cfg_path}")
    LOGGER.debug("Chargement de la configuration pytest depuis %s", cfg_path)

    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    if not isinstance(cfg, dict):
        raise ValueError("La racine de config doit etre un mapping")

    fibex_cfg = _require_mapping(cfg, "fibex")
    fibex_cfg["path"] = str(
        _resolve_path(
            str(fibex_cfg.get("path", "")),
            cfg_path.parent,
            fallback_dir=ROOT,
        )
    )
    if not Path(fibex_cfg["path"]).is_file():
        raise FileNotFoundError(f"Fichier FIBEX introuvable apres resolution: {fibex_cfg['path']}")
    LOGGER.info("FIBEX resolu pour les tests: %s", fibex_cfg["path"])
    _validate_config(cfg)
    return cfg


def _configure_logging(debug: bool, log_dir: Path) -> None:
    """Configurer le logger racine une seule fois pour la session."""

    root_logger = logging.getLogger()
    log_dir.mkdir(parents=True, exist_ok=True)
    level = logging.DEBUG if debug else logging.INFO
    root_logger.setLevel(level)

    formatter = logging.Formatter("%(asctime)s %(levelname)s [%(name)s] %(message)s")
    log_file = log_dir / ("debug.log" if debug else "run.log")
    file_handler_present = any(
        isinstance(handler, logging.FileHandler) and Path(handler.baseFilename) == log_file
        for handler in root_logger.handlers
        if isinstance(handler, logging.FileHandler)
    )
    if not file_handler_present:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    if debug:
        has_console = any(
            isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler)
            for handler in root_logger.handlers
        )
        if not has_console:
            stream_handler = logging.StreamHandler()
            stream_handler.setLevel(level)
            stream_handler.setFormatter(formatter)
            root_logger.addHandler(stream_handler)

    for logger_name in ("flexray_vector_lib", "eco_mode_harness", "canmatrix", __name__):
        logger = logging.getLogger(logger_name)
        logger.setLevel(level)
        logger.propagate = True

    LOGGER.debug("Logging configure: level=%s log_file=%s", logging.getLevelName(level), log_file)


@pytest.fixture(scope="session")
def cfg(pytestconfig: pytest.Config) -> dict:
    """Retourner la configuration YAML validee pour la session."""

    return _load_config(pytestconfig)


@pytest.fixture(scope="session")
def debug_enabled(pytestconfig: pytest.Config) -> bool:
    """Retourner l etat du mode debug."""

    return bool(pytestconfig.getoption("--eco-debug"))


@pytest.fixture(scope="function")
def eco_mode(cfg: dict, debug_enabled: bool):
    """Fournir un controleur ECO direct base sur flexray-vector-lib."""

    from eco_mode_harness import EcoModeController

    log_dir = Path(os.getenv("ECO_MODE_REPORT_DIR", str(ROOT / "reports")))
    if not log_dir.is_absolute():
        log_dir = ROOT / log_dir
    _configure_logging(debug_enabled, log_dir)

    controller = EcoModeController.from_config(cfg)
    try:
        yield controller
    finally:
        controller.close()
