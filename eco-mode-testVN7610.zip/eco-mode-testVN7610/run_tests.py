"""Point d entree CLI pour lancer pytest avec rapports et logs debug."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys

import pytest


def main() -> int:
    """Parser les arguments, poser les variables et lancer pytest."""

    parser = argparse.ArgumentParser(description="Tests de validation du mode ECO (FIBEX)")
    parser.add_argument(
        "--config",
        default="config/testbench.yaml",
        help="Chemin vers testbench.yaml",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Activer les logs debug",
    )
    parser.add_argument(
        "--report-dir",
        default="reports",
        help="Dossier pour les rapports HTML et JUnit",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=15,
        help="Timeout global pytest en secondes",
    )
    args = parser.parse_args()

    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = Path.cwd() / config_path
    os.environ["ECO_MODE_CONFIG"] = str(config_path)
    os.environ["ECO_MODE_DEBUG"] = "1" if args.debug else "0"
    os.environ["ECO_MODE_REPORT_DIR"] = str(report_dir)

    pytest_args = [
        "-q",
        f"--html={report_dir / 'report.html'}",
        "--self-contained-html",
        f"--junitxml={report_dir / 'junit.xml'}",
        f"--timeout={args.timeout}",
        "-s",
    ]
    if args.debug:
        pytest_args += [
            "-o",
            "log_cli=true",
            "-o",
            "log_cli_level=DEBUG",
        ]

    return pytest.main(pytest_args)


if __name__ == "__main__":
    sys.exit(main())
