# FIBEX - Guide rapide (base sur fibex/example_vehicle.xml)

## Introduction FIBEX
FIBEX (Field Bus Exchange Format) est un format standard ASAM qui decrit un reseau de communication embarque:
clusters, canaux, trames (frames), PDUs, signaux, codage et timing. Il sert de source unique de verite
pour encoder/decoder des trames (ex: avec canmatrix) et pour mapper des signaux applicatifs vers des bus.

## Documentation generale FIBEX (du general au detail)
Cette section explique la structure d un fichier FIBEX et comment le lire pour identifier
rapidement un bus (LIN/CAN/FlexRay), un message, et les signaux qu il transporte.

### 1) Structure globale d un fichier FIBEX
Un FIBEX est un XML qui contient en general:
- `<fx:PROJECT>`: informations de projet (nom, description, version).
- `<fx:ELEMENTS>`: toutes les definitions de reseau.
- `<fx:PROCESSING-INFORMATION>`: les details de codage (types, unites, conversions).

### 2) Elements principaux et role
Dans `<fx:ELEMENTS>` on trouve typiquement:
- **CLUSTERS**: un cluster = un reseau logique (ex: CAN, LIN, FlexRay) avec son protocole,
  sa vitesse, sa politique de numerotation des bits, et des references vers des canaux.
- **CHANNELS**: un canal = un support physique logique du cluster. Il porte les trames via
  des *triggerings* (identifiants CAN, slots FlexRay, etc.).
- **ECUS**: les noeuds du reseau. On y trouve qui emet/recoit quoi.
- **FRAMES**: les trames sur le bus (payload brut).
- **PDUS**: les conteneurs applicatifs, qui regroupent des signaux.
- **SIGNALS**: definitions des signaux (nom, valeur par defaut, reference de codage).

Dans `<fx:PROCESSING-INFORMATION>`:
- **CODINGS**: type de base, taille en bits, et methode de conversion (lineaire, tabulaire).
- **COMPU-METHODS**: formule de conversion brut -> physique.
- **UNITS**: unite associee (km/h, degC, %, etc.).

### 3) Architecture logique (du bus au signal)
Le chemin de lecture typique est:

```
CLUSTER (protocole, vitesse)
  -> CHANNEL (bus physique)
     -> FRAME-TRIGGERING (ID CAN, slot FlexRay, timing LIN)
        -> FRAME (taille DLC, conteneur)
           -> PDU-INSTANCE (offset dans la trame)
              -> PDU (conteneur applicatif)
                 -> SIGNAL-INSTANCE (bit position + endianness)
                    -> SIGNAL (nom, defaut)
                       -> CODING/COMPU-METHOD (type, facteur, unite)
```

### 3a) Schema visuel (ASCII) bus -> signal
```
      +----------------------+
      |       CLUSTER        |
      |  (PROTOCOL, SPEED)   |
      +----------+-----------+
                 |
                 v
      +----------------------+
      |       CHANNEL        |
      |   (bus physique)     |
      +----------+-----------+
                 |
                 v
      +----------------------+
      |  FRAME-TRIGGERING    |
      | (ID CAN / slot FR /  |
      |  timing LIN)         |
      +----------+-----------+
                 |
                 v
      +----------------------+
      |        FRAME         |
      |   (BYTE-LENGTH)      |
      +----------+-----------+
                 |
                 v
      +----------------------+
      |     PDU-INSTANCE     |
      |    (offset frame)    |
      +----------+-----------+
                 |
                 v
      +----------------------+
      |         PDU          |
      |  (conteneur appli)   |
      +----------+-----------+
                 |
                 v
      +----------------------+
      |   SIGNAL-INSTANCE    |
      | (bit-pos, endianness)|
      +----------+-----------+
                 |
                 v
      +----------------------+
      |        SIGNAL        |
      | (nom, default value) |
      +----------+-----------+
                 |
                 v
      +----------------------+
      |        CODING        |
      | (type, unit, conv)   |
      +----------------------+
```

### 3a-bis) Schema image (SVG/PNG)
![Architecture bus vers signal (SVG)](assets/fibex-bus-signal.svg)
![Architecture bus vers signal (PNG)](assets/fibex-bus-signal.png)

### 3bis) Numerotation des bits et endianness
Deux champs influencent l interpretation des bits:
- `CLUSTER/IS-HIGH-LOW-BIT-ORDER` et `CLUSTER/BIT-COUNTING-POLICY` definissent
  la numerotation globale des bits dans le cluster.
- `SIGNAL-INSTANCE/IS-HIGH-LOW-BYTE-ORDER` definit l ordre des octets pour le signal.

Dans beaucoup d outils CAN, on assimile souvent:
- **false** -> little-endian (Intel)
- **true** -> big-endian (Motorola)

Mais la lecture exacte depend toujours des deux politiques definies dans le FIBEX.

### 4) Differencier un signal LIN / CAN / FlexRay
Dans un FIBEX, un **signal n est pas "LIN" ou "CAN" en soi**. Il le devient par sa **liaison**
au bus via la chaine `SIGNAL -> PDU -> FRAME -> FRAME-TRIGGERING -> CHANNEL -> CLUSTER`.

Pour determiner le bus d un signal:
1. Trouver le `SIGNAL-INSTANCE` (dans le PDU).
2. Remonter au `PDU`, puis a la `FRAME` qui le contient.
3. Chercher la `FRAME-TRIGGERING` associee (dans le channel).
4. Identifier le `CHANNEL`, puis le `CLUSTER`.
5. Lire `fx:PROTOCOL` dans le cluster: **LIN**, **CAN**, **FLEXRAY**.

Dans `example_vehicle.xml`, le cluster `cluster_example_vehicle` a
`<fx:PROTOCOL>CAN</fx:PROTOCOL>`: **tous les signaux sont CAN**.

### 5) Structure de message par bus (rappel + mapping FIBEX)
**CAN**
- Message: ID (11/29 bits), DLC, Data[0..7] (ou CAN FD plus long).
- FIBEX: `FRAME-TRIGGERING/IDENTIFIER` = ID CAN, `FRAME/BYTE-LENGTH` = DLC,
  `SIGNAL-INSTANCE/BIT-POSITION` = position dans la charge utile.

**LIN**
- Message: Header (break, sync, PID) + Response (data + checksum).
- FIBEX: cluster `PROTOCOL=LIN`, souvent avec schedule/slots de trames.
  Les `FRAME-TRIGGERINGS` representent les frames LIN et leurs timings.

**FlexRay**
- Message: slots (static/dynamic), cycle, channel A/B, payload, CRC.
- FIBEX: `FRAME-TRIGGERING` contient le slot, cycle, repetition et canal;
  les frames sont associees a un cluster `PROTOCOL=FLEXRAY`.

> En pratique, CAN met surtout l accent sur l ID, LIN sur la planification master/slave,
> FlexRay sur le temps (slot/cycle) et la redondance (A/B).

### 6) Exemple fil rouge (CAN) base sur `example_vehicle.xml`
Signal **DriveModeRequest**:
- SIGNAL: `SIG_HMI_Request.DriveModeRequest`
- SIGNAL-INSTANCE: `PDUINST_HMI_Request.DriveModeRequest` avec `BIT-POSITION=0`
- PDU: `PDU_HMI_Request` (BYTE-LENGTH=8)
- FRAME: `FRAME_HMI_Request` (BYTE-LENGTH=8)
- FRAME-TRIGGERING: `FT_HMI_Request` avec `IDENTIFIER-VALUE=256` (0x100)
- CHANNEL: `CANCHANNEL01`
- CLUSTER: `cluster_example_vehicle` (PROTOCOL=CAN, SPEED=500 kbps)

Lecture rapide: **ID 0x100** transporte un PDU de 8 octets,
dont le signal `DriveModeRequest` occupe les bits 0..7.

### 7) Exemple de codage/decodage (conversion brut -> physique)
Le codage associe a `DriveModeRequest` est un **A_UINT8** avec une
conversion lineaire de facteur 1 et offset 0:

```
phys = brut * facteur + offset
```

Donc un brut a 2 signifie une valeur physique 2 (meme echelle).

### 8) Exemple multi-bus (illustratif)
Ci-dessous un exemple conceptuel d architecture vehicule:
- **LIN**: capteurs simples (portes, vitres).
- **CAN**: aggregateur (BCM/VCU) et diagnostic.
- **FlexRay**: fonctions critiques (freinage/assis).

Dans un FIBEX multi-bus, on aurait:
- 1 cluster LIN (PROTOCOL=LIN) + channels LIN
- 1 cluster CAN (PROTOCOL=CAN) + channels CAN
- 1 cluster FlexRay (PROTOCOL=FLEXRAY) + channels FlexRay

Le signal est rattache au bon bus via ses frames et channels.

### 9) Checklist pour ajouter un nouveau message
1. Creer le `SIGNAL` (et son `CODING/UNIT` si besoin).
2. Ajouter un `SIGNAL-INSTANCE` dans un `PDU`.
3. Lier le `PDU` a une `FRAME` via `PDU-INSTANCE`.
4. Declencher la `FRAME` dans le `CHANNEL` (ID CAN / slot FlexRay / planning LIN).
5. Associer l emission/reception a un `ECU` (ports).

## Comparatif rapide: LIN vs CAN vs FlexRay (cas d usage concrets)
| Bus | Debit typique | Determinisme | Cout/complexite | Cas d usage concret |
| --- | --- | --- | --- | --- |
| LIN | 10-20 kbps | Faible | Tres bas | Commandes simples: vitres, sieges, capteurs de porte, HVAC |
| CAN | 125 kbps - 1 Mbps | Moyen | Moyen | Chassis/powertrain, diagnostic, capteurs, ADAS non critique |
| FlexRay | 10 Mbps (par canal) | Eleve (time-triggered) | Eleve | Fonctions critiques: freinage, direction, chassis actif |

Notes:
- LIN est souvent esclave (master/slave) pour actionneurs simples.
- CAN est le bus polyvalent le plus utilise en automobile.
- FlexRay est choisi quand la latence et le determinisme sont prioritaires.

## Ce que contient example_vehicle.xml (reseau, bus, protocole)
Le fichier `fibex/example_vehicle.xml` definit un seul cluster:
- Cluster: `cluster_example_vehicle`
- Protocole: CAN 2.0
- Vitesse: 500 kbps
- Canal: `CANCHANNEL01`

Dans ce FIBEX d exemple, toutes les trames sont CAN. Les bus LIN/FlexRay utilises par les tests
ne sont pas decrits dans ce fichier: ils sont logiques dans la config de test (YAML).
Pour un vrai banc multi-bus, il faut un FIBEX avec plusieurs clusters et un mapping dans `fibex.clusters`.

## Frames et identifiants CAN (extrait du FIBEX)
Les frames ci-dessous sont declarees sur `CANCHANNEL01` (DLC=8, ID standard):

| Frame (nom canmatrix) | ID (dec) | ID (hex) | Signaux (start_bit, size) |
| --- | --- | --- | --- |
| PDU_HMI_Request | 256 | 0x100 | DriveModeRequest (0,8), DriveModeReqValid (8,8) |
| PDU_Body_Status | 272 | 0x110 | IgnitionState (0,8), BrakePedal (8,8) |
| PDU_Chassis_Status | 288 | 0x120 | VehicleSpeed (0,16), AccelPedalPos (16,8) |
| PDU_Powertrain_Status | 304 | 0x130 | HVReady (0,8) |
| PDU_VCU_Status | 320 | 0x140 | VCUFaultLevel (0,8), DegradedMode (8,8) |
| PDU_Trans_Status | 336 | 0x150 | GearPosition (0,8) |
| PDU_Battery_Status | 352 | 0x160 | BatterySOC (0,8), BatteryTemp (8,8) |
| PDU_VCU_Mode | 368 | 0x170 | DrivingModeActive (0,8), DriveModeAccepted (8,8), DriveModeRejectReason (16,8) |

Remarque: dans ce projet, les noms de frame utilises dans le YAML sont ceux du FIBEX
(ex: `PDU_HMI_Request`). Le codec FIBEX (canmatrix) encode/decodera ces frames par nom.

## Signaux utilises par les tests (resume)
Le mapping ci-dessus est exploite par `config/testbench.yaml`. Les signaux principaux sont:
- Demande conducteur: `DriveModeRequest`, `DriveModeReqValid`
- Preconditions corps/vehicule: `IgnitionState`, `BrakePedal`, `VehicleSpeed`, `AccelPedalPos`
- Etats powertrain/VCU: `HVReady`, `VCUFaultLevel`, `DegradedMode`, `GearPosition`
- Batterie: `BatterySOC`, `BatteryTemp`
- Resultat ECO: `DrivingModeActive`, `DriveModeAccepted`, `DriveModeRejectReason`

## Outils materiels (PC) pour envoyer des signaux CAN/LIN/FlexRay
Ce sont les interfaces les plus courantes pour un PC de test (USB/PCIe + drivers):

CAN:
- Interfaces USB/PCIe CAN avec drivers: Vector VN16xx/VN1640 (XL Driver), Kvaser Leaf, PEAK PCAN-USB,
  Intrepid ValueCAN, NI XNET CAN.
- Necessaires: transceiver CAN + termination 120 ohms.

LIN:
- Interfaces avec fonction LIN master + transceiver LIN: Vector VN1640 (CAN/LIN), NI XNET, ETAS ES58x,
  Intrepid neoVI (selon modele).
- Necessaires: transceiver LIN, pull-up master, au moins un esclave.

FlexRay:
- Interfaces FlexRay dediees: Vector VN34xx/VN36xx, NI XNET FlexRay, ETAS ES59x,
  Intrepid neoVI (selon modele).
- Necessaires: transceiver FlexRay et terminaisons compatibles.

Logiciels PC souvent utilises:
- Vector CANoe/CANalyzer pour generer et monitorer le trafic.
- Outils constructeurs ou scripts Python (ex: python-can pour CAN).
