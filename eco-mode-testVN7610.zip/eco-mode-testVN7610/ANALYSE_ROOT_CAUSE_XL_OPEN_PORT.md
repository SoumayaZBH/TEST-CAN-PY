# Analyse de la cause racine: `xlOpenPort -> XL_ERR_NOT_IMPLEMENTED`

## Resume

L'erreur actuelle n'est plus liee au chemin du FIBEX ni aux signaux des tests.
Le blocage se produit au moment de l'ouverture du port Vector XL, avant toute emission FlexRay utile.

Erreur observee:

```text
flexray_vector_lib.errors.VectorApiError: xlOpenPort a echoue : XL_ERR_NOT_IMPLEMENTED
```

Depuis cette analyse, la wheel a ete corrigee pour traiter la cause racine cote backend Vector XL.

## Ce qui a deja ete valide

- Le fichier de configuration pytest est bien charge.
- Le chemin FIBEX est correctement resolu:
  `C:\Users\hamdi\Desktop\DOSSIER_TEST\eco-mode-testVN7610\fibex\example_vehicle.xml`
- Le FIBEX est bien charge par `flexray_vector_lib`.
- Les signaux utilises par `test_eco_mode_acceptance.py` et `test_eco_mode_rejection.py` sont bien des signaux FlexRay.
- Les messages `canmatrix` du type `xlsx is not supported` ou `eds is not supported` ne sont pas la cause de l'echec.

Autrement dit, le probleme n'est pas un probleme CAN et n'est pas un probleme de mapping de signaux.

## Ou l'echec se produit exactement

La sequence observee dans les logs est la suivante:

1. `conftest.py` charge `config/testbench.yaml` et resout correctement le FIBEX.
2. `EcoModeController.from_config(...)` cree le backend Vector XL.
3. Le test commence a injecter le premier signal de precondition, par exemple `IgnitionState`.
4. `eco_mode_harness.py` appelle `backend.open()`.
5. Le backend de la wheel appelle `xlOpenPort(...)`.
6. L'API Vector retourne `XL_ERR_NOT_IMPLEMENTED`.

Le point de rupture est donc en amont de:

- la configuration du cluster FlexRay,
- l'activation du canal,
- l'emission des frames,
- la verification des verdicts ECO.

## Preuves dans le code

### Resolution FIBEX OK

Dans [conftest.py](C:/Users/hamdi/Desktop/DOSSIER_TEST/eco-mode-testVN7610/conftest.py), le FIBEX est resolu et verifie avant les tests:

- [conftest.py](C:/Users/hamdi/Desktop/DOSSIER_TEST/eco-mode-testVN7610/conftest.py#L132)
- [conftest.py](C:/Users/hamdi/Desktop/DOSSIER_TEST/eco-mode-testVN7610/conftest.py#L153)

### L'appel bloquant est l'ouverture du port XL

Dans [eco_mode_harness.py](C:/Users/hamdi/Desktop/DOSSIER_TEST/eco-mode-testVN7610/src/eco_mode_harness.py), le log `XL open requested` est emis juste avant l'appel a `super().open()`:

- [eco_mode_harness.py](C:/Users/hamdi/Desktop/DOSSIER_TEST/eco-mode-testVN7610/src/eco_mode_harness.py#L162)
- [eco_mode_harness.py](C:/Users/hamdi/Desktop/DOSSIER_TEST/eco-mode-testVN7610/src/eco_mode_harness.py#L169)

La creation du controleur montre aussi que le backend est bien initialise pour le bus FlexRay:

- [eco_mode_harness.py](C:/Users/hamdi/Desktop/DOSSIER_TEST/eco-mode-testVN7610/src/eco_mode_harness.py#L423)
- [eco_mode_harness.py](C:/Users/hamdi/Desktop/DOSSIER_TEST/eco-mode-testVN7610/src/eco_mode_harness.py#L454)

### La wheel ouvrait le port avec `xlOpenPort(...)`

Dans la wheel installee `flexray_vector_lib`, le backend Vector XL:

- forçait `XL_INTERFACE_VERSION = 3`
- construisait `access_mask = 1 << channel_index`
- ne demandait pas explicitement le droit d initialisation dans `permission_mask`
- appelle `xlOpenPort(..., XL_BUS_TYPE_FLEXRAY)`

Reference backend corrige:

- [backend.py](C:/Users/hamdi/AppData/Local/Programs/Python/Python313/Lib/site-packages/flexray_vector_lib/vector/backend.py)

## Cause racine

La cause racine est une incompatibilite entre la facon dont la wheel `flexray_vector_lib-0.1.0` ouvrait le port Vector XL et ce que le driver `vxlapi`/la configuration Vector expose reellement sur cette machine.

Plus precisement, l'appel suivant n'est pas pris en charge dans l'environnement courant:

```text
xlOpenPort(app_name, access_mask, rx_queue_size, XL_INTERFACE_VERSION=3, XL_BUS_TYPE_FLEXRAY)
```

Les constatations precises faites sur cette machine sont:

- avec `XL_INTERFACE_VERSION=3`, `xlOpenPort(...)` retourne `XL_ERR_NOT_IMPLEMENTED`
- avec `XL_INTERFACE_VERSION=4`, le meme appel avec `access_mask = 1 << channel_index` retourne `XL_ERR_INVALID_CHAN_INDEX`
- `xlGetApplConfig(...)` ne retourne aucun mapping applicatif exploitable dans l'etat courant
- `xlGetDriverConfig(...)` remonte `channelCount = 0`, donc aucun canal FlexRay visible par le XL Driver sur cette machine au moment du diagnostic

La cause racine cote code etait donc triple:

1. la wheel utilisait une version d interface XL non adaptee par defaut pour ce cas FlexRay
2. la wheel supposait a tort que `1 << channel_index` etait toujours le bon `access_mask`
3. la wheel n initialisait pas `permission_mask` avec le masque demande, donc meme un port ouvert aurait pu manquer des droits d initialisation

## Ce que cela signifie pour les tests

Les tests echouent avant la moindre transmission de signal FlexRay.

Donc:

- les preconditions ECO ne sont jamais injectees sur le bus,
- la requete ECO n'est jamais emise,
- l'echec n'est pas lie a la logique metier des tests,
- l'echec n'est pas lie au fait d'utiliser des signaux CAN.

## Pourquoi ce n'est pas un probleme CAN

Tous les signaux manipules par les tests sont portes par des frames FlexRay du FIBEX.
L'erreur survient avant meme que le contenu de la frame soit transmis.

Le simple fait que `xlOpenPort` echoue montre que le probleme est au niveau:

- de l'ouverture du port materiel,
- du driver Vector XL,
- de la compatibilite de la wheel avec cet environnement.

Ce n'est donc pas un probleme de protocole CAN ni de definition des signaux de test.

## Correctif applique

Le backend de la wheel a ete modifie pour:

1. tenter `XL_INTERFACE_VERSION_V4` en premier, puis replier vers `V3` uniquement si le driver retourne `XL_ERR_NOT_IMPLEMENTED`
2. resoudre le vrai canal FlexRay via `xlGetDriverConfig` et utiliser son `channelMask`
3. utiliser `xlGetApplConfig` seulement comme mode explicite ou de compatibilite
4. demander explicitement le droit d initialisation en initialisant `permission_mask` avec le `access_mask`
5. lever une erreur de configuration lisible si aucun canal FlexRay n est visible dans le XL Driver

## Consequence pratique

Le prochain correctif ne doit pas viser les tests Python ni le FIBEX, mais la couche d'ouverture Vector XL.

En pratique, il faut maintenant:

- verifier que le VN7610 est bien visible dans le XL Driver sur la machine cible
- verifier le mapping applicatif `app_name` / `app_channel` si vous voulez passer par `xlGetApplConfig`
- conserver `channel_index` comme index global quand vous ne dependez pas du mapping applicatif

## Logs deja disponibles

Les logs ajoutes dans le projet permettent maintenant de voir clairement:

- la resolution effective du FIBEX,
- la creation du controleur ECO,
- le premier signal logique demande,
- le moment exact ou `XL open requested` est declenche,
- l'endroit exact ou `xlOpenPort` echoue.

Les logs Python de `flexray_vector_lib` remontent bien dans la console et dans `reports/debug.log`.
En revanche, les logs internes natifs de la DLL `vxlapi` ne sont visibles que si le driver Vector les expose lui-meme; ce n'est pas force depuis Python.
