"""GUI emulator to intercept outgoing test flow and inject incoming FlexRay frames."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import queue
import socket
import struct
import sys
import threading
from typing import Callable, Optional
import tkinter as tk
from tkinter import ttk

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from fibex_parser import FrameDef, parse_fibex
from signal_codec import decode_payload, encode_payload

try:
    from emulator.eco_mode_logic import build_vcu_mode_response
except ModuleNotFoundError:
    from eco_mode_logic import build_vcu_mode_response

UDP_HEADER = struct.Struct("!IBB")


@dataclass(frozen=True)
class UdpFrame:
    """Decoded UDP transport frame for test/emulator exchange."""

    frame_id: int
    data: bytes
    is_extended_id: bool = False


def pack_udp_frame(frame: UdpFrame) -> bytes:
    """Encode frame into the same payload format used by netio UdpAdapter."""

    payload = bytes(frame.data)
    if len(payload) > 255:
        raise ValueError("Payload too large for UDP adapter format (max 255 bytes)")
    return UDP_HEADER.pack(int(frame.frame_id), 1 if frame.is_extended_id else 0, len(payload)) + payload


def unpack_udp_frame(payload: bytes) -> Optional[UdpFrame]:
    """Decode one UDP payload into frame structure."""

    if len(payload) < UDP_HEADER.size:
        return None
    frame_id, ext_flag, length = UDP_HEADER.unpack(payload[: UDP_HEADER.size])
    data = payload[UDP_HEADER.size : UDP_HEADER.size + length]
    if len(data) != length:
        return None
    return UdpFrame(frame_id=frame_id, data=data, is_extended_id=bool(ext_flag))


class UdpBridge:
    """Background UDP listener/sender shared by emulator UI."""

    def __init__(
        self,
        listen_host: str,
        listen_port: int,
        target_host: str,
        target_port: int,
        on_rx: Callable[[UdpFrame], None],
    ) -> None:
        self._listen_host = listen_host
        self._listen_port = listen_port
        self._target_host = target_host
        self._target_port = target_port
        self._on_rx = on_rx

        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()

    def start(self) -> None:
        with self._lock:
            if self._thread is not None:
                return
            self._stop_event.clear()
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._sock.bind((self._listen_host, self._listen_port))
            self._sock.settimeout(0.2)
            self._thread = threading.Thread(target=self._run, name="udp-emulator-bridge", daemon=True)
            self._thread.start()

    def stop(self) -> None:
        with self._lock:
            self._stop_event.set()
            sock = self._sock
            self._sock = None
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
        thread = self._thread
        if thread is not None:
            thread.join(timeout=1.0)
        self._thread = None

    def send(self, frame: UdpFrame) -> None:
        payload = pack_udp_frame(frame)
        with self._lock:
            if self._sock is None:
                raise RuntimeError("UDP bridge not started")
            self._sock.sendto(payload, (self._target_host, self._target_port))

    def _run(self) -> None:
        while not self._stop_event.is_set():
            sock = self._sock
            if sock is None:
                return
            try:
                payload, _addr = sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                return
            frame = unpack_udp_frame(payload)
            if frame is not None:
                self._on_rx(frame)


class EmulatorUi:
    """Tkinter application for displaying and injecting FlexRay test traffic."""

    def __init__(
        self,
        root: tk.Tk,
        fibex_path: Path,
        cluster_name: str,
        listen_host: str,
        listen_port: int,
        target_host: str,
        target_port: int,
    ) -> None:
        self._root = root
        self._root.title("ECO Mode FlexRay Emulator")
        self._root.geometry("1320x760")
        self._root.protocol("WM_DELETE_WINDOW", self._on_close)

        self._fibex_model = parse_fibex(fibex_path, cluster_name)
        self._frames_by_name = self._fibex_model.frames
        self._frames_by_slot = self._fibex_model.slots
        self._latest_signals: dict[str, float | int | bool] = {}
        self._event_queue: queue.Queue[UdpFrame] = queue.Queue()

        self._listen_host_var = tk.StringVar(value=listen_host)
        self._listen_port_var = tk.StringVar(value=str(listen_port))
        self._target_host_var = tk.StringVar(value=target_host)
        self._target_port_var = tk.StringVar(value=str(target_port))
        self._auto_reply_var = tk.BooleanVar(value=True)
        self._status_var = tk.StringVar(value="Stopped")
        self._selected_frame_var = tk.StringVar(value=sorted(self._frames_by_name.keys())[0])

        self._bridge: Optional[UdpBridge] = None
        self._signal_entries: dict[str, tk.Entry] = {}
        self._build_layout()

        self._root.after(50, self._process_events)

    def _build_layout(self) -> None:
        top = ttk.Frame(self._root, padding=8)
        top.pack(fill=tk.X)

        ttk.Label(top, text="Listen Host").grid(row=0, column=0, sticky="w")
        ttk.Entry(top, textvariable=self._listen_host_var, width=14).grid(row=0, column=1, padx=4)
        ttk.Label(top, text="Listen Port").grid(row=0, column=2, sticky="w")
        ttk.Entry(top, textvariable=self._listen_port_var, width=8).grid(row=0, column=3, padx=4)

        ttk.Label(top, text="Target Host").grid(row=0, column=4, sticky="w")
        ttk.Entry(top, textvariable=self._target_host_var, width=14).grid(row=0, column=5, padx=4)
        ttk.Label(top, text="Target Port").grid(row=0, column=6, sticky="w")
        ttk.Entry(top, textvariable=self._target_port_var, width=8).grid(row=0, column=7, padx=4)

        ttk.Checkbutton(top, text="Auto ECO response", variable=self._auto_reply_var).grid(
            row=0, column=8, padx=8
        )
        ttk.Button(top, text="Start", command=self._start_bridge).grid(row=0, column=9, padx=4)
        ttk.Button(top, text="Stop", command=self._stop_bridge).grid(row=0, column=10, padx=4)
        ttk.Label(top, textvariable=self._status_var).grid(row=0, column=11, padx=8, sticky="e")
        top.columnconfigure(11, weight=1)

        body = ttk.Panedwindow(self._root, orient=tk.HORIZONTAL)
        body.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        left = ttk.Frame(body, padding=4)
        right = ttk.Frame(body, padding=4)
        body.add(left, weight=3)
        body.add(right, weight=2)

        self._build_log_panel(left)
        self._build_injection_panel(right)

    def _build_log_panel(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Flux intercepte / injecte").pack(anchor="w")
        columns = ("time", "direction", "slot", "frame", "payload", "signals")
        self._log_tree = ttk.Treeview(parent, columns=columns, show="headings", height=28)
        self._log_tree.heading("time", text="Time")
        self._log_tree.heading("direction", text="Direction")
        self._log_tree.heading("slot", text="Slot")
        self._log_tree.heading("frame", text="Frame")
        self._log_tree.heading("payload", text="Payload(hex)")
        self._log_tree.heading("signals", text="Signals")

        self._log_tree.column("time", width=95, anchor="w")
        self._log_tree.column("direction", width=80, anchor="center")
        self._log_tree.column("slot", width=60, anchor="center")
        self._log_tree.column("frame", width=210, anchor="w")
        self._log_tree.column("payload", width=220, anchor="w")
        self._log_tree.column("signals", width=470, anchor="w")

        yscroll = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self._log_tree.yview)
        self._log_tree.configure(yscrollcommand=yscroll.set)
        self._log_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        yscroll.pack(side=tk.RIGHT, fill=tk.Y)

    def _build_injection_panel(self, parent: ttk.Frame) -> None:
        header = ttk.Frame(parent)
        header.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(header, text="Injection manuelle").pack(anchor="w")

        frame_row = ttk.Frame(parent)
        frame_row.pack(fill=tk.X, pady=(0, 8))
        ttk.Label(frame_row, text="Frame").pack(side=tk.LEFT)
        combo = ttk.Combobox(
            frame_row,
            textvariable=self._selected_frame_var,
            values=sorted(self._frames_by_name.keys()),
            state="readonly",
            width=34,
        )
        combo.pack(side=tk.LEFT, padx=6)
        combo.bind("<<ComboboxSelected>>", lambda _event: self._refresh_signal_fields())

        self._signals_container = ttk.Frame(parent)
        self._signals_container.pack(fill=tk.BOTH, expand=True)

        actions = ttk.Frame(parent)
        actions.pack(fill=tk.X, pady=6)
        ttk.Button(actions, text="Inject frame", command=self._inject_manual_frame).pack(side=tk.LEFT)
        ttk.Button(actions, text="Reset values", command=self._refresh_signal_fields).pack(side=tk.LEFT, padx=8)

        self._refresh_signal_fields()

    def _start_bridge(self) -> None:
        if self._bridge is not None:
            self._set_status("Already started")
            return
        try:
            listen_port = int(self._listen_port_var.get().strip())
            target_port = int(self._target_port_var.get().strip())
        except ValueError:
            self._set_status("Invalid port values")
            return

        self._bridge = UdpBridge(
            listen_host=self._listen_host_var.get().strip(),
            listen_port=listen_port,
            target_host=self._target_host_var.get().strip(),
            target_port=target_port,
            on_rx=self._enqueue_rx_frame,
        )
        try:
            self._bridge.start()
        except OSError as exc:
            self._bridge = None
            self._set_status(f"Start failed: {exc}")
            return
        self._set_status("Running")

    def _stop_bridge(self) -> None:
        bridge = self._bridge
        if bridge is None:
            self._set_status("Already stopped")
            return
        bridge.stop()
        self._bridge = None
        self._set_status("Stopped")

    def _enqueue_rx_frame(self, frame: UdpFrame) -> None:
        self._event_queue.put(frame)

    def _process_events(self) -> None:
        while True:
            try:
                frame = self._event_queue.get_nowait()
            except queue.Empty:
                break
            self._handle_rx_frame(frame)
        self._root.after(50, self._process_events)

    def _handle_rx_frame(self, frame: UdpFrame) -> None:
        frame_def = self._frames_by_slot.get(frame.frame_id)
        frame_name = frame_def.name if frame_def else f"slot_{frame.frame_id}"
        decoded = self._decode_with_frame(frame_def, frame.data)
        self._latest_signals.update(decoded)
        self._append_log("RX_TEST", frame.frame_id, frame_name, frame.data, decoded)

        if not self._auto_reply_var.get():
            return
        if frame_def is None or frame_def.name != "PDU_HMI_Request":
            return

        req = int(round(float(decoded.get("DriveModeRequest", 0))))
        valid = int(round(float(decoded.get("DriveModeReqValid", 0))))
        if req == 1 and valid == 1:
            response_values = build_vcu_mode_response(self._latest_signals)
            self._inject_frame("PDU_VCU_Mode", response_values, "TX_AUTO")

    def _decode_with_frame(self, frame_def: Optional[FrameDef], payload: bytes) -> dict[str, float | int]:
        if frame_def is None:
            return {}
        decoded = decode_payload(frame_def.signals, payload)
        normalized: dict[str, float | int] = {}
        for name, value in decoded.items():
            if float(value).is_integer():
                normalized[name] = int(round(value))
            else:
                normalized[name] = value
        return normalized

    def _inject_manual_frame(self) -> None:
        try:
            values = self._collect_manual_values()
            frame_name = self._selected_frame_var.get()
            self._inject_frame(frame_name, values, "TX_MANUAL")
        except Exception as exc:
            self._set_status(f"Inject failed: {exc}")

    def _inject_frame(self, frame_name: str, values: dict[str, float | int | bool], direction: str) -> None:
        frame_def = self._frames_by_name.get(frame_name)
        if frame_def is None:
            raise KeyError(f"Unknown frame: {frame_name}")
        bridge = self._bridge
        if bridge is None:
            raise RuntimeError("Start emulator first")

        payload = encode_payload(frame_def.signals, values, frame_def.payload_length)
        frame = UdpFrame(frame_id=frame_def.slot_id, data=payload)
        bridge.send(frame)
        self._latest_signals.update(values)
        self._append_log(direction, frame_def.slot_id, frame_name, payload, values)
        self._set_status(f"Injected {frame_name}")

    def _collect_manual_values(self) -> dict[str, float | int | bool]:
        values: dict[str, float | int | bool] = {}
        for signal_name, entry in self._signal_entries.items():
            raw = entry.get().strip()
            if raw == "":
                values[signal_name] = 0
                continue
            low = raw.lower()
            if low in {"true", "false"}:
                values[signal_name] = low == "true"
                continue
            if "." in raw:
                values[signal_name] = float(raw)
            else:
                values[signal_name] = int(raw)
        return values

    def _refresh_signal_fields(self) -> None:
        for child in self._signals_container.winfo_children():
            child.destroy()
        self._signal_entries.clear()

        frame_name = self._selected_frame_var.get()
        frame_def = self._frames_by_name[frame_name]

        canvas = tk.Canvas(self._signals_container, highlightthickness=0)
        scroll = ttk.Scrollbar(self._signals_container, orient=tk.VERTICAL, command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind(
            "<Configure>",
            lambda _event: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        for row, signal in enumerate(frame_def.signals):
            ttk.Label(inner, text=signal.name, width=28).grid(row=row, column=0, sticky="w", padx=(0, 6), pady=2)
            entry = ttk.Entry(inner, width=16)
            entry.grid(row=row, column=1, sticky="w", pady=2)
            current = self._latest_signals.get(signal.name, 0)
            entry.insert(0, str(current))
            self._signal_entries[signal.name] = entry

    def _append_log(
        self,
        direction: str,
        slot_id: int,
        frame_name: str,
        payload: bytes,
        signals: dict[str, float | int | bool],
    ) -> None:
        now = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        signal_text = ", ".join(f"{name}={value}" for name, value in signals.items())
        self._log_tree.insert(
            "",
            tk.END,
            values=(now, direction, slot_id, frame_name, payload.hex(), signal_text),
        )
        rows = self._log_tree.get_children()
        if len(rows) > 800:
            self._log_tree.delete(rows[0])
        self._log_tree.yview_moveto(1.0)

    def _set_status(self, text: str) -> None:
        self._status_var.set(text)

    def _on_close(self) -> None:
        self._stop_bridge()
        self._root.destroy()


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="ECO mode local emulator GUI")
    parser.add_argument("--fibex", default=str(ROOT / "fibex" / "fibex.xml"), help="FIBEX XML path")
    parser.add_argument("--cluster", default="cluster_flexray_pt", help="FlexRay cluster name")
    parser.add_argument("--listen-host", default="127.0.0.1", help="UDP host to listen test traffic")
    parser.add_argument("--listen-port", type=int, default=50100, help="UDP port to listen test traffic")
    parser.add_argument("--target-host", default="127.0.0.1", help="UDP host to inject responses")
    parser.add_argument("--target-port", type=int, default=50101, help="UDP port to inject responses")
    return parser


def main() -> int:
    args = build_arg_parser().parse_args()
    root = tk.Tk()
    EmulatorUi(
        root=root,
        fibex_path=Path(args.fibex),
        cluster_name=str(args.cluster),
        listen_host=str(args.listen_host),
        listen_port=int(args.listen_port),
        target_host=str(args.target_host),
        target_port=int(args.target_port),
    )
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

