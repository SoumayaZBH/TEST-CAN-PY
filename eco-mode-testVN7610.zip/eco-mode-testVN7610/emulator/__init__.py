"""Local emulator package for eco-mode tests without hardware."""

