# Emulator (sans carte VN7610)

Ce dossier contient une application Python GUI pour:
- intercepter le flux sortant des tests ECO,
- afficher les trames + signaux decodes,
- simuler les signaux entrants et les injecter sur le bus logique.

## Fichier principal
- `emulator/gui_emulator.py`

## Lancer l emulateur GUI
Depuis la racine `eco-mode-testVN7610`:

```powershell
python emulator/gui_emulator.py --fibex fibex/fibex.xml --cluster cluster_flexray_pt
```

Ports par defaut:
- ecoute emulateur (trames sortantes tests): `127.0.0.1:50100`
- injection vers tests (trames entrantes simulees): `127.0.0.1:50101`

## Lancer les tests en mode emulator
Dans un autre terminal:

```powershell
python run_tests.py --config config/testbench_emulator.yaml --debug
```

Important:
- lancer d'abord la GUI, puis les tests.
- si vous voyez `endpoint distant indisponible` ou `WinError 10054`, l'emulateur GUI n'ecoute pas encore sur `127.0.0.1:50100`.

## Fonctionnement
- `RX_TEST`: trames emises par le test et recues par l emulateur.
- `TX_AUTO`: reponse ECO automatique (`PDU_VCU_Mode`) selon les preconditions observees.
- `TX_MANUAL`: trame envoyee manuellement via la GUI.

## Logique ECO automatique
Module: `emulator/eco_mode_logic.py`.

Regles:
- accepte si preconditions nominales.
- sinon renvoie un code de rejet (`DriveModeRejectReason`) compatible avec les cas de test rejet.
