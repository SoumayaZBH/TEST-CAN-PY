"""ECO mode decision logic used by the local emulator."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

SignalValue = float | int | bool


@dataclass(frozen=True)
class EcoDecision:
    """Decision payload mirrored by PDU_VCU_Mode signals."""

    active_mode: int
    accepted: int
    reject_reason: int


def build_vcu_mode_response(latest_signals: Mapping[str, SignalValue]) -> dict[str, int]:
    """Build VCU mode response signals from latest observed preconditions."""

    decision = decide_eco_request(latest_signals)
    return {
        "DrivingModeActive": decision.active_mode,
        "DriveModeAccepted": decision.accepted,
        "DriveModeRejectReason": decision.reject_reason,
    }


def decide_eco_request(latest_signals: Mapping[str, SignalValue]) -> EcoDecision:
    """Apply simple deterministic ECO acceptance rules for offline testing."""

    ignition_state = _as_int(latest_signals.get("IgnitionState"), default=0)
    hv_ready = _as_int(latest_signals.get("HVReady"), default=0)
    vcu_fault = _as_int(latest_signals.get("VCUFaultLevel"), default=0)
    degraded_mode = _as_int(latest_signals.get("DegradedMode"), default=0)
    gear_position = _as_int(latest_signals.get("GearPosition"), default=0)
    vehicle_speed = _as_int(latest_signals.get("VehicleSpeed"), default=0)
    accel_pedal = _as_int(latest_signals.get("AccelPedalPos"), default=0)
    brake_pedal = _as_int(latest_signals.get("BrakePedal"), default=0)
    battery_soc = _as_int(latest_signals.get("BatterySOC"), default=0)

    reject_reason = 0
    if ignition_state != 2:
        reject_reason = 1
    elif hv_ready != 1:
        reject_reason = 2
    elif vcu_fault != 0:
        reject_reason = 3
    elif degraded_mode != 0:
        reject_reason = 4
    elif gear_position != 1:
        reject_reason = 5
    elif vehicle_speed != 0:
        reject_reason = 6
    elif accel_pedal != 0:
        reject_reason = 7
    elif brake_pedal != 0:
        reject_reason = 8
    elif battery_soc < 10:
        reject_reason = 9

    if reject_reason == 0:
        return EcoDecision(active_mode=1, accepted=1, reject_reason=0)
    return EcoDecision(active_mode=0, accepted=0, reject_reason=reject_reason)


def _as_int(value: SignalValue | None, default: int) -> int:
    if value is None:
        return default
    if isinstance(value, bool):
        return int(value)
    try:
        return int(round(float(value)))
    except (TypeError, ValueError):
        return default

