# eco-mode-testVN7610

Tests ECO mode sur banc FlexRay avec **Vector VN7610**, en injection directe via la librairie externe `flexray-vector-lib`.

## Objectif
Ce depot conserve `config/testbench.yaml` comme source unique de configuration. Les tests `test_eco_mode_acceptance.py` et `test_eco_mode_rejection.py` utilisent maintenant exclusivement la chaine directe basee sur `flexray-vector-lib`.

Le flux est maintenant le suivant :
- chargement du testbench YAML ;
- utilisation de `flexray-vector-lib` depuis le wheel reference dans `requirements.txt` ;
- injection des signaux FlexRay via `FlexRayInjector` ;
- lecture directe des trames RX Vector XL ;
- decodage des signaux de verdict a partir du FIBEX.

## Prerequis
- Windows 11
- Python 3.10 ou plus
- pilote Vector XL installe
- interface Vector VN7610 operationnelle
- reseau FlexRay actif
- FIBEX valide du reseau cible

## Installation
Depuis le dossier du projet :

```powershell
python -m pip install -r requirements.txt
```

## Configuration
Fichier principal : `config/testbench.yaml`

Champs a verifier avant execution :
- `fibex.path` : FIBEX cible
- `fibex.clusters.flexray_pt` : nom du cluster FlexRay
- `buses.flexray_pt.app_name` : nom d application Vector
- `buses.flexray_pt.channel_index` : index global du canal VN7610
- `buses.flexray_pt.app_channel` : optionnel, canal applicatif Vector si vous utilisez `xlGetApplConfig`
- `buses.flexray_pt.interface_version` : optionnel, pour forcer une version XL si necessaire
- `buses.flexray_pt.tx_mode` et `buses.flexray_pt.tx_ack` : politique d emission
- `signals.*` : mapping logique vers `bus/frame/signal`

Remarque :
- le bloc `buses.flexray_pt` ne contient plus que les champs effectivement utilises par le flux direct.
- le FIBEX d exemple `fibex/example_vehicle.xml` est maintenant un exemple strictement FlexRay.

## Lancement
Mode standard :

```powershell
python run_tests.py --config config/testbench.yaml --debug
```

Pytest direct :

```powershell
python -m pytest -q --config config/testbench.yaml --eco-debug -s
```

## Diagnostic Vector XL
Pour lister automatiquement les canaux vus par `vxlapi` et obtenir une suggestion pour `channel_index` ou `app_channel` :

```powershell
python tools/diagnose_vector_xl.py --config config/testbench.yaml
```

Le script remonte aussi des indices cote Windows :
- peripheriques `Vector-Hardware` vus par `pnputil`
- etat du service `vHardwareService`
- presence ou absence des cles registre `HKLM\SOFTWARE\VECTOR\CANDriver 1.0`

Point important :
- un boitier Vector branche au PC mais non connecte a un autre equipement FlexRay peut rester hors bus ;
- cela peut expliquer `is_on_bus=0`, mais pas `channelCount=0` ;
- si le script affiche `channelCount=0`, le probleme est cote XL Driver / Vector Hardware Config / detection du VN7610, avant meme la question du reseau FlexRay.

## Recuperation best effort
Pour tenter les actions qu'un script Python peut faire cote Windows :
- verifier que Windows voit le VN7610
- rescanner les peripheriques
- redemarrer le service Vector
- redemarrer le peripherique VN7610
- reprober `vxlapi`

Commande :

```powershell
python tools/recover_vector_xl.py --config config/testbench.yaml
```

Avec actions systeme :

```powershell
python tools/recover_vector_xl.py --config config/testbench.yaml --scan-devices --restart-vn7610 --restart-vector-service
```

Remarque :
- ces actions peuvent exiger un terminal lance en administrateur ;
- elles peuvent aider a recuperer la detection ;
- elles ne peuvent pas garantir qu'un canal apparaisse dans `vxlapi` si le XL Driver reste non publie.
- le diagnostic detaille de l intervention du `09/04/2026` est documente dans `DIAGNOSTIC_INSTALLATION_VECTOR_2026_04_09.md`.

## Mapping applicatif Vector
Pour ecrire automatiquement un mapping `app_name` / `app_channel` avec `xlSetApplConfig` quand un canal FlexRay visible existe :

```powershell
python tools/map_vector_app.py --config config/testbench.yaml
```

Application effective :

```powershell
python tools/map_vector_app.py --config config/testbench.yaml --apply
```

Si plusieurs canaux FlexRay sont visibles :

```powershell
python tools/map_vector_app.py --config config/testbench.yaml --channel-index 7 --app-channel 0 --apply
```

Limite :
- ce script ne peut mapper une application que si `vxlapi` voit deja au moins un canal FlexRay ;
- si `channelCount=0`, il n y a rien a mapper.

## Architecture actuelle
- `conftest.py` : charge et valide `testbench.yaml`, puis prepare les fixtures pytest
- `src/eco_mode_harness.py` : couche ECO directe
- `src/tests/test_eco_mode_acceptance.py` : scenario d acceptation
- `src/tests/test_eco_mode_rejection.py` : scenarios de rejet
- `config/testbench.yaml` : configuration unique du banc

## Modifications realisees
- suppression de l ancienne pile `netio` et des anciens backends locaux devenus orphelins
- ajout de `src/eco_mode_harness.py` pour piloter l injection et la lecture FlexRay
- utilisation de `flexray-vector-lib` pour encoder et transmettre les signaux des scenarios ECO
- ajout du wheel `vendor/flexray_vector_lib-0.1.0-py3-none-any.whl` comme dependance du projet
- ajout d une extension locale `ObservableVectorXLBackend` pour lire les trames RX, car la librairie externe ne fournit pas encore d API de reception
- correction du backend Vector XL dans la wheel :
  resolution du vrai `channelMask` via le driver, tentative `XL_INTERFACE_VERSION_V4` puis repli `V3`, et demande explicite du droit d initialisation
- suppression du chargement dynamique par chemin source dans `conftest.py`
- nettoyage du bloc `buses.flexray_pt` pour retirer les cles legacy non utilisees
- mise a jour de `requirements.txt` avec `pydantic`, requis par la librairie externe
- reecriture de la documentation pour refleter le nouveau chemin d execution

## Limites connues
- la librairie externe est utilisee pour l injection ; la reception repose sur une extension locale du backend Vector XL
- si aucun canal FlexRay n est visible dans le XL Driver sur la machine, les tests ne peuvent pas demarrer meme si le code Python est correct
