# eco-mode-testVN7610

Suite de tests ECO mode en **hardware direct VN7610 FlexRay** avec l'architecture `netio` conservee.
Un mode **emulator GUI sans carte** est aussi disponible.

## Ce qui est implemente
- `src/vector_xl.py`
  - wrapper `ctypes` bas niveau sur `vxlapi64.dll`
  - ouverture/fermeture driver et port
  - activation/desactivation du channel
  - emission/reception des evenements FlexRay
- `src/fibex_parser.py`
  - parsing FIBEX XML via `xml.etree.ElementTree`
  - extraction cluster + frames + signaux
- `src/signal_codec.py`
  - encode/decode bit a bit little-endian
  - conversion physique <-> brut (factor/offset)
- `src/flexrayInjector.py`
  - configuration du noeud A
  - calcul de cycle par `time.perf_counter()`
  - envoi uniquement quand `(cycle_index - base_cycle) % repetition == 0`

## Architecture conservee
- `src/netio/bus.py`: abstractions `BusAdapter`, `RawFrame`, registre adaptateurs
- `src/netio/flexray_vector_adapter.py`: facade `kind: flexray_vector`
- `src/netio/fibex_codec.py`: codec FIBEX branche sur `fibex_parser` + `signal_codec`
- `src/netio/signal_io.py`: envoi/lecture des signaux
- `src/netio/vcu_api.py`: orchestration metier ECO
- `src/tests/`: tests fonctionnels ECO + tests unitaires parser/codec/scheduling

## FIBEX fourni
- `fibex/fibex.xml`
  - cluster FlexRay: `cluster_flexray_pt`
  - channels reseau: `FR_CHANNEL_A` et `FR_CHANNEL_B`
  - frames/signaux alignes avec `config/testbench.yaml` et les tests ECO

## Configuration
Fichier principal: `config/testbench.yaml`.

Points a verifier avant lancement sur banc reel:
- `buses.flexray_pt.app_name` / `app_channel` (Vector Hardware Config)
- `channel_index` si `use_appl_config: false`
- coherence des noms de frame/signal avec votre FIBEX cible

Guide de depannage erreurs Vector/XL:
- `DEPANNAGE_VECTOR_CALCULATEUR.md`

## Installation
```powershell
python -m pip install -r requirements.txt
```

## Execution
Execution complete:
```powershell
python run_tests.py --config config/testbench.yaml --debug
```

Execution sans carte (emulator GUI):
1. Terminal A:
```powershell
python emulator/gui_emulator.py --fibex fibex/fibex.xml --cluster cluster_flexray_pt
```
2. Terminal B:
```powershell
python run_tests.py --config config/testbench_emulator.yaml --debug
```

Execution unitaire (sans hardware):
```powershell
python -m pytest -q src/tests/test_signal_codec.py src/tests/test_fibex_parser.py src/tests/test_fibex_codec.py src/tests/test_flexray_injector_schedule.py src/tests/test_emulator_logic.py
```

## Nettoyage effectue
Suppression des composants devenus inutiles:
- anciens backends `vector_flexray_backend.py` / `vn7610_flexray_backend.py`
- ancien parseur `flexray_fibex.py`
- anciens FIBEX examples non FlexRay
- ancienne doc FIBEX et assets associes
