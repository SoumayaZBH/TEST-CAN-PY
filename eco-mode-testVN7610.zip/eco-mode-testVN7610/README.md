# eco-mode-testVN7610

Application de test ECO mode, basee sur FIBEX, avec architecture identique a `eco_mode-tests2`
mais executee uniquement en **hardware direct** via **Vector VN7610 FlexRay**.

## Portee
- Aucun emulateur UDP.
- Aucun bus CAN/LIN dans la config de test.
- Un seul bus logique: `flexray_pt`.
- Backend dedie VN7610: `vn7610_flexray_backend.VN7610FlexRayBackend`.

## Prerequis
- Windows 11.
- Python 3.10+ (3.11+ recommande).
- Vector XL Driver installe (`vxlapi.dll` accessible).
- Interface Vector VN7610 connectee en USB.
- Reseau FlexRay actif (banc/ECU) + FIBEX valide du reseau cible.

## Installation
Depuis `eco-mode-testVN7610/`:

```powershell
python -m pip install -r requirements.txt
```

## Configuration hardware
Fichier principal: `config/testbench.yaml`.

Champs a verifier avant lancement:
- `fibex.path`: chemin FIBEX reel.
- `fibex.clusters.flexray_pt`: nom exact du cluster FlexRay.
- `buses.flexray_pt.channel_index`: index global du canal VN7610.
- `buses.flexray_pt.cluster`: cluster FlexRay utilise par le backend.
- `signals.*`: noms frame/signal strictement alignes avec le FIBEX.

Notes:
- Le backend dedie force `hw_type = VN7610`.
- `use_appl_config: true` permet d utiliser le mapping Vector Hardware Config.

## Mapping Vector Hardware Config
Dans Vector Hardware Config:
1. Creer/Verifier l application `eco_mode_testVN7610`.
2. Assigner `app_channel = 0` au canal FlexRay du VN7610.
3. Noter le `channel_index` global (utilise dans `config/testbench.yaml`).

## Lancement des tests
Execution standard:

```powershell
python run_tests.py --config config/testbench.yaml --debug
```

Execution pytest directe:

```powershell
python -m pytest -q --config config/testbench.yaml --eco-debug -s
```

Rapports generes dans `reports/`:
- `reports/report.html`
- `reports/junit.xml`
- `reports/debug.log` (si `--debug`)

## Architecture conservee
- `src/netio/bus.py`: abstractions `BusAdapter`, `RawFrame`, registre d adaptateurs.
- `src/netio/flexray_vector_adapter.py`: facade adaptateur `kind: flexray_vector`.
- `src/vector_flexray_backend.py`: backend Vector XL generique FlexRay.
- `src/vn7610_flexray_backend.py`: specialisation stricte VN7610.
- `src/netio/fibex_codec.py`: encodage/decodage signaux depuis FIBEX.
- `src/netio/signal_io.py`: IO signaux multi-trames.
- `src/netio/vcu_api.py`: orchestration ECO (preconditions, requete, verdict).
- `src/tests/`: meme logique de tests acceptation/rejet.

## Backend VN7610 dedie
Le backend `VN7610FlexRayBackend`:
- force le `hw_type` VN7610,
- applique des defaults safe (`channel_mask`, `tx_mode`, `app_name`),
- valide les champs critiques (`fibex_path`, `cluster`, selection de canal),
- reutilise le backend XL generique pour TX/RX et configuration de cluster.

## Aucune execution emulateur
Ce projet est concu pour attaquer directement la carte via VN7610.
Les anciens fichiers d emulateur et configs UDP ont ete retires.
