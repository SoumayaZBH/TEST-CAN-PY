"""Couche ECO directe pour les tests FlexRay VN7610, sans netio."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Mapping, Optional, Tuple, Union
import ctypes
import logging
import time

import canmatrix.formats

from flexray_fibex import load_flexray_canmatrix
from flexray_vector_lib.api import FlexRayInjector
from flexray_vector_lib.encoding import encode_signal_into_payload
from flexray_vector_lib.fibex import resolve_signal
from flexray_vector_lib.models import TransmittedFrame
from flexray_vector_lib.vector.backend import VectorXLBackend, XL_SUCCESS

SignalValue = Union[int, float, bool]

LOGGER = logging.getLogger(__name__)

XL_ERR_QUEUE_IS_EMPTY = 10
XL_FR_RX_FRAME = 0x0081
XL_FR_TX_MODE_CYCLIC = 0x01
XL_FR_TX_MODE_SINGLE_SHOT = 0x02
XL_FR_FRAMEFLAG_REQ_TXACK = 0x0020
XL_FR_MAX_DATA_LENGTH = 254


@dataclass(frozen=True)
class TimingCfg:
    """Valeurs de temporisation utilisees par les scenarios ECO."""

    precondition_hold_ms: int
    request_hold_ms: int
    acceptance_timeout_ms: int

    @property
    def precondition_hold_s(self) -> float:
        return self.precondition_hold_ms / 1000.0

    @property
    def request_hold_s(self) -> float:
        return self.request_hold_ms / 1000.0

    @property
    def acceptance_timeout_s(self) -> float:
        return self.acceptance_timeout_ms / 1000.0


@dataclass(frozen=True)
class SignalBinding:
    """Reference logique vers un signal du FIBEX."""

    bus: str
    frame: str
    signal: str


@dataclass(frozen=True)
class ReceivedFlexRayFrame:
    """Trame recue depuis le bus FlexRay."""

    slot_id: int
    data: bytes
    timestamp: float


@dataclass(frozen=True)
class FrameRef:
    """Metadonnees de trame resolues depuis le FIBEX."""

    name: str
    frame_id: int
    is_extended_id: bool
    frame: object


class FlexRayFrameCodec:
    """Decoder minimal des trames FlexRay a partir du FIBEX."""

    def __init__(self, fibex_path: Path, bus_clusters: Optional[Dict[str, str]] = None) -> None:
        fibex_path = Path(fibex_path)
        if not fibex_path.is_file():
            raise FileNotFoundError(f"Fichier FIBEX introuvable: {fibex_path}")
        self._dbs: Dict[str, object] = {}
        try:
            self._dbs.update(canmatrix.formats.loadp(str(fibex_path), import_type="fibex"))
        except Exception as exc:
            LOGGER.warning(
                "Chargement canmatrix natif du FIBEX impossible pour %s, bascule vers le decodeur FlexRay local: %s: %s",
                fibex_path,
                type(exc).__name__,
                exc,
            )
        flexray_dbs = load_flexray_canmatrix(fibex_path)
        if flexray_dbs:
            for name, db in flexray_dbs.items():
                self._dbs[name] = db
        if not self._dbs:
            raise ValueError("Chargement FIBEX echoue ou aucun cluster retourne")
        self._bus_clusters = bus_clusters or {}
        self._frames_by_name: Dict[str, Dict[str, FrameRef]] = {}
        self._frames_by_id: Dict[str, Dict[int, FrameRef]] = {}

    def decode(self, bus: str, frame_id: int, data: bytes) -> Optional[Tuple[str, Dict[str, SignalValue]]]:
        """Decoder une trame brute en nom de trame et signaux."""

        frame_ref = self._get_frame_by_id(bus, frame_id)
        if frame_ref is None:
            return None
        decoded = frame_ref.frame.decode(data)
        signals: Dict[str, SignalValue] = {}
        for name, value in decoded.items():
            if hasattr(value, "phys_value"):
                signals[name] = value.phys_value
            elif hasattr(value, "raw_value"):
                signals[name] = value.raw_value
            else:
                signals[name] = value
        return frame_ref.name, signals

    def _get_frame_by_id(self, bus: str, frame_id: int) -> Optional[FrameRef]:
        if bus not in self._frames_by_id:
            self._prime_bus_cache(bus)
        return self._frames_by_id[bus].get(frame_id)

    def _prime_bus_cache(self, bus: str) -> None:
        cluster = self._resolve_cluster(bus)
        matrix = self._dbs[cluster]
        by_name: Dict[str, FrameRef] = {}
        by_id: Dict[int, FrameRef] = {}
        for name, frame in matrix.frames_dict_name.items():
            frame_id, is_extended = _frame_identifier(frame)
            ref = FrameRef(name=name, frame_id=frame_id, is_extended_id=is_extended, frame=frame)
            by_name[name] = ref
            by_id[frame_id] = ref
        self._frames_by_name[bus] = by_name
        self._frames_by_id[bus] = by_id
        LOGGER.info("Cache FIBEX pret pour le bus '%s' (cluster '%s').", bus, cluster)

    def _resolve_cluster(self, bus: str) -> str:
        if bus in self._bus_clusters:
            cluster = self._bus_clusters[bus]
            if cluster not in self._dbs:
                raise KeyError(f"Cluster '{cluster}' introuvable dans le FIBEX")
            return cluster
        if len(self._dbs) == 1:
            return next(iter(self._dbs.keys()))
        raise KeyError(
            "Plusieurs clusters trouves dans le FIBEX. "
            "Ajouter fibex.clusters.<bus> dans config/testbench.yaml."
        )


class ObservableVectorXLBackend(VectorXLBackend):
    """Extension du backend Vector XL pour permettre la lecture des trames RX."""

    def open(self) -> None:
        LOGGER.debug(
            "XL open requested: app=%s channel_index=%s rx_queue_size=%s",
            self.app_name,
            self.channel_index,
            self.rx_queue_size,
        )
        super().open()
        LOGGER.debug("XL open completed: is_open=%s", getattr(self, "_is_open", None))

    def configure_cluster(self, cluster) -> None:
        LOGGER.debug("XL configure_cluster requested: cluster=%s", getattr(cluster, "name", cluster))
        super().configure_cluster(cluster)
        LOGGER.debug(
            "XL configure_cluster completed: cluster=%s permission_mask=0x%X access_mask=0x%X",
            getattr(cluster, "name", cluster),
            int(getattr(self, "_permission_mask").value),
            int(getattr(self, "_access_mask").value),
        )

    def set_startup_mode(self, mode) -> None:
        LOGGER.debug("XL set_startup_mode: mode=%s", mode)
        super().set_startup_mode(mode)

    def activate_channel(self, *, reset_clock: bool = True) -> None:
        LOGGER.debug("XL activate_channel requested: reset_clock=%s", reset_clock)
        super().activate_channel(reset_clock=reset_clock)
        LOGGER.debug("XL activate_channel completed: active=%s", getattr(self, "_is_active", None))

    def transmit(self, frame: TransmittedFrame) -> None:
        LOGGER.debug(
            "XL transmit requested: cluster=%s frame=%s slot=%s base_cycle=%s repetition=%s channel=%s tx_mode=%s flags=0x%X len=%s",
            frame.cluster_name,
            frame.frame_name,
            frame.slot_id,
            frame.base_cycle,
            frame.repetition,
            frame.channel,
            frame.tx_mode,
            frame.flags,
            len(frame.payload),
        )
        super().transmit(frame)
        LOGGER.debug("XL transmit completed: frame=%s", frame.frame_name)

    def close(self) -> None:
        LOGGER.debug("XL close requested")
        super().close()
        LOGGER.debug("XL close completed")

    def receive_frame(self, timeout: Optional[float] = None) -> Optional[ReceivedFlexRayFrame]:
        """Lire la prochaine trame FlexRay recue sur le port actuel."""

        self.open()
        library = self._library_or_raise()
        self._ensure_receive_binding(library)

        end_time = None if timeout is None else time.monotonic() + max(timeout, 0.0)
        event = _XLfrRxEvent()
        event.size = ctypes.sizeof(_XLfrRxEvent)

        while True:
            status = library.xlFrReceive(self._port_handle, ctypes.byref(event))
            if status == XL_SUCCESS:
                if event.tag != XL_FR_RX_FRAME:
                    LOGGER.debug("XL receive ignored non-RX event: tag=0x%X", int(event.tag))
                    continue
                length = min(int(event.tagData.frRxFrame.payloadLength) * 2, XL_FR_MAX_DATA_LENGTH)
                LOGGER.debug(
                    "XL receive completed: slot=%s cycle=%s len=%s",
                    int(event.tagData.frRxFrame.slotID),
                    int(event.tagData.frRxFrame.cycleCount),
                    length,
                )
                return ReceivedFlexRayFrame(
                    slot_id=int(event.tagData.frRxFrame.slotID),
                    data=bytes(event.tagData.frRxFrame.data[:length]),
                    timestamp=time.time(),
                )
            if status == XL_ERR_QUEUE_IS_EMPTY:
                if end_time is None or time.monotonic() >= end_time:
                    return None
                time.sleep(0.001)
                continue
            library._check(status, "xlFrReceive")

    def drain_receive_queue(self) -> int:
        """Vider la file RX courante et retourner le nombre de trames jetees."""

        drained = 0
        while self.receive_frame(timeout=0.0) is not None:
            drained += 1
        if drained:
            LOGGER.debug("File RX videe: %s trame(s) ignoree(s).", drained)
        return drained

    def _ensure_receive_binding(self, library: object) -> None:
        if hasattr(library, "xlFrReceive"):
            return
        library.xlFrReceive = library._dll.xlFrReceive
        library.xlFrReceive.argtypes = [ctypes.c_long, ctypes.POINTER(_XLfrRxEvent)]
        library.xlFrReceive.restype = ctypes.c_short


class ConfigurableFlexRayInjector(FlexRayInjector):
    """Injecteur FlexRay configure a partir des options du testbench."""

    def __init__(
        self,
        channel_index: int,
        app_name: str = "PyFlexRayInjector",
        *,
        app_channel: Optional[int] = None,
        rx_queue_size: int = 4096,
        interface_version: Optional[int] = None,
        backend: Optional[ObservableVectorXLBackend] = None,
        tx_mode: int = XL_FR_TX_MODE_CYCLIC,
        tx_flags: int = 0,
        default_channel: Optional[str] = None,
    ) -> None:
        super().__init__(
            channel_index=channel_index,
            app_name=app_name,
            app_channel=app_channel,
            rx_queue_size=rx_queue_size,
            interface_version=interface_version,
            backend=backend,
        )
        self._configured_tx_mode = int(tx_mode)
        self._configured_tx_flags = int(tx_flags)
        self._configured_channel = default_channel

    def inject_signal(
        self,
        *,
        signal_name: str,
        value: Union[float, int],
        frame_name: Optional[str] = None,
        cluster_name: Optional[str] = None,
    ) -> bytes:
        """Injecter un signal en reappliquant la configuration TX du testbench."""

        network = self._require_network()
        cluster, frame, signal = resolve_signal(
            network,
            signal_name=signal_name,
            frame_name=frame_name,
            cluster_name=cluster_name,
            default_cluster_name=self._default_cluster_name,
        )
        self.prepare_cluster(cluster.name, mode=self._startup_mode, activate=True)

        payload_key = (cluster.name, frame.name)
        payload = self._frame_images.setdefault(payload_key, bytearray(frame.byte_length))
        encode_signal_into_payload(payload, signal, value)
        LOGGER.debug(
            "Signal prepare pour injection: signal=%s frame=%s cluster=%s start_bit=%s bit_length=%s value=%s",
            signal_name,
            frame.name,
            cluster.name,
            signal.start_bit,
            signal.encoding.bit_length,
            value,
        )

        transmitted_frame = TransmittedFrame(
            cluster_name=cluster.name,
            frame_name=frame.name,
            slot_id=frame.triggering.slot_id,
            base_cycle=frame.triggering.base_cycle,
            repetition=frame.triggering.repetition,
            payload=bytes(payload),
            channel=frame.triggering.channel or self._configured_channel,
            flags=self._configured_tx_flags,
            tx_mode=self._configured_tx_mode,
        )
        self._backend.transmit(transmitted_frame)
        LOGGER.info(
            "Signal injecte '%s'=%s dans %s/%s.",
            signal_name,
            value,
            cluster.name,
            frame.name,
        )
        return bytes(payload)


class FlexRaySignalMonitor:
    """Surveille les trames FlexRay et maintient un cache des signaux recus."""

    def __init__(self, backend: ObservableVectorXLBackend, codec: FlexRayFrameCodec, bus_name: str) -> None:
        self._backend = backend
        self._codec = codec
        self._bus_name = bus_name
        self._cache: Dict[Tuple[str, str, str], SignalValue] = {}

    def pump(self, duration_s: float) -> None:
        """Lire les trames durant une fenetre de temps et rafraichir le cache."""

        end_time = time.monotonic() + max(0.0, duration_s)
        while time.monotonic() < end_time:
            remaining = end_time - time.monotonic()
            frame = self._backend.receive_frame(timeout=min(0.05, max(0.0, remaining)))
            if frame is None:
                continue
            decoded = self._codec.decode(self._bus_name, frame.slot_id, frame.data)
            if decoded is None:
                continue
            frame_name, signals = decoded
            for name, value in signals.items():
                self._cache[(self._bus_name, frame_name, name)] = value
            LOGGER.debug("Signaux recus sur %s/%s.", self._bus_name, frame_name)

    def reset(self) -> None:
        """Vider le cache local et la file RX du driver."""

        self._cache.clear()
        LOGGER.debug("Cache des signaux RX reinitialise pour bus=%s", self._bus_name)
        self._backend.drain_receive_queue()

    def get_signal(self, ref: SignalBinding) -> Optional[SignalValue]:
        """Retourner la derniere valeur recue pour un signal logique."""

        return self._cache.get((ref.bus, ref.frame, ref.signal))


class EcoModeController:
    """Facade de scenario ECO utilisant flexray-vector-lib pour l'injection."""

    def __init__(
        self,
        injector: ConfigurableFlexRayInjector,
        monitor: FlexRaySignalMonitor,
        signal_map: Dict[str, SignalBinding],
        timing: TimingCfg,
    ) -> None:
        self._injector = injector
        self._monitor = monitor
        self._signal_map = signal_map
        self._timing = timing

    @classmethod
    def from_config(cls, cfg: Mapping[str, object]) -> "EcoModeController":
        """Construire un controleur complet a partir du testbench YAML."""

        fibex_cfg = _as_mapping(cfg.get("fibex"), "fibex")
        buses_cfg = _as_mapping(cfg.get("buses"), "buses")
        signals_cfg = _as_mapping(cfg.get("signals"), "signals")
        timing_cfg = _as_mapping(cfg.get("timing_ms"), "timing_ms")

        bus_names = {str(entry["bus"]) for entry in signals_cfg.values()}
        if len(bus_names) != 1:
            raise ValueError("La couche ECO directe supporte un seul bus logique dans ce projet.")
        bus_name = next(iter(bus_names))

        bus_cfg = _as_mapping(buses_cfg.get(bus_name), f"buses.{bus_name}")
        fibex_path = Path(str(fibex_cfg["path"]))
        clusters_cfg = fibex_cfg.get("clusters")
        bus_clusters = dict(clusters_cfg) if isinstance(clusters_cfg, dict) else {}
        default_cluster = (
            bus_clusters.get(bus_name)
            or bus_cfg.get("cluster")
            or bus_cfg.get("cluster_name")
        )

        channel_index = int(bus_cfg["channel_index"])
        app_name = str(bus_cfg.get("app_name", "eco_mode_testVN7610"))
        app_channel_raw = bus_cfg.get("app_channel")
        app_channel = int(app_channel_raw) if app_channel_raw is not None else None
        rx_queue_size = int(bus_cfg.get("rx_queue_size", 4096))
        interface_version_raw = bus_cfg.get("interface_version")
        interface_version = int(interface_version_raw) if interface_version_raw is not None else None
        tx_mode = _tx_mode_from_text(bus_cfg.get("tx_mode"))
        tx_flags = XL_FR_FRAMEFLAG_REQ_TXACK if bool(bus_cfg.get("tx_ack", False)) else 0
        default_channel = str(bus_cfg.get("channel_mask", "A"))
        LOGGER.info(
            "Creation EcoModeController: bus=%s app=%s channel_index=%s app_channel=%s interface_version=%s fibex=%s cluster=%s tx_mode=%s tx_flags=0x%X",
            bus_name,
            app_name,
            channel_index,
            app_channel,
            interface_version,
            fibex_path,
            default_cluster,
            tx_mode,
            tx_flags,
        )

        backend = ObservableVectorXLBackend(
            channel_index=channel_index,
            app_name=app_name,
            rx_queue_size=rx_queue_size,
            app_channel=app_channel,
            interface_version=interface_version,
        )
        injector = ConfigurableFlexRayInjector(
            channel_index=channel_index,
            app_name=app_name,
            app_channel=app_channel,
            rx_queue_size=rx_queue_size,
            interface_version=interface_version,
            backend=backend,
            tx_mode=tx_mode,
            tx_flags=tx_flags,
            default_channel=default_channel,
        )
        injector.load_fibex(fibex_path, default_cluster_name=default_cluster)

        signal_map = {
            logical_name: SignalBinding(
                bus=str(entry["bus"]),
                frame=str(entry["frame"]),
                signal=str(entry["signal"]),
            )
            for logical_name, entry in signals_cfg.items()
        }
        timing = TimingCfg(
            precondition_hold_ms=int(timing_cfg["precondition_hold"]),
            request_hold_ms=int(timing_cfg["request_hold"]),
            acceptance_timeout_ms=int(timing_cfg["acceptance_timeout"]),
        )
        codec = FlexRayFrameCodec(fibex_path, bus_clusters=bus_clusters or None)
        monitor = FlexRaySignalMonitor(backend, codec, bus_name)
        return cls(injector=injector, monitor=monitor, signal_map=signal_map, timing=timing)

    def reset_observations(self) -> None:
        """Nettoyer les observations precedentes avant un nouveau scenario."""

        self._monitor.reset()

    def apply_preconditions(self, values: Mapping[str, SignalValue]) -> None:
        """Injecter les preconditions puis laisser le bus se stabiliser."""

        LOGGER.info("Application des preconditions ECO: %s", dict(values))
        self._send_logical_values(values)
        self._monitor.pump(self._timing.precondition_hold_s)

    def request_eco(self) -> None:
        """Envoyer la requete ECO selon les mappings du testbench."""

        LOGGER.info("Emission de la requete ECO")
        self._send_logical_values(
            {
                "driver_mode_req_valid": 1,
                "driver_mode_request": 1,
            }
        )
        self._monitor.pump(self._timing.request_hold_s)

    def wait_for_eco_result(self) -> Dict[str, Optional[SignalValue]]:
        """Attendre les retours VCU et retourner les dernieres valeurs connues."""

        end_time = time.monotonic() + self._timing.acceptance_timeout_s
        while time.monotonic() < end_time:
            self._monitor.pump(0.1)
            active = self._get_optional("driving_mode_active")
            accepted = self._get_optional("drivemode_accepted")
            reject = self._get_optional("drivemode_reject_reason")
            if active == 1 or accepted == 0 or reject is not None:
                break
        result = {
            "active_mode": self._get_optional("driving_mode_active"),
            "accepted": self._get_optional("drivemode_accepted"),
            "reject_reason": self._get_optional("drivemode_reject_reason"),
        }
        LOGGER.info("Resultat ECO: %s", result)
        return result

    def close(self) -> None:
        """Liberer le backend FlexRay partage par l injecteur et le moniteur."""

        LOGGER.debug("Fermeture du controleur ECO")
        self._injector.close()

    def _send_logical_values(self, values: Mapping[str, SignalValue]) -> None:
        for logical_name, value in values.items():
            binding = self._signal_map.get(logical_name)
            if binding is None:
                raise KeyError(f"Mapping manquant pour le signal '{logical_name}'")
            LOGGER.debug(
                "Envoi signal logique: logical=%s bus=%s frame=%s signal=%s value=%s",
                logical_name,
                binding.bus,
                binding.frame,
                binding.signal,
                value,
            )
            self._injector.inject_signal(
                signal_name=binding.signal,
                frame_name=binding.frame,
                value=value,
            )

    def _get_optional(self, logical_name: str) -> Optional[SignalValue]:
        binding = self._signal_map.get(logical_name)
        if binding is None:
            return None
        return self._monitor.get_signal(binding)


class _XLFrRxFrame(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("flags", ctypes.c_uint16),
        ("headerCRC", ctypes.c_uint16),
        ("slotID", ctypes.c_uint16),
        ("cycleCount", ctypes.c_ubyte),
        ("payloadLength", ctypes.c_ubyte),
        ("data", ctypes.c_ubyte * XL_FR_MAX_DATA_LENGTH),
    ]


class _XLFrRxTagData(ctypes.Union):
    _pack_ = 8
    _fields_ = [("frRxFrame", _XLFrRxFrame), ("raw", ctypes.c_ubyte * (512 - 32))]


class _XLfrRxEvent(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("size", ctypes.c_uint32),
        ("tag", ctypes.c_uint16),
        ("channelIndex", ctypes.c_uint16),
        ("userHandle", ctypes.c_uint32),
        ("flagsChip", ctypes.c_uint16),
        ("reserved", ctypes.c_uint16),
        ("timeStamp", ctypes.c_uint64),
        ("timeStampSync", ctypes.c_uint64),
        ("tagData", _XLFrRxTagData),
    ]


def _as_mapping(value: object, name: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"La section '{name}' doit etre un mapping")
    return value


def _frame_identifier(frame: object) -> Tuple[int, bool]:
    arb = getattr(frame, "arbitration_id", None)
    if arb is not None and getattr(arb, "id", None):
        return int(arb.id), bool(getattr(arb, "extended", False))
    header_id = getattr(frame, "header_id", None)
    if header_id is not None:
        return int(header_id), False
    raise ValueError("La trame n a ni arbitration_id ni header_id")


def _tx_mode_from_text(raw_value: object) -> int:
    if raw_value is None:
        return XL_FR_TX_MODE_CYCLIC
    value = str(raw_value).strip().lower()
    if value in {"single", "single_shot", "oneshot"}:
        return XL_FR_TX_MODE_SINGLE_SHOT
    return XL_FR_TX_MODE_CYCLIC
