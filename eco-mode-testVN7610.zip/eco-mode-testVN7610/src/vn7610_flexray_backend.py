"""Backend FlexRay dedie a Vector VN7610."""

from __future__ import annotations

from typing import Any, Mapping

from netio.bus import BusSpec
from vector_flexray_backend import XL_HWTYPE_VN7610, VectorFlexRayBackend

_VN7610_ALIAS = {
    "81",
    "VN7610",
    "VN7610A",
    "XL_HWTYPE_VN7610",
}


def normalize_vn7610_params(params: Mapping[str, Any]) -> dict[str, Any]:
    """Appliquer des garde-fous VN7610 et valider la config requise."""

    merged = dict(params)

    merged.setdefault("app_name", "eco_mode_testVN7610")
    merged.setdefault("app_channel", 0)
    merged.setdefault("channel_mask", "A")
    merged.setdefault("tx_mode", "cyclic")
    merged.setdefault("tx_ack", False)
    merged.setdefault("use_appl_config", True)

    user_hw_type = merged.get("hw_type")
    if user_hw_type is not None:
        normalized_hw = str(user_hw_type).strip().upper()
        if normalized_hw not in _VN7610_ALIAS:
            raise RuntimeError(
                "VN7610FlexRayBackend: hw_type doit cibler VN7610 "
                "(VN7610, XL_HWTYPE_VN7610 ou 81)."
            )
    merged["hw_type"] = XL_HWTYPE_VN7610

    if not merged.get("fibex_path"):
        raise RuntimeError("VN7610FlexRayBackend: fournir 'fibex_path' dans la config du bus.")

    if not (merged.get("cluster") or merged.get("cluster_name")):
        raise RuntimeError("VN7610FlexRayBackend: fournir 'cluster' (ou 'cluster_name').")

    channel_selected = merged.get("channel_index") is not None or merged.get("channel") is not None
    if not channel_selected and not bool(merged.get("use_appl_config", True)):
        raise RuntimeError(
            "VN7610FlexRayBackend: fournir 'channel_index' (ou activer use_appl_config=true)."
        )

    return merged


class VN7610FlexRayBackend(VectorFlexRayBackend):
    """Backend concret VN7610 qui specialise le backend Vector generique."""

    def __init__(self, spec: BusSpec) -> None:
        normalized = normalize_vn7610_params(spec.params)
        vn_spec = BusSpec(name=spec.name, kind=spec.kind, params=normalized)
        super().__init__(vn_spec)
