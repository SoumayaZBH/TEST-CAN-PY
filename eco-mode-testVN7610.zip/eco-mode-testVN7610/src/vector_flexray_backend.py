"""Backend FlexRay Vector (VN36xx/VN1640A/VN7610) via XL Driver (vxlapi)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional
import ctypes
import logging
import os
import time

import yaml

from netio.bus import BusAdapter, BusSpec, RawFrame
from flexray_fibex import load_flexray_cluster_params, load_flexray_schedule

logger = logging.getLogger(__name__)

# XL constants (from vxlapi.h)
XL_SUCCESS = 0
XL_ERR_QUEUE_IS_EMPTY = 10

XL_BUS_TYPE_FLEXRAY = 0x00000004

XL_INTERFACE_VERSION_V3 = 3
XL_INTERFACE_VERSION_V4 = 4

XL_FR_START_CYCLE = 0x0080
XL_FR_RX_FRAME = 0x0081
XL_FR_TX_FRAME = 0x0082
XL_FR_TXACK_FRAME = 0x0083

XL_FR_TX_MODE_CYCLIC = 0x01
XL_FR_TX_MODE_SINGLE_SHOT = 0x02

XL_FR_CHANNEL_A = 0x01
XL_FR_CHANNEL_B = 0x02
XL_FR_CHANNEL_AB = XL_FR_CHANNEL_A | XL_FR_CHANNEL_B

XL_FR_FRAMEFLAG_REQ_TXACK = 0x0020

# XL hardware types (subset)
XL_HWTYPE_VN3600 = 39
XL_HWTYPE_VN7600 = 41
XL_HWTYPE_VN1640 = 59
XL_HWTYPE_VN7610 = 81
XL_HWTYPE_VN7640 = 102


# ctypes type aliases
XLstatus = ctypes.c_short
XLaccess = ctypes.c_ulonglong
XLportHandle = ctypes.c_long
XLuint64 = ctypes.c_ulonglong


class XLfrClusterConfig(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("busGuardianEnable", ctypes.c_uint),
        ("baudrate", ctypes.c_uint),
        ("busGuardianTick", ctypes.c_uint),
        ("externalClockCorrectionMode", ctypes.c_uint),
        ("gColdStartAttempts", ctypes.c_uint),
        ("gListenNoise", ctypes.c_uint),
        ("gMacroPerCycle", ctypes.c_uint),
        ("gMaxWithoutClockCorrectionFatal", ctypes.c_uint),
        ("gMaxWithoutClockCorrectionPassive", ctypes.c_uint),
        ("gNetworkManagementVectorLength", ctypes.c_uint),
        ("gNumberOfMinislots", ctypes.c_uint),
        ("gNumberOfStaticSlots", ctypes.c_uint),
        ("gOffsetCorrectionStart", ctypes.c_uint),
        ("gPayloadLengthStatic", ctypes.c_uint),
        ("gSyncNodeMax", ctypes.c_uint),
        ("gdActionPointOffset", ctypes.c_uint),
        ("gdDynamicSlotIdlePhase", ctypes.c_uint),
        ("gdMacrotick", ctypes.c_uint),
        ("gdMinislot", ctypes.c_uint),
        ("gdMiniSlotActionPointOffset", ctypes.c_uint),
        ("gdNIT", ctypes.c_uint),
        ("gdStaticSlot", ctypes.c_uint),
        ("gdSymbolWindow", ctypes.c_uint),
        ("gdTSSTransmitter", ctypes.c_uint),
        ("gdWakeupSymbolRxIdle", ctypes.c_uint),
        ("gdWakeupSymbolRxLow", ctypes.c_uint),
        ("gdWakeupSymbolRxWindow", ctypes.c_uint),
        ("gdWakeupSymbolTxIdle", ctypes.c_uint),
        ("gdWakeupSymbolTxLow", ctypes.c_uint),
        ("pAllowHaltDueToClock", ctypes.c_uint),
        ("pAllowPassiveToActive", ctypes.c_uint),
        ("pChannels", ctypes.c_uint),
        ("pClusterDriftDamping", ctypes.c_uint),
        ("pDecodingCorrection", ctypes.c_uint),
        ("pDelayCompensationA", ctypes.c_uint),
        ("pDelayCompensationB", ctypes.c_uint),
        ("pExternOffsetCorrection", ctypes.c_uint),
        ("pExternRateCorrection", ctypes.c_uint),
        ("pKeySlotUsedForStartup", ctypes.c_uint),
        ("pKeySlotUsedForSync", ctypes.c_uint),
        ("pLatestTx", ctypes.c_uint),
        ("pMacroInitialOffsetA", ctypes.c_uint),
        ("pMacroInitialOffsetB", ctypes.c_uint),
        ("pMaxPayloadLengthDynamic", ctypes.c_uint),
        ("pMicroInitialOffsetA", ctypes.c_uint),
        ("pMicroInitialOffsetB", ctypes.c_uint),
        ("pMicroPerCycle", ctypes.c_uint),
        ("pMicroPerMacroNom", ctypes.c_uint),
        ("pOffsetCorrectionOut", ctypes.c_uint),
        ("pRateCorrectionOut", ctypes.c_uint),
        ("pSamplesPerMicrotick", ctypes.c_uint),
        ("pSingleSlotEnabled", ctypes.c_uint),
        ("pWakeupChannel", ctypes.c_uint),
        ("pWakeupPattern", ctypes.c_uint),
        ("pdAcceptedStartupRange", ctypes.c_uint),
        ("pdListenTimeout", ctypes.c_uint),
        ("pdMaxDrift", ctypes.c_uint),
        ("pdMicrotick", ctypes.c_uint),
        ("gdCASRxLowMax", ctypes.c_uint),
        ("gChannels", ctypes.c_uint),
        ("vExternOffsetControl", ctypes.c_uint),
        ("vExternRateControl", ctypes.c_uint),
        ("pChannelsMTS", ctypes.c_uint),
        ("framePresetData", ctypes.c_uint),
        ("reserved", ctypes.c_uint * 15),
    ]


class XLfrMode(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("frMode", ctypes.c_uint),
        ("frStartupAttributes", ctypes.c_uint),
        ("useSelCycle", ctypes.c_ushort),
        ("selCycle", ctypes.c_ushort),
        ("reserved", ctypes.c_uint * 29),
    ]


class XL_FR_RX_FRAME_EV(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("flags", ctypes.c_ushort),
        ("headerCRC", ctypes.c_ushort),
        ("slotID", ctypes.c_ushort),
        ("cycleCount", ctypes.c_ubyte),
        ("payloadLength", ctypes.c_ubyte),
        ("data", ctypes.c_ubyte * 254),
    ]


class XL_FR_TX_FRAME_EV(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("flags", ctypes.c_ushort),
        ("slotID", ctypes.c_ushort),
        ("offset", ctypes.c_ubyte),
        ("repetition", ctypes.c_ubyte),
        ("payloadLength", ctypes.c_ubyte),
        ("txMode", ctypes.c_ubyte),
        ("incrementSize", ctypes.c_ubyte),
        ("incrementOffset", ctypes.c_ubyte),
        ("reserved0", ctypes.c_ubyte),
        ("reserved1", ctypes.c_ubyte),
        ("data", ctypes.c_ubyte * 254),
    ]


class XLfrTagData(ctypes.Union):
    _pack_ = 8
    _fields_ = [
        ("frRxFrame", XL_FR_RX_FRAME_EV),
        ("frTxFrame", XL_FR_TX_FRAME_EV),
        ("raw", ctypes.c_ubyte * (512 - 32)),
    ]


class XLfrEvent(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("size", ctypes.c_uint),
        ("tag", ctypes.c_ushort),
        ("channelIndex", ctypes.c_ushort),
        ("userHandle", ctypes.c_uint),
        ("flagsChip", ctypes.c_ushort),
        ("reserved", ctypes.c_ushort),
        ("timeStamp", XLuint64),
        ("timeStampSync", XLuint64),
        ("tagData", XLfrTagData),
    ]


class VxlApi:
    """Small ctypes wrapper around vxlapi.dll."""

    def __init__(self, dll_path: Optional[str] = None) -> None:
        self._dll = ctypes.WinDLL(dll_path or "vxlapi")
        self._bind()

    def _bind(self) -> None:
        self._dll.xlOpenDriver.restype = XLstatus
        self._dll.xlCloseDriver.restype = XLstatus
        self._dll.xlGetErrorString.restype = ctypes.c_char_p

        self._dll.xlSetApplConfig.argtypes = [
            ctypes.c_char_p,
            ctypes.c_uint,
            ctypes.c_uint,
            ctypes.c_uint,
            ctypes.c_uint,
            ctypes.c_uint,
        ]
        self._dll.xlSetApplConfig.restype = XLstatus

        self._dll.xlGetApplConfig.argtypes = [
            ctypes.c_char_p,
            ctypes.c_uint,
            ctypes.POINTER(ctypes.c_uint),
            ctypes.POINTER(ctypes.c_uint),
            ctypes.POINTER(ctypes.c_uint),
            ctypes.c_uint,
        ]
        self._dll.xlGetApplConfig.restype = XLstatus

        self._dll.xlGetChannelMask.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int]
        self._dll.xlGetChannelMask.restype = XLaccess

        self._dll.xlOpenPort.argtypes = [
            ctypes.POINTER(XLportHandle),
            ctypes.c_char_p,
            XLaccess,
            ctypes.POINTER(XLaccess),
            ctypes.c_uint,
            ctypes.c_uint,
            ctypes.c_uint,
        ]
        self._dll.xlOpenPort.restype = XLstatus

        self._dll.xlClosePort.argtypes = [XLportHandle]
        self._dll.xlClosePort.restype = XLstatus

        self._dll.xlActivateChannel.argtypes = [XLportHandle, XLaccess, ctypes.c_uint, ctypes.c_uint]
        self._dll.xlActivateChannel.restype = XLstatus

        self._dll.xlDeactivateChannel.argtypes = [XLportHandle, XLaccess]
        self._dll.xlDeactivateChannel.restype = XLstatus

        self._dll.xlFrSetConfiguration.argtypes = [XLportHandle, XLaccess, ctypes.POINTER(XLfrClusterConfig)]
        self._dll.xlFrSetConfiguration.restype = XLstatus

        self._dll.xlFrSetMode.argtypes = [XLportHandle, XLaccess, ctypes.POINTER(XLfrMode)]
        self._dll.xlFrSetMode.restype = XLstatus

        self._dll.xlFrInitStartupAndSync.argtypes = [XLportHandle, XLaccess, ctypes.POINTER(XLfrEvent)]
        self._dll.xlFrInitStartupAndSync.restype = XLstatus

        self._dll.xlFrSetTransceiverMode.argtypes = [
            XLportHandle,
            XLaccess,
            ctypes.c_uint,
            ctypes.c_uint,
        ]
        self._dll.xlFrSetTransceiverMode.restype = XLstatus

        self._dll.xlFrReceive.argtypes = [XLportHandle, ctypes.POINTER(XLfrEvent)]
        self._dll.xlFrReceive.restype = XLstatus

        self._dll.xlFrTransmit.argtypes = [XLportHandle, XLaccess, ctypes.POINTER(XLfrEvent)]
        self._dll.xlFrTransmit.restype = XLstatus

    def _status(self, status: int, context: str) -> None:
        if status == XL_SUCCESS:
            return
        err = self._dll.xlGetErrorString(status)
        msg = err.decode("ascii", errors="ignore") if err else "unknown"
        raise RuntimeError(f"{context} failed (0x{status:X}): {msg}")

    def open_driver(self) -> None:
        self._status(self._dll.xlOpenDriver(), "xlOpenDriver")

    def close_driver(self) -> None:
        self._status(self._dll.xlCloseDriver(), "xlCloseDriver")

    def set_appl_config(
        self, app_name: str, app_channel: int, hw_type: int, hw_index: int, hw_channel: int
    ) -> None:
        self._status(
            self._dll.xlSetApplConfig(
                app_name.encode("ascii"), app_channel, hw_type, hw_index, hw_channel, XL_BUS_TYPE_FLEXRAY
            ),
            "xlSetApplConfig",
        )

    def get_appl_config(self, app_name: str, app_channel: int) -> tuple[int, int, int]:
        hw_type = ctypes.c_uint()
        hw_index = ctypes.c_uint()
        hw_channel = ctypes.c_uint()
        self._status(
            self._dll.xlGetApplConfig(
                app_name.encode("ascii"),
                app_channel,
                ctypes.byref(hw_type),
                ctypes.byref(hw_index),
                ctypes.byref(hw_channel),
                XL_BUS_TYPE_FLEXRAY,
            ),
            "xlGetApplConfig",
        )
        return int(hw_type.value), int(hw_index.value), int(hw_channel.value)

    def get_channel_mask(self, hw_type: int, hw_index: int, hw_channel: int) -> int:
        return int(self._dll.xlGetChannelMask(hw_type, hw_index, hw_channel))

    def open_port(
        self, app_name: str, access_mask: int, rx_queue_size: int, interface_version: int
    ) -> tuple[XLportHandle, int]:
        port_handle = XLportHandle()
        permission_mask = XLaccess(access_mask)
        status = self._dll.xlOpenPort(
            ctypes.byref(port_handle),
            app_name.encode("ascii"),
            XLaccess(access_mask),
            ctypes.byref(permission_mask),
            rx_queue_size,
            interface_version,
            XL_BUS_TYPE_FLEXRAY,
        )
        self._status(status, "xlOpenPort")
        return port_handle, int(permission_mask.value)

    def close_port(self, port_handle: XLportHandle) -> None:
        self._status(self._dll.xlClosePort(port_handle), "xlClosePort")

    def activate_channel(self, port_handle: XLportHandle, access_mask: int) -> None:
        self._status(
            self._dll.xlActivateChannel(port_handle, XLaccess(access_mask), XL_BUS_TYPE_FLEXRAY, 0),
            "xlActivateChannel",
        )

    def deactivate_channel(self, port_handle: XLportHandle, access_mask: int) -> None:
        self._status(
            self._dll.xlDeactivateChannel(port_handle, XLaccess(access_mask)),
            "xlDeactivateChannel",
        )

    def fr_set_configuration(self, port_handle: XLportHandle, access_mask: int, cfg: XLfrClusterConfig) -> None:
        self._status(
            self._dll.xlFrSetConfiguration(port_handle, XLaccess(access_mask), ctypes.byref(cfg)),
            "xlFrSetConfiguration",
        )

    def fr_set_mode(self, port_handle: XLportHandle, access_mask: int, mode: XLfrMode) -> None:
        self._status(
            self._dll.xlFrSetMode(port_handle, XLaccess(access_mask), ctypes.byref(mode)),
            "xlFrSetMode",
        )

    def fr_init_startup_and_sync(
        self, port_handle: XLportHandle, access_mask: int, event: XLfrEvent
    ) -> None:
        self._status(
            self._dll.xlFrInitStartupAndSync(port_handle, XLaccess(access_mask), ctypes.byref(event)),
            "xlFrInitStartupAndSync",
        )

    def fr_set_transceiver_mode(
        self, port_handle: XLportHandle, access_mask: int, fr_channel: int, mode: int
    ) -> None:
        self._status(
            self._dll.xlFrSetTransceiverMode(port_handle, XLaccess(access_mask), fr_channel, mode),
            "xlFrSetTransceiverMode",
        )

    def fr_receive(self, port_handle: XLportHandle, event: XLfrEvent) -> int:
        return int(self._dll.xlFrReceive(port_handle, ctypes.byref(event)))

    def fr_transmit(self, port_handle: XLportHandle, access_mask: int, event: XLfrEvent) -> None:
        self._status(
            self._dll.xlFrTransmit(port_handle, XLaccess(access_mask), ctypes.byref(event)),
            "xlFrTransmit",
        )


@dataclass
class _ScheduleInfo:
    offset: int
    repetition: int
    channel: int


class VectorFlexRayBackend(BusAdapter):
    """Backend Vector FlexRay (XL Driver)."""

    def __init__(self, spec: BusSpec) -> None:
        super().__init__(spec)
        self._params = spec.params
        self._vxl = VxlApi(self._params.get("vxlapi_dll"))
        self._vxl.open_driver()

        app_name = str(self._params.get("app_name", "eco_mode_tests2"))
        app_channel = int(self._params.get("app_channel", 0))

        hw_type, hw_index, hw_channel = self._resolve_hw_config(app_name, app_channel)
        if self._params.get("set_app_config", False) and hw_type is not None:
            self._vxl.set_appl_config(app_name, app_channel, hw_type, hw_index, hw_channel)

        access_mask = self._resolve_access_mask(hw_type, hw_index, hw_channel)
        self._access_mask = access_mask
        interface_version = int(self._params.get("xl_interface_version", XL_INTERFACE_VERSION_V4))
        rx_queue_size = int(self._params.get("rx_queue_size", 4096))
        self._port_handle, permission_mask = self._vxl.open_port(
            app_name, access_mask, rx_queue_size, interface_version
        )
        logger.info(
            "FlexRay Vector ouvert: app=%s/%s hw_type=%s hw_index=%s hw_channel=%s mask=0x%X",
            app_name,
            app_channel,
            hw_type if hw_type is not None else "auto",
            hw_index,
            hw_channel,
            access_mask,
        )
        if permission_mask == 0:
            logger.warning("Init access not granted for FlexRay channel (mask=0x%X).", access_mask)

        fibex_path, cluster_name = self._resolve_fibex_config()
        cluster_params = load_flexray_cluster_params(fibex_path, cluster_name)
        if cluster_params is None:
            raise RuntimeError("Aucun cluster FlexRay detecte dans le FIBEX.")
        self._cluster_params = cluster_params

        self._use_canalyzer = bool(self._params.get("use_canalyzer_config", False))
        cluster_cfg = self._build_cluster_config(cluster_params.params, self._params.get("cluster_overrides", {}))
        if not self._use_canalyzer and permission_mask != 0:
            self._vxl.fr_set_configuration(self._port_handle, access_mask, cluster_cfg)

        self._schedule_by_slot: Dict[int, _ScheduleInfo] = {}
        schedule_by_frame = load_flexray_schedule(fibex_path, cluster_name or cluster_params.cluster_name)
        for sched in schedule_by_frame.values():
            self._schedule_by_slot[int(sched.slot_id)] = _ScheduleInfo(
                offset=int(sched.base_cycle),
                repetition=int(sched.cycle_repetition),
                channel=_channel_mask(sched.channel),
            )

        self._default_channel = _channel_mask(self._params.get("channel_mask", "A"))
        self._default_tx_mode = _tx_mode(self._params.get("tx_mode", "cyclic"))
        self._default_tx_flags = XL_FR_FRAMEFLAG_REQ_TXACK if self._params.get("tx_ack", False) else 0

        mode = XLfrMode()
        mode.frMode = int(self._params.get("fr_mode", 0))
        mode.frStartupAttributes = int(self._params.get("startup_mode", 0))
        mode.useSelCycle = 0
        mode.selCycle = 0
        if not self._use_canalyzer:
            self._vxl.fr_set_mode(self._port_handle, access_mask, mode)

        self._vxl.activate_channel(self._port_handle, access_mask)

    def _resolve_fibex_config(self) -> tuple[Path, Optional[str]]:
        fibex_path = self._params.get("fibex_path")
        cluster_name = self._params.get("cluster")
        if fibex_path and not cluster_name:
            cluster_name = self._params.get("cluster_name")
        if not fibex_path:
            cfg_path = os.getenv("ECO_MODE_CONFIG")
            if cfg_path:
                cfg_file = Path(cfg_path)
                cfg = yaml.safe_load(cfg_file.read_text(encoding="utf-8")) or {}
                fibex_cfg = cfg.get("fibex", {})
                fibex_path = fibex_cfg.get("path")
                clusters = fibex_cfg.get("clusters", {})
                if not cluster_name and isinstance(clusters, dict):
                    cluster_name = clusters.get(self.name)
                if fibex_path and not Path(fibex_path).is_absolute():
                    fibex_path = str((cfg_file.parent / fibex_path).resolve())
        if not fibex_path:
            raise RuntimeError("FlexRay backend: fibex_path manquant (bus config ou ECO_MODE_CONFIG).")
        return Path(fibex_path), cluster_name

    def _resolve_hw_config(self, app_name: str, app_channel: int) -> tuple[Optional[int], int, int]:
        hw_type = self._params.get("hw_type")
        hw_index = int(self._params.get("hw_index", 0))
        hw_channel = int(self._params.get("hw_channel", 0))
        if isinstance(hw_type, str):
            try:
                hw_type = _hw_type_from_name(hw_type)
            except ValueError:
                logger.warning(
                    "FlexRay backend: hw_type '%s' inconnu, tentative via app_name/app_channel.",
                    hw_type,
                )
                hw_type = None
        elif hw_type is not None:
            hw_type = int(hw_type)

        if hw_type is None and self._params.get("use_appl_config", True):
            try:
                hw_type, hw_index, hw_channel = self._vxl.get_appl_config(app_name, app_channel)
            except Exception:
                hw_type = None
        return hw_type, hw_index, hw_channel

    def _resolve_access_mask(self, hw_type: Optional[int], hw_index: int, hw_channel: int) -> int:
        channel_index = self._params.get("channel_index", self._params.get("channel"))
        if channel_index is not None:
            return 1 << int(channel_index)
        if hw_type is not None:
            return self._vxl.get_channel_mask(int(hw_type), hw_index, hw_channel)
        raise RuntimeError(
            "FlexRay backend: fournir channel_index ou hw_type/hw_index/hw_channel "
            "(ou app_name configure)."
        )

    def _build_cluster_config(
        self, params: Dict[str, int], overrides: Optional[Dict[str, int]]
    ) -> XLfrClusterConfig:
        cfg = XLfrClusterConfig()
        merged = dict(params)
        if overrides:
            merged.update(overrides)
        for field, _ in cfg._fields_:
            if field in merged:
                setattr(cfg, field, int(merged[field]))
        return cfg

    def send(self, frame: RawFrame) -> None:
        info = self._schedule_by_slot.get(frame.frame_id)
        offset = info.offset if info else int(self._params.get("offset", 0))
        repetition = info.repetition if info else int(self._params.get("repetition", 1))
        channel = info.channel if info else self._default_channel
        payload = bytes(frame.data)
        payload_words = (len(payload) + 1) // 2
        if payload_words > 127:
            raise ValueError("Payload FlexRay trop long (max 254 bytes).")

        event = XLfrEvent()
        event.size = ctypes.sizeof(XLfrEvent)
        event.tag = XL_FR_TX_FRAME
        event.flagsChip = channel & 0xFF
        event.tagData.frTxFrame.flags = self._default_tx_flags
        event.tagData.frTxFrame.slotID = int(frame.frame_id)
        event.tagData.frTxFrame.offset = int(offset)
        event.tagData.frTxFrame.repetition = int(repetition)
        event.tagData.frTxFrame.payloadLength = int(payload_words)
        event.tagData.frTxFrame.txMode = int(self._default_tx_mode)
        event.tagData.frTxFrame.incrementOffset = 0
        event.tagData.frTxFrame.incrementSize = 0

        padded = payload + (b"\x00" if len(payload) % 2 else b"")
        for i, value in enumerate(padded[:254]):
            event.tagData.frTxFrame.data[i] = value

        self._vxl.fr_transmit(self._port_handle, self._access_mask, event)

    def recv(self, timeout: Optional[float] = None) -> Optional[RawFrame]:
        end = time.monotonic() + timeout if timeout else None
        event = XLfrEvent()
        while True:
            status = self._vxl.fr_receive(self._port_handle, event)
            if status == XL_SUCCESS:
                if event.tag != XL_FR_RX_FRAME:
                    continue
                length = min(int(event.tagData.frRxFrame.payloadLength) * 2, 254)
                data = bytes(event.tagData.frRxFrame.data[:length])
                return RawFrame(
                    bus=self.name,
                    frame_id=int(event.tagData.frRxFrame.slotID),
                    data=data,
                    timestamp=time.time(),
                )
            if status == XL_ERR_QUEUE_IS_EMPTY:
                if end is None or time.monotonic() >= end:
                    return None
                time.sleep(0.001)
                continue
            self._vxl._status(status, "xlFrReceive")

    def shutdown(self) -> None:
        try:
            self._vxl.deactivate_channel(self._port_handle, self._access_mask)
        except Exception:
            pass
        try:
            self._vxl.close_port(self._port_handle)
        finally:
            self._vxl.close_driver()


def _hw_type_from_name(name: str) -> int:
    upper = name.strip().upper()
    if upper.startswith("XL_HWTYPE_"):
        upper = upper[len("XL_HWTYPE_") :]

    if upper.startswith("VN7610"):
        return XL_HWTYPE_VN7610
    if upper.startswith("VN7640"):
        return XL_HWTYPE_VN7640
    if upper.startswith("VN7600"):
        return XL_HWTYPE_VN7600
    if upper.startswith("VN36"):
        return XL_HWTYPE_VN3600
    if upper.startswith("VN1640"):
        return XL_HWTYPE_VN1640
    if upper.isdigit():
        return int(upper)
    raise ValueError(f"HW type inconnu: {name}")


def _channel_mask(value: Optional[str]) -> int:
    if value is None:
        return XL_FR_CHANNEL_A
    value = str(value).strip().upper()
    if value in ("A", "CH_A", "CHANNEL_A"):
        return XL_FR_CHANNEL_A
    if value in ("B", "CH_B", "CHANNEL_B"):
        return XL_FR_CHANNEL_B
    if value in ("AB", "BA", "A+B", "A|B"):
        return XL_FR_CHANNEL_AB
    return XL_FR_CHANNEL_A


def _tx_mode(value: Optional[str]) -> int:
    if value is None:
        return XL_FR_TX_MODE_CYCLIC
    value = str(value).strip().lower()
    if value in ("single", "single_shot", "oneshot"):
        return XL_FR_TX_MODE_SINGLE_SHOT
    return XL_FR_TX_MODE_CYCLIC
