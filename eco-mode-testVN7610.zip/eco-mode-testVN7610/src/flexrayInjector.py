"""FlexRay injector backend used by eco-mode tests (Node A scheduling)."""

from __future__ import annotations

from pathlib import Path
from typing import Optional
import logging
import time

from fibex_parser import FibexConfig, FrameDef, parse_fibex
from netio.bus import BusAdapter, BusSpec, RawFrame
from vector_xl import (
    XL_BUS_TYPE_FLEXRAY,
    XL_FR_CHANNEL_A,
    XL_FR_CHANNEL_AB,
    XL_FR_CHANNEL_B,
    XL_FR_MAX_DATA_LENGTH,
    XL_FR_RX_FRAME,
    XL_FR_TX_MODE_CYCLIC,
    XL_FR_TX_MODE_SINGLE_SHOT,
    XL_INTERFACE_VERSION_V4,
    VectorXL,
    create_fr_mode_normal,
    create_fr_tx_event,
    fr_rx_payload_bytes,
)

logger = logging.getLogger(__name__)


def should_transmit(cycle_index: int, base_cycle: int, repetition: int) -> bool:
    """Return True only when cycle respects FIBEX base-cycle/repetition rule."""

    if cycle_index < base_cycle:
        return False
    return ((cycle_index - base_cycle) % repetition) == 0


def next_eligible_cycle(cycle_index: int, base_cycle: int, repetition: int) -> int:
    """Return next cycle index that satisfies (cycle - base) % repetition == 0."""

    if cycle_index <= base_cycle:
        return base_cycle
    delta = (cycle_index - base_cycle) % repetition
    if delta == 0:
        return cycle_index
    return cycle_index + (repetition - delta)


class FlexRayInjectorBackend(BusAdapter):
    """BusAdapter implementation backed by Vector XL FlexRay APIs."""

    def __init__(self, spec: BusSpec) -> None:
        super().__init__(spec)
        params = dict(spec.params)

        fibex_path = params.get("fibex_path")
        cluster_name = params.get("cluster") or params.get("cluster_name")
        if not fibex_path:
            raise RuntimeError("FlexRayInjectorBackend requires 'fibex_path'")
        if not cluster_name:
            raise RuntimeError("FlexRayInjectorBackend requires 'cluster' or 'cluster_name'")

        self._fibex: FibexConfig = parse_fibex(Path(fibex_path), str(cluster_name))
        self._frames_by_slot = self._fibex.slots
        self._cycle_time_s = self._fibex.cluster.cycle_ms / 1000.0
        if self._cycle_time_s <= 0:
            raise RuntimeError("Invalid FlexRay cycle time in FIBEX")

        self._channel_flag = _channel_flag(params.get("channel_mask", "A"))
        self._tx_mode = _tx_mode(params.get("tx_mode", "single_shot"))
        self._tx_ack = bool(params.get("tx_ack", False))
        self._use_appl_config = bool(params.get("use_appl_config", True))

        dll_name = str(params.get("vxlapi_dll", "vxlapi64.dll"))
        self._xl = VectorXL(dll_name)
        self._port_handle: Optional[int] = None
        self._access_mask: Optional[int] = None

        self._app_name = str(params.get("app_name", "eco_mode_testVN7610"))
        self._app_channel = int(params.get("app_channel", 0))
        self._user_name = str(params.get("user_name", "flexrayInjector"))
        self._rx_queue_size = int(params.get("rx_queue_size", 16384))
        self._interface_version = int(params.get("xl_interface_version", XL_INTERFACE_VERSION_V4))

        self._open_and_configure(params)
        self._t0 = time.perf_counter()

        logger.info(
            "FlexRay injector backend ready on %s (cluster=%s, cycle_ms=%s)",
            self.name,
            self._fibex.cluster.name,
            self._fibex.cluster.cycle_ms,
        )

    def _open_and_configure(self, params: dict) -> None:
        self._xl.open_driver()
        try:
            access_mask = self._resolve_access_mask(params)
            port_handle, permission_mask = self._xl.open_port(
                user_name=self._user_name,
                access_mask=access_mask,
                rx_queue_size=self._rx_queue_size,
                interface_version=self._interface_version,
                bus_type=XL_BUS_TYPE_FLEXRAY,
            )
            if (permission_mask & access_mask) == 0:
                raise RuntimeError("xlOpenPort did not grant init permission for selected channel")

            self._port_handle = port_handle
            self._access_mask = access_mask
            self._configure_node_a()
            self._xl.activate_channel(self._port_handle, self._access_mask, XL_BUS_TYPE_FLEXRAY)
        except Exception:
            try:
                self._xl.close_driver()
            except Exception:
                pass
            raise

    def _resolve_access_mask(self, params: dict) -> int:
        if self._use_appl_config:
            channel = self._xl.get_application_channel(
                app_name=self._app_name,
                app_channel=self._app_channel,
                bus_type=XL_BUS_TYPE_FLEXRAY,
            )
            return channel.access_mask

        channel_index = params.get("channel_index", params.get("channel"))
        if channel_index is None:
            raise RuntimeError("Provide channel_index/channel when use_appl_config=false")
        return 1 << int(channel_index)

    def _configure_node_a(self) -> None:
        assert self._port_handle is not None
        assert self._access_mask is not None

        channel_cfg = self._xl.fr_get_channel_configuration(self._port_handle, self._access_mask)
        cluster_cfg = channel_cfg.xlFrClusterConfig

        cluster_cfg.gNumberOfStaticSlots = int(self._fibex.cluster.static_slot_count)
        cluster_cfg.pChannels = int(self._channel_flag)

        max_payload = max(frame.payload_length for frame in self._frames_by_slot.values())
        cluster_cfg.gPayloadLengthStatic = int(max_payload)

        self._xl.fr_set_configuration(self._port_handle, self._access_mask, cluster_cfg)
        self._xl.fr_set_mode(self._port_handle, self._access_mask, create_fr_mode_normal())

    def _cycle_index(self) -> int:
        elapsed = time.perf_counter() - self._t0
        return int(elapsed / self._cycle_time_s)

    def _wait_until_cycle(self, cycle_index: int) -> None:
        target = self._t0 + (cycle_index * self._cycle_time_s)
        while True:
            remaining = target - time.perf_counter()
            if remaining <= 0:
                return
            time.sleep(min(remaining, 0.001))

    def _wait_for_eligible_cycle(self, frame: FrameDef) -> None:
        while True:
            cycle = self._cycle_index()
            if should_transmit(cycle, frame.base_cycle, frame.repetition):
                return
            self._wait_until_cycle(next_eligible_cycle(cycle, frame.base_cycle, frame.repetition))

    def send(self, frame: RawFrame) -> None:
        assert self._port_handle is not None
        assert self._access_mask is not None

        frame_def = self._frames_by_slot.get(int(frame.frame_id))
        if frame_def is None:
            raise KeyError(f"Slot '{frame.frame_id}' not present in FIBEX schedule")

        payload = bytes(frame.data)
        if len(payload) < frame_def.payload_length:
            payload = payload + (b"\x00" * (frame_def.payload_length - len(payload)))
        elif len(payload) > frame_def.payload_length:
            payload = payload[: frame_def.payload_length]

        self._wait_for_eligible_cycle(frame_def)
        tx_event = create_fr_tx_event(
            slot_id=frame_def.slot_id,
            base_cycle=frame_def.base_cycle,
            repetition=frame_def.repetition,
            payload=payload,
            tx_mode=self._tx_mode,
            request_txack=self._tx_ack,
            channel_flag=self._channel_flag,
        )
        self._xl.fr_transmit(self._port_handle, self._access_mask, tx_event)

    def recv(self, timeout: Optional[float] = None) -> Optional[RawFrame]:
        assert self._port_handle is not None
        end = time.monotonic() + timeout if timeout is not None else None

        while True:
            fr_event = self._xl.fr_receive(self._port_handle)
            if fr_event is None:
                if end is not None and time.monotonic() >= end:
                    return None
                time.sleep(0.001)
                continue
            if fr_event.tag != XL_FR_RX_FRAME:
                continue

            slot_id = int(fr_event.tagData.frRxFrame.slotID)
            frame_def = self._frames_by_slot.get(slot_id)
            if frame_def is not None:
                payload = fr_rx_payload_bytes(fr_event, frame_def.payload_length)
            else:
                payload_words = int(fr_event.tagData.frRxFrame.payloadLength)
                payload_bytes = min(payload_words * 2, XL_FR_MAX_DATA_LENGTH)
                payload = bytes(fr_event.tagData.frRxFrame.data[index] for index in range(payload_bytes))

            return RawFrame(
                bus=self.name,
                frame_id=slot_id,
                data=payload,
                timestamp=time.time(),
            )

    def shutdown(self) -> None:
        if self._port_handle is None or self._access_mask is None:
            return
        try:
            self._xl.deactivate_channel(self._port_handle, self._access_mask)
        except Exception:
            pass
        try:
            self._xl.close_port(self._port_handle)
        except Exception:
            pass
        try:
            self._xl.close_driver()
        finally:
            self._port_handle = None
            self._access_mask = None


def _channel_flag(channel: object) -> int:
    text = str(channel).strip().upper()
    if text in {"A", "CH_A", "CHANNEL_A"}:
        return XL_FR_CHANNEL_A
    if text in {"B", "CH_B", "CHANNEL_B"}:
        return XL_FR_CHANNEL_B
    if text in {"AB", "BA", "A+B", "A|B"}:
        return XL_FR_CHANNEL_AB
    return XL_FR_CHANNEL_A


def _tx_mode(mode: object) -> int:
    text = str(mode).strip().lower()
    if text in {"cyclic"}:
        return XL_FR_TX_MODE_CYCLIC
    return XL_FR_TX_MODE_SINGLE_SHOT
