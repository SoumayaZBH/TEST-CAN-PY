"""Signal encoding and decoding helpers for FlexRay payloads."""

from __future__ import annotations

from typing import Iterable, Mapping


class SignalLike:
    """Structural protocol expected by payload codec helpers."""

    name: str
    start_bit: int
    bit_length: int
    factor: float
    offset: float
    signed: bool


def pack_unsigned_le(payload: bytearray, start_bit: int, bit_length: int, raw_value: int) -> None:
    """Pack an unsigned value into payload using little-endian bit numbering."""

    if bit_length <= 0:
        raise ValueError("bit_length must be > 0")
    if start_bit < 0:
        raise ValueError("start_bit must be >= 0")

    max_raw = (1 << bit_length) - 1
    if raw_value < 0 or raw_value > max_raw:
        raise ValueError(f"raw_value {raw_value} out of range for {bit_length} bits")

    for bit in range(bit_length):
        bit_index = start_bit + bit
        byte_index = bit_index // 8
        bit_in_byte = bit_index % 8

        if byte_index >= len(payload):
            raise ValueError("signal exceeds payload size")

        bit_val = (raw_value >> bit) & 0x1
        if bit_val:
            payload[byte_index] |= 1 << bit_in_byte
        else:
            payload[byte_index] &= ~(1 << bit_in_byte)


def unpack_unsigned_le(payload: bytes | bytearray, start_bit: int, bit_length: int) -> int:
    """Unpack an unsigned value from payload using little-endian bit numbering."""

    if bit_length <= 0:
        raise ValueError("bit_length must be > 0")
    if start_bit < 0:
        raise ValueError("start_bit must be >= 0")

    raw = 0
    for bit in range(bit_length):
        bit_index = start_bit + bit
        byte_index = bit_index // 8
        bit_in_byte = bit_index % 8

        if byte_index >= len(payload):
            raise ValueError("signal exceeds payload size")

        bit_val = (payload[byte_index] >> bit_in_byte) & 0x1
        raw |= bit_val << bit
    return raw


def _to_signed(raw: int, bit_length: int) -> int:
    sign_bit = 1 << (bit_length - 1)
    if raw & sign_bit:
        return raw - (1 << bit_length)
    return raw


def _from_signed(value: int, bit_length: int) -> int:
    min_value = -(1 << (bit_length - 1))
    max_value = (1 << (bit_length - 1)) - 1
    if value < min_value or value > max_value:
        raise ValueError(f"signed raw value {value} out of range for {bit_length} bits")
    if value < 0:
        return (1 << bit_length) + value
    return value


def physical_to_raw(
    physical_value: float,
    factor: float,
    offset: float,
    bit_length: int,
    signed: bool = False,
) -> int:
    """Convert physical value into raw payload integer value."""

    if factor == 0:
        raise ValueError("factor must not be zero")

    raw_float = (physical_value - offset) / factor
    raw_int = int(round(raw_float))

    if signed:
        return _from_signed(raw_int, bit_length)

    max_raw = (1 << bit_length) - 1
    if raw_int < 0 or raw_int > max_raw:
        raise ValueError(f"raw value {raw_int} out of range for unsigned {bit_length} bits")
    return raw_int


def raw_to_physical(
    raw_value: int,
    factor: float,
    offset: float,
    bit_length: int,
    signed: bool = False,
) -> float:
    """Convert raw payload integer value into physical value."""

    if signed:
        signed_raw = _to_signed(raw_value, bit_length)
        return signed_raw * factor + offset
    return raw_value * factor + offset


def encode_payload(
    signals: Iterable[SignalLike],
    physical_values: Mapping[str, float | int | bool],
    payload_length: int,
) -> bytes:
    """Encode multiple signals into a payload byte buffer."""

    payload = bytearray(payload_length)
    for signal in signals:
        if signal.name not in physical_values:
            continue
        raw = physical_to_raw(
            physical_value=float(physical_values[signal.name]),
            factor=float(signal.factor),
            offset=float(signal.offset),
            bit_length=int(signal.bit_length),
            signed=bool(getattr(signal, "signed", False)),
        )
        pack_unsigned_le(
            payload=payload,
            start_bit=int(signal.start_bit),
            bit_length=int(signal.bit_length),
            raw_value=raw,
        )
    return bytes(payload)


def decode_payload(signals: Iterable[SignalLike], payload: bytes | bytearray) -> dict[str, float]:
    """Decode a payload into physical values for all known signals."""

    values: dict[str, float] = {}
    for signal in signals:
        raw = unpack_unsigned_le(payload, int(signal.start_bit), int(signal.bit_length))
        values[signal.name] = raw_to_physical(
            raw_value=raw,
            factor=float(signal.factor),
            offset=float(signal.offset),
            bit_length=int(signal.bit_length),
            signed=bool(getattr(signal, "signed", False)),
        )
    return values
