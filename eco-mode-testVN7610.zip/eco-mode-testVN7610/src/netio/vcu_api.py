"""API de commande du mode ECO utilisee par les tests pytest."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Union
import logging
import time

from .signal_io import SignalIO, SignalRef

SignalValue = Union[int, float, bool]

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TimingCfg:
    """Valeurs de timing en millisecondes."""

    precondition_hold_ms: int
    request_hold_ms: int
    acceptance_timeout_ms: int

    @property
    def precondition_hold_s(self) -> float:
        """Retourner la duree de precondition en secondes."""

        return self.precondition_hold_ms / 1000.0

    @property
    def request_hold_s(self) -> float:
        """Retourner la duree de requete en secondes."""

        return self.request_hold_ms / 1000.0

    @property
    def acceptance_timeout_s(self) -> float:
        """Retourner le timeout d acceptation en secondes."""

        return self.acceptance_timeout_ms / 1000.0


class VcuDriveModeApi:
    """API de haut niveau pour demander et verifier l activation ECO."""

    def __init__(
        self,
        sio: SignalIO,
        sigmap: Dict[str, SignalRef],
        timing: TimingCfg,
    ) -> None:
        """Memoriser les dependances pour un flux multi-bus."""

        self._sio = sio
        self._sigmap = sigmap
        self._timing = timing

    def apply_preconditions(self, values: Dict[str, SignalValue]) -> None:
        """Appliquer les preconditions et maintenir la stabilite."""

        self._send_grouped(values)
        self._sio.pump(self._timing.precondition_hold_s)

    def request_eco(self) -> None:
        """Demander l activation ECO en envoyant les signaux de commande."""

        self._send_grouped(
            {
                "driver_mode_req_valid": 1,
                "driver_mode_request": 1,
            }
        )
        self._sio.pump(self._timing.request_hold_s)

    def wait_for_eco_result(self) -> Dict[str, Optional[SignalValue]]:
        """Attendre la reponse ECO et retourner les dernieres valeurs."""

        end_time = time.monotonic() + self._timing.acceptance_timeout_s
        while time.monotonic() < end_time:
            self._sio.pump(0.1)
            active = self._get_optional("driving_mode_active")
            accepted = self._get_optional("drivemode_accepted")
            reject = self._get_optional("drivemode_reject_reason")
            if active == 1 or accepted == 0 or reject is not None:
                break
        result = {
            "active_mode": self._get_optional("driving_mode_active"),
            "accepted": self._get_optional("drivemode_accepted"),
            "reject_reason": self._get_optional("drivemode_reject_reason"),
        }
        logger.info("Resultat ECO: %s", result)
        return result

    def _send_grouped(self, values: Dict[str, SignalValue]) -> None:
        """Regrouper les signaux par bus/trame et les envoyer."""

        grouped: Dict[tuple[str, str], Dict[str, SignalValue]] = {}
        for logical_name, value in values.items():
            ref = self._sigmap.get(logical_name)
            if ref is None:
                raise KeyError(f"Mapping manquant pour le signal '{logical_name}'")
            grouped.setdefault((ref.bus, ref.frame), {})[ref.signal] = value

        for (bus, frame), signals in grouped.items():
            self._sio.set_signals(bus, frame, signals)

    def _get_optional(self, logical_name: str) -> Optional[SignalValue]:
        """Retourner un signal optionnel si present dans le mapping."""

        ref = self._sigmap.get(logical_name)
        if ref is None:
            return None
        return self._sio.get_signal(ref)
