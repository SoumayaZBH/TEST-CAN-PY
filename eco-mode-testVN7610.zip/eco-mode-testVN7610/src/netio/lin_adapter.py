﻿"""Adaptateur LIN factice avec boucle locale en memoire."""

from __future__ import annotations

import logging

from .bus import BusSpec, VirtualBusAdapter, register_bus_adapter

logger = logging.getLogger(__name__)


class LinAdapter(VirtualBusAdapter):
    """Adaptateur LIN boucle locale pour le developpement hors-ligne."""

    def __init__(self, spec: BusSpec) -> None:
        """Initialiser l adaptateur LIN virtuel."""

        super().__init__(spec)
        logger.warning(
            "Adaptateur LIN '%s' en mode boucle locale. "
            "Remplacer par un adaptateur LIN reel pour les tests materiel.",
            spec.name,
        )


register_bus_adapter("lin", LinAdapter)


