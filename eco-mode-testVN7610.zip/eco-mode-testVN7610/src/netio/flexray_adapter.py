﻿"""Adaptateur FlexRay factice avec boucle locale en memoire."""

from __future__ import annotations

import logging

from .bus import BusSpec, VirtualBusAdapter, register_bus_adapter

logger = logging.getLogger(__name__)


class FlexRayAdapter(VirtualBusAdapter):
    """Adaptateur FlexRay boucle locale pour le developpement hors-ligne."""

    def __init__(self, spec: BusSpec) -> None:
        """Initialiser l adaptateur FlexRay virtuel."""

        super().__init__(spec)
        logger.warning(
            "Adaptateur FlexRay '%s' en mode boucle locale. "
            "Remplacer par un adaptateur FlexRay reel pour les tests materiel.",
            spec.name,
        )


register_bus_adapter("flexray", FlexRayAdapter)


