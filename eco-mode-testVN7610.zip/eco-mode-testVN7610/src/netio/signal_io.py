"""IO de signaux pour configurations FIBEX multi-bus."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple, Union
import logging
import time

from .bus import BusAdapter
from .fibex_codec import FibexCodec

SignalValue = Union[int, float, bool]

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SignalRef:
    """Reference vers un signal sur un bus et une trame."""

    bus: str
    frame: str
    signal: str


class SignalIO:
    """Helper IO signal avec cache des dernieres valeurs multi-bus."""

    def __init__(self, buses: Dict[str, BusAdapter], codec: FibexCodec) -> None:
        """Initialiser avec registre de bus et codec FIBEX."""

        self._buses = buses
        self._codec = codec
        self._cache: Dict[Tuple[str, str, str], SignalValue] = {}

    def set_signals(self, bus: str, frame: str, signal_values: Dict[str, SignalValue]) -> None:
        """Encoder et envoyer les signaux pour un bus et une trame."""

        raw = self._codec.encode(bus, frame, signal_values)
        self._buses[bus].send(raw)
        logger.debug("Signaux envoyes sur %s/%s: %s", bus, frame, list(signal_values.keys()))

    def pump(self, duration_s: float) -> None:
        """Pomper tous les bus pendant une duree et mettre a jour le cache."""

        if not self._buses:
            return
        end_time = time.monotonic() + max(0.0, duration_s)
        bus_names = list(self._buses.keys())
        while time.monotonic() < end_time:
            remaining = end_time - time.monotonic()
            slice_timeout = min(0.05, max(0.0, remaining / max(1, len(bus_names))))
            for bus in bus_names:
                msg = self._buses[bus].recv(timeout=slice_timeout)
                if msg is None:
                    continue
                decoded = self._codec.decode(msg)
                if decoded is None:
                    continue
                frame_name, signals = decoded
                for name, value in signals.items():
                    self._cache[(bus, frame_name, name)] = value
                logger.debug("Signaux recus sur %s/%s", bus, frame_name)

    def get_signal(self, ref: SignalRef) -> Optional[SignalValue]:
        """Retourner la derniere valeur cachee pour une reference de signal."""

        return self._cache.get((ref.bus, ref.frame, ref.signal))
