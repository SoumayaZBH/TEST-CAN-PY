"""Aides de journalisation pour les executions de tests."""

from __future__ import annotations

from pathlib import Path
import logging


def configure_logging(debug: bool, log_dir: Path) -> None:
    """Configurer le logging racine selon le mode debug et le dossier de logs."""

    if logging.getLogger().handlers:
        return
    log_dir.mkdir(parents=True, exist_ok=True)
    handlers: list[logging.Handler] = []
    if debug:
        handlers.append(logging.StreamHandler())
        handlers.append(logging.FileHandler(log_dir / "debug.log", encoding="utf-8"))
        level = logging.DEBUG
    else:
        handlers.append(logging.FileHandler(log_dir / "run.log", encoding="utf-8"))
        level = logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
        handlers=handlers,
    )
