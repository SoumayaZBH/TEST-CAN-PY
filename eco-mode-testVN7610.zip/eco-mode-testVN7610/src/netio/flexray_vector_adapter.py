"""Adaptateur FlexRay Vector via backend externe."""

from __future__ import annotations

import importlib
import logging
from typing import Optional

from .bus import BusAdapter, BusSpec, RawFrame, VirtualBusAdapter, register_bus_adapter

logger = logging.getLogger(__name__)


class VectorFlexRayAdapter(BusAdapter):
    """Adaptateur FlexRay Vector avec backend charge dynamiquement."""

    def __init__(self, spec: BusSpec) -> None:
        """Initialiser l adaptateur FlexRay Vector."""

        super().__init__(spec)
        backend_path = spec.params.get("backend")
        if not backend_path:
            backend_path = "vector_flexray_backend.VectorFlexRayBackend"
            logger.info(
                "FlexRay Vector '%s': backend par defaut active (%s).",
                spec.name,
                backend_path,
            )
        if backend_path == "virtual":
            self._backend = VirtualBusAdapter(spec)
            logger.warning(
                "FlexRay Vector '%s' en mode boucle locale (backend=virtual).",
                spec.name,
            )
        else:
            self._backend = _load_backend(backend_path, spec)
            logger.info("FlexRay Vector backend charge: %s", backend_path)

    def send(self, frame: RawFrame) -> None:
        """Envoyer une trame FlexRay via le backend."""

        self._backend.send(frame)

    def recv(self, timeout: Optional[float] = None) -> Optional[RawFrame]:
        """Recevoir une trame FlexRay via le backend."""

        return self._backend.recv(timeout)

    def shutdown(self) -> None:
        """Arreter le backend FlexRay."""

        self._backend.shutdown()


def _load_backend(backend_path: str, spec: BusSpec) -> BusAdapter:
    """Charger un backend externe sous forme module.Classe."""

    try:
        module_name, class_name = backend_path.rsplit(".", 1)
    except ValueError:
        raise ValueError("backend doit etre au format 'module.Classe'") from None

    try:
        module = importlib.import_module(module_name)
    except ImportError as exc:
        raise ImportError(f"Impossible d importer le module '{module_name}'") from exc

    backend_cls = getattr(module, class_name, None)
    if backend_cls is None:
        raise ImportError(
            f"La classe '{class_name}' est introuvable dans '{module_name}'"
        )

    backend = backend_cls(spec)
    if not isinstance(backend, BusAdapter):
        raise TypeError("Le backend FlexRay doit heriter de BusAdapter")
    return backend


register_bus_adapter("flexray_vector", VectorFlexRayAdapter)
