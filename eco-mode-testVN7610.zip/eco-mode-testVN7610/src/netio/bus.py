﻿"""Abstractions d adaptateurs de bus et registre pour IO multi-bus."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional, Type
import logging
import queue
import time

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RawFrame:
    """Trame de transport brute avec metadonnees minimales."""

    bus: str
    frame_id: int
    data: bytes
    is_extended_id: bool = False
    timestamp: Optional[float] = None


@dataclass(frozen=True)
class BusSpec:
    """Configuration normalisee du bus utilisee par les adaptateurs."""

    name: str
    kind: str
    params: Dict[str, Any]


class BusAdapter(ABC):
    """Adaptateur abstrait exposant send/recv/shutdown pour un bus."""

    def __init__(self, spec: BusSpec) -> None:
        """Initialiser l adaptateur avec une specification normalisee."""

        self._spec = spec

    @property
    def name(self) -> str:
        """Retourner le nom logique du bus defini dans la config."""

        return self._spec.name

    @property
    def kind(self) -> str:
        """Retourner le type d adaptateur (can, lin, flexray, ...)."""

        return self._spec.kind

    @abstractmethod
    def send(self, frame: RawFrame) -> None:
        """Envoyer une trame brute sur le bus."""

    @abstractmethod
    def recv(self, timeout: Optional[float] = None) -> Optional[RawFrame]:
        """Recevoir une trame brute du bus avec timeout optionnel."""

    @abstractmethod
    def shutdown(self) -> None:
        """Arreter l adaptateur et liberer les ressources."""


class VirtualBusAdapter(BusAdapter):
    """Adaptateur boucle locale en memoire pour le developpement hors-ligne."""

    def __init__(self, spec: BusSpec) -> None:
        """Creer une file en memoire pour renvoyer les trames."""

        super().__init__(spec)
        self._queue: queue.Queue[RawFrame] = queue.Queue()

    def send(self, frame: RawFrame) -> None:
        """Reinjecter la trame dans la file de reception."""

        normalized = RawFrame(
            bus=self.name,
            frame_id=frame.frame_id,
            data=frame.data,
            is_extended_id=frame.is_extended_id,
            timestamp=time.time(),
        )
        self._queue.put(normalized)
        logger.debug("Envoi boucle locale sur %s: id=0x%X", self.name, frame.frame_id)

    def recv(self, timeout: Optional[float] = None) -> Optional[RawFrame]:
        """Retourner la prochaine trame ou None en cas de timeout."""

        try:
            frame = self._queue.get(timeout=timeout or 0.0)
            return frame
        except queue.Empty:
            return None

    def shutdown(self) -> None:
        """Arret sans action pour l adaptateur virtuel."""

        logger.debug("Arret adaptateur virtuel pour %s", self.name)


_BUS_ADAPTERS: Dict[str, Type[BusAdapter]] = {}


def register_bus_adapter(kind: str, adapter_cls: Type[BusAdapter]) -> None:
    """Enregistrer une classe d adaptateur pour un type de bus."""

    _BUS_ADAPTERS[kind.lower()] = adapter_cls


def build_bus_adapters(bus_cfg: Dict[str, Dict[str, Any]]) -> Dict[str, BusAdapter]:
    """Instancier tous les adaptateurs definis dans la configuration YAML."""

    adapters: Dict[str, BusAdapter] = {}
    for bus_name, entry in bus_cfg.items():
        if not isinstance(entry, dict):
            raise ValueError(f"Bus '{bus_name}' doit etre une section mapping")
        kind = entry.get("kind")
        if not kind:
            raise KeyError(f"Bus '{bus_name}' manque le champ obligatoire 'kind'")
        adapter_cls = _BUS_ADAPTERS.get(str(kind).lower())
        if adapter_cls is None:
            raise KeyError(f"Aucun adaptateur enregistre pour le type '{kind}'")
        params = {k: v for k, v in entry.items() if k != "kind"}
        spec = BusSpec(name=bus_name, kind=str(kind).lower(), params=params)
        adapters[bus_name] = adapter_cls(spec)
        logger.info("Adaptateur bus initialise: %s (%s)", bus_name, kind)
    return adapters

