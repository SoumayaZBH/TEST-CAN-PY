"""FIBEX signal encoding/decoding backed by ElementTree parser + bit codec."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple, Union
import logging

from fibex_parser import FrameDef, SignalDef, parse_fibex
from signal_codec import decode_payload, encode_payload

from .bus import RawFrame

SignalValue = Union[int, float, bool]

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class FrameRef:
    """Resolved frame metadata for fast encode/decode operations."""

    name: str
    frame_id: int
    payload_length: int
    signals: list[SignalDef]


class FibexCodec:
    """Encode and decode test signals based on a FlexRay FIBEX file."""

    def __init__(self, fibex_path: Path, bus_clusters: Optional[Dict[str, str]] = None) -> None:
        fibex_path = Path(fibex_path)
        if not fibex_path.is_file():
            raise FileNotFoundError(f"FIBEX file not found: {fibex_path}")

        self._fibex_path = fibex_path
        self._bus_clusters = bus_clusters or {}
        self._default_cluster: Optional[str] = None

        self._frames_by_name: Dict[str, Dict[str, FrameRef]] = {}
        self._frames_by_id: Dict[str, Dict[int, FrameRef]] = {}

    def encode(self, bus: str, frame_name: str, signal_values: Dict[str, SignalValue]) -> RawFrame:
        """Encode physical signal values to a raw FlexRay frame."""

        frame_ref = self._get_frame_by_name(bus, frame_name)
        payload = encode_payload(frame_ref.signals, signal_values, frame_ref.payload_length)
        return RawFrame(bus=bus, frame_id=frame_ref.frame_id, data=payload)

    def decode(self, frame: RawFrame) -> Optional[Tuple[str, Dict[str, SignalValue]]]:
        """Decode a raw FlexRay frame payload into physical signal values."""

        frame_ref = self._get_frame_by_id(frame.bus, frame.frame_id)
        if frame_ref is None:
            return None

        decoded = decode_payload(frame_ref.signals, frame.data)
        values: Dict[str, SignalValue] = {}
        for name, value in decoded.items():
            if float(value).is_integer():
                values[name] = int(round(value))
            else:
                values[name] = value
        return frame_ref.name, values

    def _get_frame_by_name(self, bus: str, frame_name: str) -> FrameRef:
        if bus not in self._frames_by_name:
            self._prime_bus_cache(bus)
        try:
            return self._frames_by_name[bus][frame_name]
        except KeyError as exc:
            raise KeyError(f"Frame '{frame_name}' not found on bus '{bus}'") from exc

    def _get_frame_by_id(self, bus: str, frame_id: int) -> Optional[FrameRef]:
        if bus not in self._frames_by_id:
            self._prime_bus_cache(bus)
        return self._frames_by_id[bus].get(frame_id)

    def _prime_bus_cache(self, bus: str) -> None:
        cluster = self._resolve_cluster(bus)
        model = parse_fibex(self._fibex_path, cluster)

        by_name: Dict[str, FrameRef] = {}
        by_id: Dict[int, FrameRef] = {}
        for frame in model.frames.values():
            ref = _frame_ref(frame)
            by_name[ref.name] = ref
            by_id[ref.frame_id] = ref

        self._frames_by_name[bus] = by_name
        self._frames_by_id[bus] = by_id
        logger.info("FIBEX cache ready for bus '%s' (cluster '%s')", bus, model.cluster.name)

    def _resolve_cluster(self, bus: str) -> Optional[str]:
        if bus in self._bus_clusters:
            return self._bus_clusters[bus]
        if self._default_cluster is None:
            self._default_cluster = parse_fibex(self._fibex_path).cluster.name
        return self._default_cluster


def _frame_ref(frame: FrameDef) -> FrameRef:
    return FrameRef(
        name=frame.name,
        frame_id=frame.slot_id,
        payload_length=frame.payload_length,
        signals=frame.signals,
    )
