"""Adaptateur CAN base sur python-can."""

from __future__ import annotations

import logging
from typing import Optional

import can

from .bus import BusAdapter, BusSpec, RawFrame, register_bus_adapter

logger = logging.getLogger(__name__)


class CanAdapter(BusAdapter):
    """Adaptateur qui encapsule python-can pour le trafic CAN."""

    def __init__(self, spec: BusSpec) -> None:
        """Ouvrir un bus python-can avec les parametres fournis."""

        super().__init__(spec)
        params = dict(spec.params)
        interface = params.pop("interface", None)
        channel = params.get("channel")
        if not interface:
            raise ValueError(f"Bus CAN '{spec.name}': champ 'interface' obligatoire")
        if channel is None:
            raise ValueError(f"Bus CAN '{spec.name}': champ 'channel' obligatoire")

        # Pass-through des options python-can (ex: app_name, serial, channel_index, fd, ...).
        self._bus = can.Bus(interface=interface, **params)
        logger.info(
            "Adaptateur CAN pret sur l interface=%s, channel=%s",
            interface,
            channel,
        )

    def send(self, frame: RawFrame) -> None:
        """Envoyer une trame CAN."""

        message = can.Message(
            arbitration_id=frame.frame_id,
            data=frame.data,
            is_extended_id=frame.is_extended_id,
        )
        self._bus.send(message)
        logger.debug("Envoi CAN: id=0x%X", frame.frame_id)

    def recv(self, timeout: Optional[float] = None) -> Optional[RawFrame]:
        """Recevoir une trame CAN et la convertir en RawFrame."""

        msg = self._bus.recv(timeout)
        if msg is None:
            return None
        return RawFrame(
            bus=self.name,
            frame_id=msg.arbitration_id,
            data=bytes(msg.data),
            is_extended_id=bool(msg.is_extended_id),
            timestamp=msg.timestamp,
        )

    def shutdown(self) -> None:
        """Arreter l interface CAN."""

        self._bus.shutdown()
        logger.info("Arret adaptateur CAN")


register_bus_adapter("can", CanAdapter)
