"""Adaptateur bus base sur UDP pour emulateur et tests locaux."""

from __future__ import annotations

import logging
import socket
import struct
from typing import Optional

from .bus import BusAdapter, BusSpec, RawFrame, register_bus_adapter

logger = logging.getLogger(__name__)


class UdpAdapter(BusAdapter):
    """Adaptateur qui transporte les trames brutes via UDP."""

    def __init__(self, spec: BusSpec) -> None:
        """Lier une socket UDP locale et definir le point distant."""

        super().__init__(spec)
        self._local_addr = str(spec.params.get("local_addr", "127.0.0.1"))
        self._local_port = int(spec.params.get("local_port", 0))
        self._remote_addr = str(spec.params.get("remote_addr", "127.0.0.1"))
        self._remote_port = int(spec.params.get("remote_port", 0))
        if self._local_port == 0 or self._remote_port == 0:
            raise ValueError(f"Adaptateur UDP '{spec.name}' requiert local_port et remote_port")
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.bind((self._local_addr, self._local_port))
        logger.info(
            "Adaptateur UDP '%s' lie sur %s:%s -> %s:%s",
            spec.name,
            self._local_addr,
            self._local_port,
            self._remote_addr,
            self._remote_port,
        )

    def send(self, frame: RawFrame) -> None:
        """Envoyer une trame brute via UDP."""

        payload = _pack_frame(frame)
        self._sock.sendto(payload, (self._remote_addr, self._remote_port))
        logger.debug("Envoi UDP sur %s: id=0x%X", self.name, frame.frame_id)

    def recv(self, timeout: Optional[float] = None) -> Optional[RawFrame]:
        """Recevoir un paquet UDP et le convertir en RawFrame."""

        if timeout is None:
            self._sock.settimeout(None)
        else:
            self._sock.settimeout(timeout)
        try:
            data, _addr = self._sock.recvfrom(2048)
        except (socket.timeout, BlockingIOError):
            return None
        frame = _unpack_frame(self.name, data)
        return frame

    def shutdown(self) -> None:
        """Fermer la socket UDP."""

        try:
            self._sock.close()
        finally:
            logger.info("Arret adaptateur UDP '%s'", self.name)


def _pack_frame(frame: RawFrame) -> bytes:
    """Encoder un RawFrame en payload UDP."""

    data = bytes(frame.data)
    if len(data) > 255:
        raise ValueError("Adaptateur UDP supporte des payloads <= 255 octets")
    header = struct.pack("!IBB", int(frame.frame_id), 1 if frame.is_extended_id else 0, len(data))
    return header + data


def _unpack_frame(bus: str, payload: bytes) -> Optional[RawFrame]:
    """Decoder un payload UDP en RawFrame."""

    if len(payload) < 6:
        return None
    frame_id, ext_flag, length = struct.unpack("!IBB", payload[:6])
    data = payload[6 : 6 + length]
    if len(data) != length:
        return None
    return RawFrame(bus=bus, frame_id=frame_id, data=data, is_extended_id=bool(ext_flag))


register_bus_adapter("udp", UdpAdapter)
