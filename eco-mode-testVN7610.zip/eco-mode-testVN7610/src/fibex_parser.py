"""ElementTree-based FIBEX parser focused on FlexRay clusters, frames and signals."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, Optional
import re
import xml.etree.ElementTree as ET

_NUM_RE = re.compile(r"[-+]?\d+(?:\.\d+)?")


@dataclass(frozen=True)
class ClusterDef:
    """FlexRay cluster timing details used by injector scheduling."""

    name: str
    cycle_ms: float
    static_slot_count: int


@dataclass(frozen=True)
class SignalDef:
    """Signal layout and conversion metadata."""

    name: str
    start_bit: int
    bit_length: int
    factor: float
    offset: float
    signed: bool = False
    little_endian: bool = True


@dataclass(frozen=True)
class FrameDef:
    """FlexRay frame schedule and payload layout."""

    name: str
    slot_id: int
    base_cycle: int
    repetition: int
    payload_length: int
    channel: str
    signals: list[SignalDef]


@dataclass(frozen=True)
class FibexConfig:
    """Parsed FlexRay cluster with indexed frame metadata."""

    cluster: ClusterDef
    frames: dict[str, FrameDef]
    slots: dict[int, FrameDef]


def parse_fibex(path: str | Path, cluster_name: Optional[str] = None) -> FibexConfig:
    """Parse a FIBEX XML and extract one FlexRay cluster with all scheduled frames."""

    tree = ET.parse(str(path))
    root = tree.getroot()

    id_map = _build_id_map(root)
    signals_by_id = _signals_by_id(root)
    codings_by_id = _codings_by_id(root)

    clusters = _find_flexray_clusters(root)
    if not clusters:
        raise ValueError("No FlexRay cluster found in FIBEX")

    cluster_node = _select_cluster(clusters, cluster_name)
    cluster = _extract_cluster(cluster_node)

    channels_by_id = _channels_by_id(root)
    channel_refs = _channel_refs(cluster_node)
    if not channel_refs:
        raise ValueError(f"Cluster '{cluster.name}' has no CHANNEL-REF")

    frames: dict[str, FrameDef] = {}
    slots: dict[int, FrameDef] = {}
    for channel_ref in channel_refs:
        channel_node = channels_by_id.get(channel_ref)
        if channel_node is None:
            continue
        channel_name = _channel_name(channel_node)
        for ft in _find_desc(channel_node, "FRAME-TRIGGERING"):
            frame_def = _extract_frame_def(
                ft=ft,
                channel_name=channel_name,
                id_map=id_map,
                signals_by_id=signals_by_id,
                codings_by_id=codings_by_id,
            )
            if frame_def is None:
                continue
            frames[frame_def.name] = frame_def
            slots[frame_def.slot_id] = frame_def

    if not frames:
        raise ValueError(f"Cluster '{cluster.name}' has no usable FlexRay FRAME-TRIGGERING")

    return FibexConfig(cluster=cluster, frames=frames, slots=slots)


def _extract_cluster(cluster_node: ET.Element) -> ClusterDef:
    name = _extract_name(cluster_node, fallback="flexray_cluster")
    cycle = _find_first_float(cluster_node, ["CLUSTER-CYCLE-TIME", "CYCLE-TIME", "CYCLE-DURATION", "GD-CYCLE"])
    if cycle is None:
        raise ValueError(f"Cluster '{name}' missing cycle time")
    cycle_ms = _to_milliseconds(cycle, cluster_node)

    static_slot_count = _find_first_int(
        cluster_node,
        ["G-NUMBER-OF-STATIC-SLOTS", "NUMBER-OF-STATIC-SLOTS", "STATIC-SLOT-COUNT"],
    )
    if static_slot_count is None:
        raise ValueError(f"Cluster '{name}' missing static slot count")

    return ClusterDef(name=name, cycle_ms=cycle_ms, static_slot_count=static_slot_count)


def _extract_frame_def(
    ft: ET.Element,
    channel_name: str,
    id_map: dict[str, ET.Element],
    signals_by_id: dict[str, tuple[str, str]],
    codings_by_id: dict[str, dict[str, float | int | bool]],
) -> Optional[FrameDef]:
    slot_id = _find_first_int(ft, ["SLOT-ID", "IDENTIFIER-VALUE"])
    base_cycle = _find_first_int(ft, ["BASE-CYCLE"])
    repetition = _find_first_int(ft, ["CYCLE-REPETITION", "REPETITION"])
    if slot_id is None or base_cycle is None or repetition is None or repetition <= 0:
        return None

    frame_node = _resolve_first_ref(ft, id_map, ["FRAME-REF"])
    if frame_node is None:
        return None

    frame_name = _extract_name(frame_node, fallback=f"slot_{slot_id}")
    payload_length = _find_first_int(frame_node, ["BYTE-LENGTH", "PAYLOAD-LENGTH", "LENGTH"])
    if payload_length is None or payload_length <= 0:
        return None

    signals = _extract_signals(frame_node, id_map, signals_by_id, codings_by_id)
    if not signals:
        return None

    return FrameDef(
        name=frame_name,
        slot_id=slot_id,
        base_cycle=base_cycle,
        repetition=repetition,
        payload_length=payload_length,
        channel=channel_name,
        signals=signals,
    )


def _extract_signals(
    frame_node: ET.Element,
    id_map: dict[str, ET.Element],
    signals_by_id: dict[str, tuple[str, str]],
    codings_by_id: dict[str, dict[str, float | int | bool]],
) -> list[SignalDef]:
    roots = [frame_node]
    for pdu_inst in _find_desc(frame_node, "PDU-INSTANCE"):
        pdu_ref = _attr_ref(pdu_inst, "PDU-REF")
        pdu_node = _resolve_ref(pdu_ref, id_map)
        if pdu_node is not None:
            roots.append(pdu_node)

    signal_nodes: list[ET.Element] = []
    for root in roots:
        signal_nodes.extend(_find_desc(root, "SIGNAL-INSTANCE"))

    result: list[SignalDef] = []
    seen: set[str] = set()
    for sig_inst in signal_nodes:
        sig_ref = _attr_ref(sig_inst, "SIGNAL-REF")
        if not sig_ref:
            continue
        sig_meta = signals_by_id.get(sig_ref)
        if sig_meta is None:
            continue
        sig_name, coding_id = sig_meta
        if sig_name in seen:
            continue

        start_bit = _find_first_int(sig_inst, ["BIT-POSITION", "START-BIT", "BIT-START-POSITION"])
        if start_bit is None:
            continue
        little_endian = not bool(_find_first_bool(sig_inst, ["IS-HIGH-LOW-BYTE-ORDER"], default=False))

        coding = codings_by_id.get(coding_id, {})
        bit_length = int(coding.get("bit_length", 0))
        if bit_length <= 0:
            bit_length = _find_first_int(sig_inst, ["BIT-LENGTH", "LENGTH"]) or 0
        if bit_length <= 0:
            continue

        factor = float(coding.get("factor", 1.0))
        offset = float(coding.get("offset", 0.0))
        signed = bool(coding.get("signed", False))

        result.append(
            SignalDef(
                name=sig_name,
                start_bit=start_bit,
                bit_length=bit_length,
                factor=factor,
                offset=offset,
                signed=signed,
                little_endian=little_endian,
            )
        )
        seen.add(sig_name)
    return result


def _signals_by_id(root: ET.Element) -> dict[str, tuple[str, str]]:
    mapping: dict[str, tuple[str, str]] = {}
    for sig in _find_desc(root, "SIGNAL"):
        sig_id = _attr(sig, "ID")
        if not sig_id:
            continue
        name = _extract_name(sig, fallback=sig_id)
        coding_ref = _attr_ref(sig, "CODING-REF") or ""
        mapping[sig_id] = (name, coding_ref)
    return mapping


def _codings_by_id(root: ET.Element) -> dict[str, dict[str, float | int | bool]]:
    codings: dict[str, dict[str, float | int | bool]] = {}
    for coding in _find_desc(root, "CODING"):
        coding_id = _attr(coding, "ID")
        if not coding_id:
            continue
        bit_length = _find_first_int(coding, ["BIT-LENGTH"]) or 0

        base_data_type = ""
        for node in _find_desc(coding, "CODED-TYPE"):
            for key, value in node.attrib.items():
                if _norm(_local_name(key)) == "basedatatype":
                    base_data_type = value
                    break
            if base_data_type:
                break
        upper_type = base_data_type.upper()
        signed = "INT" in upper_type and "UINT" not in upper_type

        factor = _find_first_float(coding, ["FACTOR"])
        offset = _find_first_float(coding, ["OFFSET"])
        if factor is None or offset is None:
            linear = _extract_linear_coeffs(coding)
            if linear is not None:
                factor, offset = linear
            else:
                factor, offset = 1.0, 0.0

        codings[coding_id] = {
            "bit_length": bit_length,
            "factor": float(factor),
            "offset": float(offset),
            "signed": signed,
        }
    return codings


def _extract_linear_coeffs(node: ET.Element) -> Optional[tuple[float, float]]:
    numerators = []
    denominators = []
    for child in node.iter():
        lname = _norm(_local_name(child.tag))
        if lname in {"compunumerator", "numerator"}:
            numerators = _collect_numbers(child)
        elif lname in {"compudenominator", "denominator"}:
            denominators = _collect_numbers(child)
    if len(numerators) < 2 or not denominators:
        return None
    if denominators[0] == 0:
        return None
    offset = numerators[0] / denominators[0]
    factor = numerators[1] / denominators[0]
    return factor, offset


def _find_flexray_clusters(root: ET.Element) -> list[ET.Element]:
    clusters: list[ET.Element] = []
    for cluster in _find_desc(root, "CLUSTER"):
        proto = _find_first_text(cluster, ["PROTOCOL"])
        if proto and "FLEXRAY" in proto.upper():
            clusters.append(cluster)
    return clusters


def _select_cluster(clusters: list[ET.Element], cluster_name: Optional[str]) -> ET.Element:
    if cluster_name:
        for cluster in clusters:
            if _extract_name(cluster, fallback="").strip() == cluster_name:
                return cluster
        raise ValueError(f"FlexRay cluster '{cluster_name}' not found in FIBEX")
    return clusters[0]


def _channels_by_id(root: ET.Element) -> dict[str, ET.Element]:
    channels: dict[str, ET.Element] = {}
    for channel in _find_desc(root, "CHANNEL"):
        channel_id = _attr(channel, "ID")
        if channel_id:
            channels[channel_id] = channel
    return channels


def _channel_refs(cluster: ET.Element) -> list[str]:
    refs: list[str] = []
    for child in cluster.iter():
        if _norm(_local_name(child.tag)) != "channelref":
            continue
        ref = _attr(child, "ID-REF")
        if ref:
            refs.append(ref)
    return refs


def _channel_name(channel: ET.Element) -> str:
    name = _find_first_text(channel, ["FLEXRAY-CHANNEL-NAME", "SHORT-NAME"]) or "A"
    upper = name.strip().upper()
    if upper in {"A", "B", "AB", "BA"}:
        return upper
    if "B" in upper:
        return "B"
    return "A"


def _resolve_first_ref(node: ET.Element, id_map: dict[str, ET.Element], refs: Iterable[str]) -> Optional[ET.Element]:
    wanted = {_norm(item) for item in refs}
    for child in node.iter():
        lname = _norm(_local_name(child.tag))
        if not lname.endswith("ref"):
            continue
        if lname not in wanted:
            continue
        resolved = _resolve_ref(_attr(child, "ID-REF") or _text(child), id_map)
        if resolved is not None:
            return resolved
    return None


def _resolve_ref(ref_text: Optional[str], id_map: dict[str, ET.Element]) -> Optional[ET.Element]:
    if not ref_text:
        return None
    stripped = ref_text.strip()
    candidates = [stripped, stripped.lstrip("#"), stripped.split("/")[-1]]
    for candidate in candidates:
        if candidate in id_map:
            return id_map[candidate]
    return None


def _attr_ref(node: ET.Element, ref_tag: str) -> Optional[str]:
    wanted = _norm(ref_tag)
    for child in node.iter():
        if _norm(_local_name(child.tag)) != wanted:
            continue
        return _attr(child, "ID-REF") or _text(child)
    return None


def _build_id_map(root: ET.Element) -> dict[str, ET.Element]:
    id_map: dict[str, ET.Element] = {}
    for node in root.iter():
        node_id = _attr(node, "ID")
        if node_id:
            id_map[node_id] = node
    return id_map


def _extract_name(node: ET.Element, fallback: str) -> str:
    attr_name = _attr(node, "NAME")
    if attr_name:
        return attr_name.strip()
    short_name = _find_first_text(node, ["SHORT-NAME", "NAME"])
    return short_name if short_name else fallback


def _to_milliseconds(value: float, node: ET.Element) -> float:
    for attr_name, attr_value in node.attrib.items():
        if "unit" not in _norm(_local_name(attr_name)):
            continue
        unit = attr_value.strip().lower()
        if unit in {"ms", "millisecond", "milliseconds"}:
            return value
        if unit in {"us", "microsecond", "microseconds"}:
            return value / 1000.0
        if unit in {"s", "sec", "second", "seconds"}:
            return value * 1000.0
    return value


def _find_desc(node: ET.Element, tag_name: str) -> list[ET.Element]:
    wanted = _norm(tag_name)
    return [child for child in node.iter() if _norm(_local_name(child.tag)) == wanted]


def _find_first_text(node: ET.Element, candidate_names: Iterable[str]) -> Optional[str]:
    wanted = {_norm(name) for name in candidate_names}
    for child in node.iter():
        if _norm(_local_name(child.tag)) not in wanted:
            continue
        value = _text(child)
        if value:
            return value
    return None


def _find_first_float(node: ET.Element, candidate_names: Iterable[str]) -> Optional[float]:
    wanted = {_norm(name) for name in candidate_names}
    for child in node.iter():
        if _norm(_local_name(child.tag)) not in wanted:
            continue
        value = _first_number(_text(child))
        if value is not None:
            return float(value)
    return None


def _find_first_int(node: ET.Element, candidate_names: Iterable[str]) -> Optional[int]:
    value = _find_first_float(node, candidate_names)
    if value is None:
        return None
    return int(round(value))


def _find_first_bool(node: ET.Element, candidate_names: Iterable[str], default: bool) -> bool:
    text = _find_first_text(node, candidate_names)
    if text is None:
        return default
    low = text.strip().lower()
    if low in {"1", "true", "yes"}:
        return True
    if low in {"0", "false", "no"}:
        return False
    return default


def _collect_numbers(node: ET.Element) -> list[float]:
    numbers: list[float] = []
    for child in node.iter():
        value = _first_number(_text(child))
        if value is not None:
            numbers.append(value)
    return numbers


def _first_number(text: str) -> Optional[float]:
    match = _NUM_RE.search(text)
    if not match:
        return None
    return float(match.group(0))


def _attr(node: ET.Element, attr_name: str) -> Optional[str]:
    wanted = _norm(attr_name)
    for key, value in node.attrib.items():
        if _norm(_local_name(key)) == wanted:
            return value
    return None


def _text(node: ET.Element) -> str:
    return (node.text or "").strip()


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", name.lower())
