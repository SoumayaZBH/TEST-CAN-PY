"""Tests unitaires des aliases hardware pour le backend FlexRay Vector."""

from vector_flexray_backend import (
    XL_HWTYPE_VN7610,
    _hw_type_from_name,
)


def test_hw_type_vn7610_name_alias() -> None:
    """Verifier la resolution de VN7610 vers le code XL attendu."""

    assert _hw_type_from_name("VN7610") == XL_HWTYPE_VN7610
    assert _hw_type_from_name("VN7610A") == XL_HWTYPE_VN7610
    assert _hw_type_from_name("XL_HWTYPE_VN7610") == XL_HWTYPE_VN7610


def test_hw_type_numeric_passthrough() -> None:
    """Verifier qu une valeur numerique reste exploitable telle quelle."""

    assert _hw_type_from_name("81") == 81
