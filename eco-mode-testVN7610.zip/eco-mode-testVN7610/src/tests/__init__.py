"""Marqueur de package pytest."""
