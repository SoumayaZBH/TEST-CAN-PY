"""Test d acceptation du mode ECO via injection FlexRay directe."""

from __future__ import annotations

BASE_PRECONDITIONS = {
    "ignition_state": 2,
    "hv_ready": 1,
    "vcu_fault_level": 0,
    "degraded_mode": 0,
    "gear_position": 1,
    "vehicle_speed": 0,
    "accel_pedal_pos": 0,
    "brake_pedal": 0,
    "battery_soc": 60,
    "battery_temp": 25,
}


def test_eco_mode_acceptance(eco_mode) -> None:
    """Demander le mode ECO et attendre l activation avec preconditions nominales."""

    eco_mode.apply_preconditions(BASE_PRECONDITIONS)
    eco_mode.request_eco()
    result = eco_mode.wait_for_eco_result()

    assert result["active_mode"] == 1
    if result["accepted"] is not None:
        assert result["accepted"] == 1
