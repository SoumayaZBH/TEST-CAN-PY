"""Test d acceptation du mode ECO avec signaux multi-bus."""

from __future__ import annotations

from netio import VcuDriveModeApi

BASE_PRECONDITIONS = {
    "ignition_state": 2,
    "hv_ready": 1,
    "vcu_fault_level": 0,
    "degraded_mode": 0,
    "gear_position": 1,
    "vehicle_speed": 0,
    "accel_pedal_pos": 0,
    "brake_pedal": 0,
    "battery_soc": 60,
    "battery_temp": 25,
}


def test_eco_mode_acceptance(vcu: VcuDriveModeApi) -> None:
    """Demander le mode ECO et attendre l activation avec preconditions nominales."""

    vcu.apply_preconditions(BASE_PRECONDITIONS)
    vcu.request_eco()
    result = vcu.wait_for_eco_result()

    assert result["active_mode"] == 1
    if result["accepted"] is not None:
        assert result["accepted"] == 1
