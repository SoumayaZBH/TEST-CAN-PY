"""Tests unitaires du backend VN7610 dedie."""

import pytest

from vector_flexray_backend import XL_HWTYPE_VN7610
from vn7610_flexray_backend import normalize_vn7610_params


def test_normalize_vn7610_params_sets_expected_defaults() -> None:
    """Verifier les defaults et le forcage du hw_type VN7610."""

    params = normalize_vn7610_params(
        {
            "fibex_path": "fibex/example_vehicle.xml",
            "cluster": "cluster_example_vehicle",
            "channel_index": 0,
        }
    )

    assert params["hw_type"] == XL_HWTYPE_VN7610
    assert params["app_name"] == "eco_mode_testVN7610"
    assert params["app_channel"] == 0
    assert params["channel_mask"] == "A"
    assert params["tx_mode"] == "cyclic"
    assert params["tx_ack"] is False


def test_normalize_vn7610_params_rejects_invalid_hw_type() -> None:
    """Refuser un hw_type qui ne cible pas VN7610."""

    with pytest.raises(RuntimeError, match="hw_type doit cibler VN7610"):
        normalize_vn7610_params(
            {
                "hw_type": "VN1640",
                "fibex_path": "fibex/example_vehicle.xml",
                "cluster": "cluster_example_vehicle",
                "channel_index": 0,
            }
        )


def test_normalize_vn7610_params_requires_fibex_and_cluster() -> None:
    """Verifier les champs obligatoires pour le backend dedie."""

    with pytest.raises(RuntimeError, match="fibex_path"):
        normalize_vn7610_params({"cluster": "cluster_example_vehicle", "channel_index": 0})

    with pytest.raises(RuntimeError, match="cluster"):
        normalize_vn7610_params({"fibex_path": "fibex/example_vehicle.xml", "channel_index": 0})
