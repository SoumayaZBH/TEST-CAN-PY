"""Tests de rejet du mode ECO via injection FlexRay directe."""

from __future__ import annotations

import pytest

BASE_PRECONDITIONS = {
    "ignition_state": 2,
    "hv_ready": 1,
    "vcu_fault_level": 0,
    "degraded_mode": 0,
    "gear_position": 1,
    "vehicle_speed": 0,
    "accel_pedal_pos": 0,
    "brake_pedal": 0,
    "battery_soc": 60,
    "battery_temp": 25,
}

REFUSAL_CASES = [
    ({"ignition_state": 0}, 1),
    ({"hv_ready": 0}, 2),
    ({"battery_soc": 5}, 9),
    ({"gear_position": 3}, 5),
    ({"brake_pedal": 1}, 8),
]


@pytest.mark.parametrize("override, expected_reason", REFUSAL_CASES)
def test_eco_mode_rejection(
    eco_mode,
    override: dict,
    expected_reason: int,
) -> None:
    """Demander le mode ECO et attendre un rejet si preconditions invalides."""

    preconditions = {**BASE_PRECONDITIONS, **override}
    eco_mode.apply_preconditions(preconditions)
    eco_mode.request_eco()
    result = eco_mode.wait_for_eco_result()

    assert result["active_mode"] != 1
    if result["accepted"] is not None:
        assert result["accepted"] == 0
    if result["reject_reason"] is not None:
        assert result["reject_reason"] == expected_reason
