"""Fixtures pytest et validation de configuration."""

from __future__ import annotations

from pathlib import Path
from typing import Dict
import os
import sys

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from netio import (
    FibexCodec,
    SignalIO,
    SignalRef,
    TimingCfg,
    VcuDriveModeApi,
    build_bus_adapters,
    configure_logging,
)

REQUIRED_SIGNALS = {
    "driver_mode_request",
    "driver_mode_req_valid",
    "ignition_state",
    "hv_ready",
    "vcu_fault_level",
    "degraded_mode",
    "gear_position",
    "vehicle_speed",
    "accel_pedal_pos",
    "brake_pedal",
    "battery_soc",
    "battery_temp",
    "driving_mode_active",
}

OPTIONAL_SIGNALS = {
    "drivemode_accepted",
    "drivemode_reject_reason",
}


def pytest_addoption(parser: pytest.Parser) -> None:
    """Ajouter des options CLI pour le chemin de config et le debug."""

    parser.addoption(
        "--config",
        action="store",
        default=os.getenv("ECO_MODE_CONFIG", str(ROOT / "config" / "testbench.yaml")),
        help="Chemin vers testbench.yaml",
    )
    parser.addoption(
        "--eco-debug",
        action="store_true",
        default=os.getenv("ECO_MODE_DEBUG", "0") == "1",
        help="Activer les logs debug ECO (evite le conflit avec pytest --debug)",
    )


def _require_mapping(cfg: dict, key: str) -> Dict:
    """Retourner une section mapping ou lever une ValueError."""

    entry = cfg.get(key)
    if not isinstance(entry, dict):
        raise ValueError(f"La section '{key}' doit etre un mapping")
    return entry


def _validate_signal_entry(name: str, entry: dict) -> None:
    """Valider qu un mapping de signal contient les champs requis."""

    if not isinstance(entry, dict):
        raise ValueError(f"Le signal '{name}' doit etre un mapping")
    for field in ("bus", "frame", "signal"):
        if not entry.get(field):
            raise ValueError(f"Signal '{name}' manquant '{field}'")


def _validate_config(cfg: dict) -> None:
    """Valider les sections obligatoires et les mappings de signaux."""

    _require_mapping(cfg, "fibex")
    _require_mapping(cfg, "buses")
    _require_mapping(cfg, "signals")
    _require_mapping(cfg, "timing_ms")

    signals_cfg = cfg["signals"]
    for signal in REQUIRED_SIGNALS:
        if signal not in signals_cfg:
            raise ValueError(f"Signal requis '{signal}' manquant dans la config")
    for name, entry in signals_cfg.items():
        _validate_signal_entry(name, entry)

    buses_cfg = cfg["buses"]
    for name, entry in buses_cfg.items():
        if not isinstance(entry, dict):
            raise ValueError(f"Bus '{name}' doit etre un mapping")
        if not entry.get("kind"):
            raise ValueError(f"Bus '{name}' manque le champ 'kind'")

    for name, entry in signals_cfg.items():
        bus_name = entry.get("bus")
        if bus_name not in buses_cfg:
            raise ValueError(f"Signal '{name}' reference un bus inconnu '{bus_name}'")


def _load_config(pytestconfig: pytest.Config) -> dict:
    """Charger la config YAML et resoudre les chemins relatifs."""

    cfg_path = Path(pytestconfig.getoption("--config"))
    if not cfg_path.is_absolute():
        cfg_path = ROOT / cfg_path
    if not cfg_path.is_file():
        raise FileNotFoundError(f"Fichier de config introuvable: {cfg_path}")
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    if not isinstance(cfg, dict):
        raise ValueError("La racine de config doit etre un mapping")
    fibex_cfg = _require_mapping(cfg, "fibex")
    fibex_path = Path(fibex_cfg.get("path", ""))
    if not fibex_path.is_absolute():
        fibex_path = ROOT / fibex_path
    fibex_cfg["path"] = str(fibex_path)
    _validate_config(cfg)
    return cfg


@pytest.fixture(scope="session")
def cfg(pytestconfig: pytest.Config) -> dict:
    """Retourner la configuration validee."""

    return _load_config(pytestconfig)


@pytest.fixture(scope="session")
def debug_enabled(pytestconfig: pytest.Config) -> bool:
    """Retourner True si le debug est actif."""

    return bool(pytestconfig.getoption("--eco-debug"))


@pytest.fixture(scope="session")
def buses(cfg: dict, debug_enabled: bool) -> Dict[str, object]:
    """Creer les adaptateurs de bus et assurer l arret."""

    log_dir = Path(os.getenv("ECO_MODE_REPORT_DIR", str(ROOT / "reports")))
    if not log_dir.is_absolute():
        log_dir = ROOT / log_dir
    configure_logging(debug_enabled, log_dir)
    adapters = build_bus_adapters(cfg["buses"])
    yield adapters
    for adapter in adapters.values():
        adapter.shutdown()


@pytest.fixture(scope="session")
def codec(cfg: dict) -> FibexCodec:
    """Instancier le codec FIBEX pour la session de tests."""

    fibex_cfg = cfg["fibex"]
    clusters = fibex_cfg.get("clusters")
    return FibexCodec(Path(fibex_cfg["path"]), bus_clusters=clusters)


@pytest.fixture(scope="function")
def sio(buses: Dict[str, object], codec: FibexCodec) -> SignalIO:
    """Creer un SignalIO par test pour un etat propre."""

    return SignalIO(buses, codec)


@pytest.fixture(scope="session")
def sigmap(cfg: dict) -> Dict[str, SignalRef]:
    """Construire le mapping logique des signaux depuis le YAML."""

    mapping: Dict[str, SignalRef] = {}
    for logical, entry in cfg["signals"].items():
        mapping[logical] = SignalRef(
            bus=entry["bus"],
            frame=entry["frame"],
            signal=entry["signal"],
        )
    return mapping


@pytest.fixture(scope="session")
def timing(cfg: dict) -> TimingCfg:
    """Construire la configuration de timing depuis le YAML."""

    timing_cfg = cfg["timing_ms"]
    return TimingCfg(
        precondition_hold_ms=int(timing_cfg["precondition_hold"]),
        request_hold_ms=int(timing_cfg["request_hold"]),
        acceptance_timeout_ms=int(timing_cfg["acceptance_timeout"]),
    )


@pytest.fixture(scope="function")
def vcu(sio: SignalIO, sigmap: Dict[str, SignalRef], timing: TimingCfg) -> VcuDriveModeApi:
    """Fournir l API VCU utilisee par les tests."""

    return VcuDriveModeApi(sio, sigmap, timing)
