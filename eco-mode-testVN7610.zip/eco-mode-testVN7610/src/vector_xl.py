"""Low-level ctypes wrapper for Vector XL Driver Library (vxlapi64.dll)."""

from __future__ import annotations

import ctypes
from dataclasses import dataclass
from typing import Optional


# XL typedef mappings
XLstatus = ctypes.c_short
XLuint64 = ctypes.c_uint64
XLaccess = XLuint64
XLportHandle = ctypes.c_long
XLstringType = ctypes.c_char_p


# XL constants (subset)
XL_SUCCESS = 0
XL_ERR_QUEUE_IS_EMPTY = 10
XL_INVALID_PORTHANDLE = -1

XL_BUS_TYPE_FLEXRAY = 0x00000004

XL_INTERFACE_VERSION_V3 = 3
XL_INTERFACE_VERSION_V4 = 4

XL_ACTIVATE_NONE = 0

XL_FR_MAX_DATA_LENGTH = 254
XL_FR_RX_EVENT_HEADER_SIZE = 32
XL_FR_MAX_EVENT_SIZE = 512

XL_FR_START_CYCLE = 0x0080
XL_FR_RX_FRAME = 0x0081
XL_FR_TX_FRAME = 0x0082
XL_FR_TXACK_FRAME = 0x0083

XL_FR_MODE_NORMAL = 0x00
XL_FR_MODE_NONE = 0x00

XL_FR_CHANNEL_A = 0x01
XL_FR_CHANNEL_B = 0x02
XL_FR_CHANNEL_AB = XL_FR_CHANNEL_A | XL_FR_CHANNEL_B

XL_FR_FRAMEFLAG_REQ_TXACK = 0x0020

XL_FR_TX_MODE_CYCLIC = 0x01
XL_FR_TX_MODE_SINGLE_SHOT = 0x02
XL_FR_PAYLOAD_INCREMENT_NONE = 0


class XLfrClusterConfig(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("busGuardianEnable", ctypes.c_uint),
        ("baudrate", ctypes.c_uint),
        ("busGuardianTick", ctypes.c_uint),
        ("externalClockCorrectionMode", ctypes.c_uint),
        ("gColdStartAttempts", ctypes.c_uint),
        ("gListenNoise", ctypes.c_uint),
        ("gMacroPerCycle", ctypes.c_uint),
        ("gMaxWithoutClockCorrectionFatal", ctypes.c_uint),
        ("gMaxWithoutClockCorrectionPassive", ctypes.c_uint),
        ("gNetworkManagementVectorLength", ctypes.c_uint),
        ("gNumberOfMinislots", ctypes.c_uint),
        ("gNumberOfStaticSlots", ctypes.c_uint),
        ("gOffsetCorrectionStart", ctypes.c_uint),
        ("gPayloadLengthStatic", ctypes.c_uint),
        ("gSyncNodeMax", ctypes.c_uint),
        ("gdActionPointOffset", ctypes.c_uint),
        ("gdDynamicSlotIdlePhase", ctypes.c_uint),
        ("gdMacrotick", ctypes.c_uint),
        ("gdMinislot", ctypes.c_uint),
        ("gdMiniSlotActionPointOffset", ctypes.c_uint),
        ("gdNIT", ctypes.c_uint),
        ("gdStaticSlot", ctypes.c_uint),
        ("gdSymbolWindow", ctypes.c_uint),
        ("gdTSSTransmitter", ctypes.c_uint),
        ("gdWakeupSymbolRxIdle", ctypes.c_uint),
        ("gdWakeupSymbolRxLow", ctypes.c_uint),
        ("gdWakeupSymbolRxWindow", ctypes.c_uint),
        ("gdWakeupSymbolTxIdle", ctypes.c_uint),
        ("gdWakeupSymbolTxLow", ctypes.c_uint),
        ("pAllowHaltDueToClock", ctypes.c_uint),
        ("pAllowPassiveToActive", ctypes.c_uint),
        ("pChannels", ctypes.c_uint),
        ("pClusterDriftDamping", ctypes.c_uint),
        ("pDecodingCorrection", ctypes.c_uint),
        ("pDelayCompensationA", ctypes.c_uint),
        ("pDelayCompensationB", ctypes.c_uint),
        ("pExternOffsetCorrection", ctypes.c_uint),
        ("pExternRateCorrection", ctypes.c_uint),
        ("pKeySlotUsedForStartup", ctypes.c_uint),
        ("pKeySlotUsedForSync", ctypes.c_uint),
        ("pLatestTx", ctypes.c_uint),
        ("pMacroInitialOffsetA", ctypes.c_uint),
        ("pMacroInitialOffsetB", ctypes.c_uint),
        ("pMaxPayloadLengthDynamic", ctypes.c_uint),
        ("pMicroInitialOffsetA", ctypes.c_uint),
        ("pMicroInitialOffsetB", ctypes.c_uint),
        ("pMicroPerCycle", ctypes.c_uint),
        ("pMicroPerMacroNom", ctypes.c_uint),
        ("pOffsetCorrectionOut", ctypes.c_uint),
        ("pRateCorrectionOut", ctypes.c_uint),
        ("pSamplesPerMicrotick", ctypes.c_uint),
        ("pSingleSlotEnabled", ctypes.c_uint),
        ("pWakeupChannel", ctypes.c_uint),
        ("pWakeupPattern", ctypes.c_uint),
        ("pdAcceptedStartupRange", ctypes.c_uint),
        ("pdListenTimeout", ctypes.c_uint),
        ("pdMaxDrift", ctypes.c_uint),
        ("pdMicrotick", ctypes.c_uint),
        ("gdCASRxLowMax", ctypes.c_uint),
        ("gChannels", ctypes.c_uint),
        ("vExternOffsetControl", ctypes.c_uint),
        ("vExternRateControl", ctypes.c_uint),
        ("pChannelsMTS", ctypes.c_uint),
        ("framePresetData", ctypes.c_uint),
        ("reserved", ctypes.c_uint * 15),
    ]


class XLfrChannelConfig(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("status", ctypes.c_uint),
        ("cfgMode", ctypes.c_uint),
        ("reserved", ctypes.c_uint * 6),
        ("xlFrClusterConfig", XLfrClusterConfig),
    ]


class XLfrMode(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("frMode", ctypes.c_uint),
        ("frStartupAttributes", ctypes.c_uint),
        ("useSelCycle", ctypes.c_ushort),
        ("selCycle", ctypes.c_ushort),
        ("reserved", ctypes.c_uint * 29),
    ]


class XL_FR_START_CYCLE_EV(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("cycleCount", ctypes.c_uint),
        ("vRateCorrection", ctypes.c_int),
        ("vOffsetCorrection", ctypes.c_int),
        ("vClockCorrectionFailed", ctypes.c_uint),
        ("vAllowPassivToActive", ctypes.c_uint),
        ("reserved", ctypes.c_uint * 3),
    ]


class XL_FR_RX_FRAME_EV(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("flags", ctypes.c_ushort),
        ("headerCRC", ctypes.c_ushort),
        ("slotID", ctypes.c_ushort),
        ("cycleCount", ctypes.c_ubyte),
        ("payloadLength", ctypes.c_ubyte),
        ("data", ctypes.c_ubyte * XL_FR_MAX_DATA_LENGTH),
    ]


class XL_FR_TX_FRAME_EV(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("flags", ctypes.c_ushort),
        ("slotID", ctypes.c_ushort),
        ("offset", ctypes.c_ubyte),
        ("repetition", ctypes.c_ubyte),
        ("payloadLength", ctypes.c_ubyte),
        ("txMode", ctypes.c_ubyte),
        ("incrementSize", ctypes.c_ubyte),
        ("incrementOffset", ctypes.c_ubyte),
        ("reserved0", ctypes.c_ubyte),
        ("reserved1", ctypes.c_ubyte),
        ("data", ctypes.c_ubyte * XL_FR_MAX_DATA_LENGTH),
    ]


class XLfrTagData(ctypes.Union):
    _pack_ = 8
    _fields_ = [
        ("frStartCycle", XL_FR_START_CYCLE_EV),
        ("frRxFrame", XL_FR_RX_FRAME_EV),
        ("frTxFrame", XL_FR_TX_FRAME_EV),
        ("raw", ctypes.c_ubyte * (XL_FR_MAX_EVENT_SIZE - XL_FR_RX_EVENT_HEADER_SIZE)),
    ]


class XLfrEvent(ctypes.Structure):
    _pack_ = 8
    _fields_ = [
        ("size", ctypes.c_uint),
        ("tag", ctypes.c_ushort),
        ("channelIndex", ctypes.c_ushort),
        ("userHandle", ctypes.c_uint),
        ("flagsChip", ctypes.c_ushort),
        ("reserved", ctypes.c_ushort),
        ("timeStamp", XLuint64),
        ("timeStampSync", XLuint64),
        ("tagData", XLfrTagData),
    ]


@dataclass(frozen=True)
class ApplicationChannel:
    """Mapped application channel info from Vector Hardware Config."""

    hw_type: int
    hw_index: int
    hw_channel: int
    access_mask: int


class XlApiError(RuntimeError):
    """Raised when an XL API call returns an error status."""

    def __init__(self, api: str, status: int, message: str) -> None:
        super().__init__(f"{api} failed with status {status}: {message}")
        self.api = api
        self.status = status


class VectorXL:
    """ctypes wrapper for selected XL APIs used by FlexRay injector backend."""

    def __init__(self, dll_name: str = "vxlapi64.dll") -> None:
        self.dll = ctypes.WinDLL(dll_name)
        self._bind()

    def _bind(self) -> None:
        self.dll.xlOpenDriver.argtypes = []
        self.dll.xlOpenDriver.restype = XLstatus

        self.dll.xlCloseDriver.argtypes = []
        self.dll.xlCloseDriver.restype = XLstatus

        self.dll.xlGetErrorString.argtypes = [XLstatus]
        self.dll.xlGetErrorString.restype = XLstringType

        self.dll.xlGetApplConfig.argtypes = [
            ctypes.c_char_p,
            ctypes.c_uint,
            ctypes.POINTER(ctypes.c_uint),
            ctypes.POINTER(ctypes.c_uint),
            ctypes.POINTER(ctypes.c_uint),
            ctypes.c_uint,
        ]
        self.dll.xlGetApplConfig.restype = XLstatus

        self.dll.xlGetChannelMask.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int]
        self.dll.xlGetChannelMask.restype = XLaccess

        self.dll.xlOpenPort.argtypes = [
            ctypes.POINTER(XLportHandle),
            ctypes.c_char_p,
            XLaccess,
            ctypes.POINTER(XLaccess),
            ctypes.c_uint,
            ctypes.c_uint,
            ctypes.c_uint,
        ]
        self.dll.xlOpenPort.restype = XLstatus

        self.dll.xlClosePort.argtypes = [XLportHandle]
        self.dll.xlClosePort.restype = XLstatus

        self.dll.xlActivateChannel.argtypes = [XLportHandle, XLaccess, ctypes.c_uint, ctypes.c_uint]
        self.dll.xlActivateChannel.restype = XLstatus

        self.dll.xlDeactivateChannel.argtypes = [XLportHandle, XLaccess]
        self.dll.xlDeactivateChannel.restype = XLstatus

        self.dll.xlFrSetConfiguration.argtypes = [XLportHandle, XLaccess, ctypes.POINTER(XLfrClusterConfig)]
        self.dll.xlFrSetConfiguration.restype = XLstatus

        self.dll.xlFrGetChannelConfiguration.argtypes = [
            XLportHandle,
            XLaccess,
            ctypes.POINTER(XLfrChannelConfig),
        ]
        self.dll.xlFrGetChannelConfiguration.restype = XLstatus

        self.dll.xlFrSetMode.argtypes = [XLportHandle, XLaccess, ctypes.POINTER(XLfrMode)]
        self.dll.xlFrSetMode.restype = XLstatus

        self.dll.xlFrReceive.argtypes = [XLportHandle, ctypes.POINTER(XLfrEvent)]
        self.dll.xlFrReceive.restype = XLstatus

        self.dll.xlFrTransmit.argtypes = [XLportHandle, XLaccess, ctypes.POINTER(XLfrEvent)]
        self.dll.xlFrTransmit.restype = XLstatus

    def _status_text(self, status: int) -> str:
        msg = self.dll.xlGetErrorString(XLstatus(status))
        if msg:
            return msg.decode("ascii", errors="replace")
        return "unknown error"

    def check_status(self, api: str, status: int) -> None:
        if status != XL_SUCCESS:
            raise XlApiError(api, status, self._status_text(status))

    def open_driver(self) -> None:
        self.check_status("xlOpenDriver", int(self.dll.xlOpenDriver()))

    def close_driver(self) -> None:
        self.check_status("xlCloseDriver", int(self.dll.xlCloseDriver()))

    def get_application_channel(
        self,
        app_name: str,
        app_channel: int,
        bus_type: int = XL_BUS_TYPE_FLEXRAY,
    ) -> ApplicationChannel:
        """Read Vector Hardware Config and derive access mask for app/channel."""

        hw_type = ctypes.c_uint(0)
        hw_index = ctypes.c_uint(0)
        hw_channel = ctypes.c_uint(0)

        status = int(
            self.dll.xlGetApplConfig(
                app_name.encode("ascii"),
                ctypes.c_uint(app_channel),
                ctypes.byref(hw_type),
                ctypes.byref(hw_index),
                ctypes.byref(hw_channel),
                ctypes.c_uint(bus_type),
            )
        )
        self.check_status("xlGetApplConfig", status)

        access_mask = int(
            self.dll.xlGetChannelMask(
                int(hw_type.value),
                int(hw_index.value),
                int(hw_channel.value),
            )
        )
        if access_mask == 0:
            raise RuntimeError("xlGetChannelMask returned 0 (channel not configured or unavailable)")

        return ApplicationChannel(
            hw_type=int(hw_type.value),
            hw_index=int(hw_index.value),
            hw_channel=int(hw_channel.value),
            access_mask=access_mask,
        )

    def open_port(
        self,
        user_name: str,
        access_mask: int,
        rx_queue_size: int = 16384,
        interface_version: int = XL_INTERFACE_VERSION_V4,
        bus_type: int = XL_BUS_TYPE_FLEXRAY,
    ) -> tuple[int, int]:
        """Open an XL port for FlexRay access."""

        port_handle = XLportHandle(XL_INVALID_PORTHANDLE)
        permission_mask = XLaccess(access_mask)

        status = int(
            self.dll.xlOpenPort(
                ctypes.byref(port_handle),
                user_name.encode("ascii"),
                XLaccess(access_mask),
                ctypes.byref(permission_mask),
                ctypes.c_uint(rx_queue_size),
                ctypes.c_uint(interface_version),
                ctypes.c_uint(bus_type),
            )
        )
        self.check_status("xlOpenPort", status)
        return int(port_handle.value), int(permission_mask.value)

    def close_port(self, port_handle: int) -> None:
        self.check_status("xlClosePort", int(self.dll.xlClosePort(XLportHandle(port_handle))))

    def activate_channel(
        self,
        port_handle: int,
        access_mask: int,
        bus_type: int = XL_BUS_TYPE_FLEXRAY,
    ) -> None:
        status = int(
            self.dll.xlActivateChannel(
                XLportHandle(port_handle),
                XLaccess(access_mask),
                ctypes.c_uint(bus_type),
                ctypes.c_uint(XL_ACTIVATE_NONE),
            )
        )
        self.check_status("xlActivateChannel", status)

    def deactivate_channel(self, port_handle: int, access_mask: int) -> None:
        status = int(self.dll.xlDeactivateChannel(XLportHandle(port_handle), XLaccess(access_mask)))
        self.check_status("xlDeactivateChannel", status)

    def fr_get_channel_configuration(self, port_handle: int, access_mask: int) -> XLfrChannelConfig:
        cfg = XLfrChannelConfig()
        status = int(
            self.dll.xlFrGetChannelConfiguration(
                XLportHandle(port_handle),
                XLaccess(access_mask),
                ctypes.byref(cfg),
            )
        )
        self.check_status("xlFrGetChannelConfiguration", status)
        return cfg

    def fr_set_configuration(self, port_handle: int, access_mask: int, cfg: XLfrClusterConfig) -> None:
        status = int(
            self.dll.xlFrSetConfiguration(
                XLportHandle(port_handle),
                XLaccess(access_mask),
                ctypes.byref(cfg),
            )
        )
        self.check_status("xlFrSetConfiguration", status)

    def fr_set_mode(self, port_handle: int, access_mask: int, mode: XLfrMode) -> None:
        status = int(
            self.dll.xlFrSetMode(
                XLportHandle(port_handle),
                XLaccess(access_mask),
                ctypes.byref(mode),
            )
        )
        self.check_status("xlFrSetMode", status)

    def fr_receive(self, port_handle: int) -> Optional[XLfrEvent]:
        event = XLfrEvent()
        status = int(self.dll.xlFrReceive(XLportHandle(port_handle), ctypes.byref(event)))
        if status == XL_ERR_QUEUE_IS_EMPTY:
            return None
        self.check_status("xlFrReceive", status)
        return event

    def fr_transmit(self, port_handle: int, access_mask: int, event: XLfrEvent) -> None:
        status = int(
            self.dll.xlFrTransmit(
                XLportHandle(port_handle),
                XLaccess(access_mask),
                ctypes.byref(event),
            )
        )
        self.check_status("xlFrTransmit", status)


def create_fr_mode_normal() -> XLfrMode:
    """Create a normal FlexRay mode structure."""

    mode = XLfrMode()
    mode.frMode = XL_FR_MODE_NORMAL
    mode.frStartupAttributes = XL_FR_MODE_NONE
    mode.useSelCycle = 0
    mode.selCycle = 0
    for index in range(len(mode.reserved)):
        mode.reserved[index] = 0
    return mode


def create_fr_tx_event(
    slot_id: int,
    base_cycle: int,
    repetition: int,
    payload: bytes,
    *,
    tx_mode: int = XL_FR_TX_MODE_SINGLE_SHOT,
    request_txack: bool = False,
    channel_flag: int = XL_FR_CHANNEL_A,
) -> XLfrEvent:
    """Build a TX event for xlFrTransmit."""

    if not (0 <= slot_id <= 0xFFFF):
        raise ValueError("slot_id must fit into unsigned short")
    if not (0 <= base_cycle <= 0xFF):
        raise ValueError("base_cycle must fit into unsigned char")
    if not (1 <= repetition <= 0xFF):
        raise ValueError("repetition must be in [1..255]")
    if len(payload) > XL_FR_MAX_DATA_LENGTH:
        raise ValueError(f"payload too large: {len(payload)} > {XL_FR_MAX_DATA_LENGTH}")

    event = XLfrEvent()
    event.size = ctypes.sizeof(XLfrEvent)
    event.tag = XL_FR_TX_FRAME
    event.channelIndex = 0
    event.userHandle = 0
    event.flagsChip = int(channel_flag) & 0xFF
    event.reserved = 0
    event.timeStamp = 0
    event.timeStampSync = 0

    tx = event.tagData.frTxFrame
    tx.flags = XL_FR_FRAMEFLAG_REQ_TXACK if request_txack else 0
    tx.slotID = ctypes.c_ushort(slot_id).value
    tx.offset = ctypes.c_ubyte(base_cycle).value
    tx.repetition = ctypes.c_ubyte(repetition).value
    tx.payloadLength = ctypes.c_ubyte((len(payload) + 1) // 2).value
    tx.txMode = ctypes.c_ubyte(tx_mode).value
    tx.incrementSize = XL_FR_PAYLOAD_INCREMENT_NONE
    tx.incrementOffset = 0
    tx.reserved0 = 0
    tx.reserved1 = 0

    for index in range(XL_FR_MAX_DATA_LENGTH):
        tx.data[index] = 0
    for index, value in enumerate(payload):
        tx.data[index] = value

    return event


def fr_rx_payload_bytes(event: XLfrEvent, payload_length_from_fibex: int) -> bytes:
    """Extract RX payload bytes using FIBEX payload length as source of truth."""

    length = min(int(payload_length_from_fibex), XL_FR_MAX_DATA_LENGTH)
    rx = event.tagData.frRxFrame
    return bytes(rx.data[index] for index in range(length))
