"""Parsing FIBEX FlexRay for cluster config and signal encoding."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Dict, Iterable, Optional, Tuple
import logging

import lxml.etree
import canmatrix

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class FlexRaySchedule:
    """Schedule information for a FlexRay frame."""

    slot_id: int
    base_cycle: int
    cycle_repetition: int
    channel: str
    payload_length: int


@dataclass(frozen=True)
class FlexRayClusterParams:
    """Raw cluster/controller params extracted from FlexRay FIBEX."""

    cluster_name: str
    params: Dict[str, int]


def load_flexray_cluster_params(
    fibex_path: Path, cluster_name: Optional[str] = None
) -> Optional[FlexRayClusterParams]:
    """Parse FlexRay cluster + controller parameters from a FIBEX file.

    Returns None if no FlexRay cluster is found.
    """

    root = _load_xml_root(fibex_path)
    clusters = _find_flexray_clusters(root)
    if not clusters:
        return None

    cluster = _select_cluster(clusters, cluster_name)
    params: Dict[str, int] = {}

    params["baudrate"] = _int_text(cluster, "./*[local-name()='SPEED']/text()")
    params["gColdStartAttempts"] = _int_text(cluster, "./*[local-name()='COLD-START-ATTEMPTS']/text()")
    params["gListenNoise"] = _int_text(cluster, "./*[local-name()='LISTEN-NOISE']/text()")
    params["gMacroPerCycle"] = _int_text(cluster, "./*[local-name()='MACRO-PER-CYCLE']/text()")
    params["gMaxWithoutClockCorrectionFatal"] = _int_text(
        cluster, "./*[local-name()='MAX-WITHOUT-CLOCK-CORRECTION-FATAL']/text()"
    )
    params["gMaxWithoutClockCorrectionPassive"] = _int_text(
        cluster, "./*[local-name()='MAX-WITHOUT-CLOCK-CORRECTION-PASSIVE']/text()"
    )
    params["gNetworkManagementVectorLength"] = _int_text(
        cluster, "./*[local-name()='NETWORK-MANAGEMENT-VECTOR-LENGTH']/text()"
    )
    params["gNumberOfMinislots"] = _int_text(cluster, "./*[local-name()='NUMBER-OF-MINISLOTS']/text()")
    params["gNumberOfStaticSlots"] = _int_text(cluster, "./*[local-name()='NUMBER-OF-STATIC-SLOTS']/text()")
    params["gOffsetCorrectionStart"] = _int_text(cluster, "./*[local-name()='OFFSET-CORRECTION-START']/text()")
    params["gPayloadLengthStatic"] = _int_text(cluster, "./*[local-name()='PAYLOAD-LENGTH-STATIC']/text()")
    params["gSyncNodeMax"] = _int_text(cluster, "./*[local-name()='SYNC-NODE-MAX']/text()")
    params["gdActionPointOffset"] = _int_text(cluster, "./*[local-name()='ACTION-POINT-OFFSET']/text()")
    params["gdDynamicSlotIdlePhase"] = _int_text(
        cluster, "./*[local-name()='DYNAMIC-SLOT-IDLE-PHASE']/text()"
    )
    params["gdMacrotick"] = 0  # Not used by XL API
    params["gdMinislot"] = _int_text(cluster, "./*[local-name()='MINISLOT']/text()")
    params["gdMiniSlotActionPointOffset"] = _int_text(
        cluster, "./*[local-name()='MINISLOT-ACTION-POINT-OFFSET']/text()"
    )
    params["gdNIT"] = _int_text(cluster, "./*[local-name()='N-I-T']/text()")
    params["gdStaticSlot"] = _int_text(cluster, "./*[local-name()='STATIC-SLOT']/text()")
    params["gdSymbolWindow"] = _int_text(cluster, "./*[local-name()='SYMBOL-WINDOW']/text()")
    params["gdTSSTransmitter"] = _int_text(cluster, "./*[local-name()='T-S-S-TRANSMITTER']/text()")
    params["gdWakeupSymbolRxIdle"] = _int_text(
        cluster, "./*[local-name()='WAKE-UP']/*[local-name()='WAKE-UP-SYMBOL-RX-IDLE']/text()"
    )
    params["gdWakeupSymbolRxLow"] = _int_text(
        cluster, "./*[local-name()='WAKE-UP']/*[local-name()='WAKE-UP-SYMBOL-RX-LOW']/text()"
    )
    params["gdWakeupSymbolRxWindow"] = _int_text(
        cluster, "./*[local-name()='WAKE-UP']/*[local-name()='WAKE-UP-SYMBOL-RX-WINDOW']/text()"
    )
    params["gdWakeupSymbolTxIdle"] = _int_text(
        cluster, "./*[local-name()='WAKE-UP']/*[local-name()='WAKE-UP-SYMBOL-TX-IDLE']/text()"
    )
    params["gdWakeupSymbolTxLow"] = _int_text(
        cluster, "./*[local-name()='WAKE-UP']/*[local-name()='WAKE-UP-SYMBOL-TX-LOW']/text()"
    )
    params["gdCASRxLowMax"] = _int_text(cluster, "./*[local-name()='CAS-RX-LOW-MAX']/text()")

    controller = _find_first(root, "CONTROLLER")
    if controller is not None:
        params["pClusterDriftDamping"] = _int_text(
            controller, "./*[local-name()='CLUSTER-DRIFT-DAMPING']/text()"
        )
        params["pDecodingCorrection"] = _int_text(
            controller, "./*[local-name()='DECODING-CORRECTION']/text()"
        )
        params["pDelayCompensationA"] = _int_text(
            controller, "./*[local-name()='DELAY-COMPENSATION-A']/text()"
        )
        params["pDelayCompensationB"] = _int_text(
            controller, "./*[local-name()='DELAY-COMPENSATION-B']/text()"
        )
        params["pExternOffsetCorrection"] = _int_text(
            controller, "./*[local-name()='EXTERN-OFFSET-CORRECTION']/text()"
        )
        params["pExternRateCorrection"] = _int_text(
            controller, "./*[local-name()='EXTERN-RATE-CORRECTION']/text()"
        )
        params["pLatestTx"] = _int_text(controller, "./*[local-name()='LATEST-TX']/text()")
        params["pMacroInitialOffsetA"] = _int_text(
            controller, "./*[local-name()='MACRO-INITIAL-OFFSET-A']/text()"
        )
        params["pMacroInitialOffsetB"] = _int_text(
            controller, "./*[local-name()='MACRO-INITIAL-OFFSET-B']/text()"
        )
        params["pMicroInitialOffsetA"] = _int_text(
            controller, "./*[local-name()='MICRO-INITIAL-OFFSET-A']/text()"
        )
        params["pMicroInitialOffsetB"] = _int_text(
            controller, "./*[local-name()='MICRO-INITIAL-OFFSET-B']/text()"
        )
        params["pMicroPerCycle"] = _int_text(controller, "./*[local-name()='MICRO-PER-CYCLE']/text()")
        params["pMicroPerMacroNom"] = 0  # Not used by XL API
        params["pOffsetCorrectionOut"] = _int_text(
            controller, "./*[local-name()='OFFSET-CORRECTION-OUT']/text()"
        )
        params["pRateCorrectionOut"] = _int_text(
            controller, "./*[local-name()='RATE-CORRECTION-OUT']/text()"
        )
        params["pSamplesPerMicrotick"] = _int_text(
            controller, "./*[local-name()='SAMPLES-PER-MICROTICK']/text()"
        )
        params["pSingleSlotEnabled"] = _bool_text(
            controller, "./*[local-name()='SINGLE-SLOT-ENABLED']/text()"
        )
        params["pWakeupPattern"] = _int_text(controller, "./*[local-name()='WAKE-UP-PATTERN']/text()")
        params["pAllowHaltDueToClock"] = _bool_text(
            controller, "./*[local-name()='ALLOW-HALT-DUE-TO-CLOCK']/text()"
        )
        params["pAllowPassiveToActive"] = _int_text(
            controller, "./*[local-name()='ALLOW-PASSIVE-TO-ACTIVE']/text()"
        )
        params["pdAcceptedStartupRange"] = _int_text(
            controller, "./*[local-name()='ACCEPTED-STARTUP-RANGE']/text()"
        )
        params["pdListenTimeout"] = _int_text(controller, "./*[local-name()='LISTEN-TIMEOUT']/text()")
        params["pdMaxDrift"] = _int_text(controller, "./*[local-name()='MAX-DRIFT']/text()")
        params["pdMicrotick"] = 0  # Not used by XL API
        params["gChannels"] = 0  # Not used by XL API
        params["vExternOffsetControl"] = 0  # Not used by XL API
        params["vExternRateControl"] = 0  # Not used by XL API
        params["pKeySlotUsedForStartup"] = 0  # Not used by XL API
        params["pKeySlotUsedForSync"] = 0  # Not used by XL API
        params["pMaxPayloadLengthDynamic"] = _int_text(
            controller, "./*[local-name()='MAX-DYNAMIC-PAYLOAD-LENGTH']/text()"
        )

    params["pChannels"] = _infer_channel_mask(root)

    name = _short_name(cluster) or "flexray_cluster"
    return FlexRayClusterParams(cluster_name=name, params=params)


def load_flexray_schedule(
    fibex_path: Path, cluster_name: Optional[str] = None
) -> Dict[str, FlexRaySchedule]:
    """Return mapping frame_name -> schedule extracted from FIBEX (FlexRay)."""

    root = _load_xml_root(fibex_path)
    clusters = _find_flexray_clusters(root)
    if not clusters:
        return {}
    cluster = _select_cluster(clusters, cluster_name)

    channels_by_id = _channels_by_id(root)
    frame_nodes = _frames_by_id(root)
    channel_ids = _channel_refs(cluster)

    schedule_by_frame: Dict[str, FlexRaySchedule] = {}
    for channel_id in channel_ids:
        channel = channels_by_id.get(channel_id)
        if channel is None:
            continue
        channel_name = _channel_name(channel)
        for ft in _find_all(channel, "FRAME-TRIGGERING"):
            slot_id = _int_text(ft, ".//*[local-name()='SLOT-ID']/text()")
            base_cycle = _int_text(ft, ".//*[local-name()='BASE-CYCLE']/text()")
            repetition = _int_text(ft, ".//*[local-name()='CYCLE-REPETITION']/text()")
            frame_ref = _attr_text(ft, ".//*[local-name()='FRAME-REF']", "ID-REF")
            if not frame_ref:
                continue
            frame_node = frame_nodes.get(frame_ref)
            if frame_node is None:
                continue
            frame_name = _short_name(frame_node) or frame_ref
            payload_len = _int_text(frame_node, "./*[local-name()='BYTE-LENGTH']/text()")
            schedule_by_frame[frame_name] = FlexRaySchedule(
                slot_id=slot_id,
                base_cycle=base_cycle,
                cycle_repetition=repetition,
                channel=channel_name,
                payload_length=payload_len,
            )
    return schedule_by_frame


def load_flexray_canmatrix(
    fibex_path: Path, cluster_name: Optional[str] = None
) -> Dict[str, canmatrix.CanMatrix]:
    """Build CanMatrix databases from FlexRay FIBEX clusters."""

    root = _load_xml_root(fibex_path)
    clusters = _find_flexray_clusters(root)
    if not clusters:
        return {}

    result: Dict[str, canmatrix.CanMatrix] = {}
    frames_by_id = _frames_by_id(root)
    signals_by_id = _signals_by_id(root)
    codings_by_id = _codings_by_id(root)
    channels_by_id = _channels_by_id(root)

    for cluster in clusters:
        if cluster_name and (_short_name(cluster) or "") != cluster_name:
            continue
        db = canmatrix.CanMatrix()
        schedule = load_flexray_schedule(fibex_path, _short_name(cluster))
        for channel_id in _channel_refs(cluster):
            channel = channels_by_id.get(channel_id)
            if channel is None:
                continue
            for ft in _find_all(channel, "FRAME-TRIGGERING"):
                frame_ref = _attr_text(ft, ".//*[local-name()='FRAME-REF']", "ID-REF")
                if not frame_ref:
                    continue
                frame_node = frames_by_id.get(frame_ref)
                if frame_node is None:
                    continue
                frame_name = _short_name(frame_node) or frame_ref
                if frame_name in db.frames_dict_name:
                    continue
                frame_size = _int_text(frame_node, "./*[local-name()='BYTE-LENGTH']/text()")
                frame = canmatrix.Frame(name=frame_name, size=frame_size)
                if frame_name in schedule:
                    sched = schedule[frame_name]
                    frame.header_id = int(sched.slot_id)
                    frame.attributes["FlexRay_BaseCycle"] = sched.base_cycle
                    frame.attributes["FlexRay_CycleRepetition"] = sched.cycle_repetition
                    frame.attributes["FlexRay_Channel"] = sched.channel
                _attach_signals(frame, frame_node, signals_by_id, codings_by_id)
                db.add_frame(frame)
        result[_short_name(cluster) or "flexray_cluster"] = db
    return result


def _attach_signals(
    frame: canmatrix.Frame,
    frame_node: lxml.etree._Element,
    signals_by_id: Dict[str, Tuple[str, str]],
    codings_by_id: Dict[str, Dict[str, object]],
) -> None:
    for sig_inst in _find_all(frame_node, "SIGNAL-INSTANCE"):
        bit_pos = _int_text(sig_inst, "./*[local-name()='BIT-POSITION']/text()")
        is_high_low = _bool_text(
            sig_inst, "./*[local-name()='IS-HIGH-LOW-BYTE-ORDER']/text()", default=False
        )
        sig_ref = _attr_text(sig_inst, ".//*[local-name()='SIGNAL-REF']", "ID-REF")
        if not sig_ref:
            continue
        sig_meta = signals_by_id.get(sig_ref)
        if sig_meta is None:
            continue
        sig_name, coding_id = sig_meta
        coding = codings_by_id.get(coding_id, {})
        bit_length = int(coding.get("bit_length", 1))
        is_signed = bool(coding.get("is_signed", False))
        sig = canmatrix.Signal(name=sig_name, is_signed=is_signed)
        sig.size = bit_length
        sig.is_little_endian = not is_high_low
        if sig.is_little_endian:
            sig.start_bit = int(bit_pos)
        else:
            sig.set_startbit(int(bit_pos), bitNumbering=1)
        if "factor" in coding:
            sig.factor = coding["factor"]
        if "offset" in coding:
            sig.offset = coding["offset"]
        if "min" in coding:
            sig.min = coding["min"]
        if "max" in coding:
            sig.max = coding["max"]
        if "unit" in coding:
            sig.unit = coding["unit"]
        frame.add_signal(sig)


def _signals_by_id(root: lxml.etree._Element) -> Dict[str, Tuple[str, str]]:
    mapping: Dict[str, Tuple[str, str]] = {}
    for sig in _find_all(root, "SIGNAL"):
        sig_id = sig.get("ID")
        if not sig_id:
            continue
        name = _short_name(sig) or sig_id
        coding_ref = _attr_text(sig, ".//*[local-name()='CODING-REF']", "ID-REF") or ""
        mapping[sig_id] = (name, coding_ref)
    return mapping


def _codings_by_id(root: lxml.etree._Element) -> Dict[str, Dict[str, object]]:
    codings: Dict[str, Dict[str, object]] = {}
    for coding in _find_all(root, "CODING"):
        coding_id = coding.get("ID")
        if not coding_id:
            continue
        coded_type = _find_first(coding, "CODED-TYPE")
        bit_length = _int_text(coding, ".//*[local-name()='BIT-LENGTH']/text()")
        base_type = ""
        if coded_type is not None:
            for key, value in coded_type.attrib.items():
                if key.upper().endswith("BASE-DATA-TYPE"):
                    base_type = value
        is_signed = "INT" in base_type and "UINT" not in base_type
        factor, offset = _compu_method_linear(coding)
        min_val, max_val = _phys_limits(coding)
        unit = _unit_text(coding)
        codings[coding_id] = {
            "bit_length": bit_length,
            "is_signed": is_signed,
            "factor": factor,
            "offset": offset,
            "min": min_val,
            "max": max_val,
            "unit": unit,
        }
    return codings


def _compu_method_linear(node: lxml.etree._Element) -> Tuple[Decimal, Decimal]:
    category = _text(node, ".//*[local-name()='COMPU-METHOD']/*[local-name()='CATEGORY']/text()")
    if category and category.upper() == "LINEAR":
        numerator = node.xpath(".//*[local-name()='COMPU-NUMERATOR']/*[local-name()='V']/text()")
        denominator = node.xpath(".//*[local-name()='COMPU-DENOMINATOR']/*[local-name()='V']/text()")
        if len(numerator) >= 2 and denominator:
            denom = Decimal(denominator[0])
            offset = Decimal(numerator[0]) / denom
            factor = Decimal(numerator[1]) / denom
            return factor, offset
    return Decimal(1), Decimal(0)


def _phys_limits(node: lxml.etree._Element) -> Tuple[Optional[Decimal], Optional[Decimal]]:
    lower = _text(node, ".//*[local-name()='LOWER-LIMIT']/text()")
    upper = _text(node, ".//*[local-name()='UPPER-LIMIT']/text()")
    try:
        min_val = Decimal(lower) if lower is not None else None
    except Exception:
        min_val = None
    try:
        max_val = Decimal(upper) if upper is not None else None
    except Exception:
        max_val = None
    return min_val, max_val


def _unit_text(node: lxml.etree._Element) -> Optional[str]:
    return _text(node, ".//*[local-name()='UNIT']/*[local-name()='DISPLAY-NAME']/text()")


def _frames_by_id(root: lxml.etree._Element) -> Dict[str, lxml.etree._Element]:
    return {frame.get("ID"): frame for frame in _find_all(root, "FRAME") if frame.get("ID")}


def _channels_by_id(root: lxml.etree._Element) -> Dict[str, lxml.etree._Element]:
    return {channel.get("ID"): channel for channel in _find_all(root, "CHANNEL") if channel.get("ID")}


def _channel_refs(cluster: lxml.etree._Element) -> Iterable[str]:
    for ref in cluster.xpath(".//*[local-name()='CHANNEL-REF']/@ID-REF"):
        yield ref


def _channel_name(channel: lxml.etree._Element) -> str:
    name = _text(channel, ".//*[local-name()='FLEXRAY-CHANNEL-NAME']/text()")
    if name:
        return name.strip().upper()
    short = _short_name(channel)
    if short and "B" in short.upper():
        return "B"
    return "A"


def _infer_channel_mask(root: lxml.etree._Element) -> int:
    mask = 0
    for channel in _find_all(root, "CHANNEL"):
        name = _channel_name(channel)
        if name == "A":
            mask |= 1
        elif name == "B":
            mask |= 2
        elif name in ("AB", "BA"):
            mask |= 3
    return mask


def _find_flexray_clusters(root: lxml.etree._Element) -> list[lxml.etree._Element]:
    clusters = []
    for cluster in _find_all(root, "CLUSTER"):
        proto = _text(cluster, ".//*[local-name()='PROTOCOL']/text()")
        if proto and "FLEXRAY" in proto.upper():
            clusters.append(cluster)
    return clusters


def _select_cluster(clusters: list[lxml.etree._Element], name: Optional[str]) -> lxml.etree._Element:
    if name:
        for cluster in clusters:
            if (_short_name(cluster) or "").strip() == name:
                return cluster
    return clusters[0]


def _short_name(node: lxml.etree._Element) -> Optional[str]:
    return _text(node, "./*[local-name()='SHORT-NAME']/text()")


def _find_all(node: lxml.etree._Element, tag: str) -> list[lxml.etree._Element]:
    return node.xpath(f".//*[local-name()='{tag}']")


def _find_first(node: lxml.etree._Element, tag: str) -> Optional[lxml.etree._Element]:
    nodes = _find_all(node, tag)
    return nodes[0] if nodes else None


def _text(node: lxml.etree._Element, xpath: str) -> Optional[str]:
    res = node.xpath(xpath)
    if not res:
        return None
    if isinstance(res[0], lxml.etree._Element):
        return res[0].text
    return str(res[0])


def _attr_text(node: lxml.etree._Element, xpath: str, attr: str) -> Optional[str]:
    elems = node.xpath(xpath)
    if not elems:
        return None
    elem = elems[0]
    for key, value in elem.attrib.items():
        if key.upper().endswith(attr):
            return value
    return None


def _int_text(node: lxml.etree._Element, xpath: str, default: int = 0) -> int:
    value = _text(node, xpath)
    if value is None:
        return default
    try:
        return int(float(value))
    except Exception:
        return default


def _bool_text(node: lxml.etree._Element, xpath: str, default: bool = False) -> int:
    value = _text(node, xpath)
    if value is None:
        return 1 if default else 0
    value = value.strip().lower()
    if value in ("true", "1", "yes"):
        return 1
    if value in ("false", "0", "no"):
        return 0
    return 1 if default else 0


def _load_xml_root(path: Path) -> lxml.etree._Element:
    parser = lxml.etree.XMLParser(resolve_entities=False, remove_comments=True)
    return lxml.etree.parse(str(path), parser).getroot()
