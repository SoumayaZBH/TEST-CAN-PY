# Depannage - Tests reels Vector + calculateur cible

## 1. Erreur observee
Pendant:

```powershell
python run_tests.py --config config/testbench.yaml --debug
```

vous obtenez:

- `vector_xl.XlApiError: xlGetApplConfig failed with status 255: XL_ERROR`

## 2. Signification technique
Dans ce projet, le backend `FlexRayInjectorBackend` appelle `xlGetApplConfig` quand:

- `use_appl_config: true` (cas actuel dans `config/testbench.yaml`)
- avec:
  - `app_name: eco_mode_testVN7610`
  - `app_channel: 0`

Si `xlGetApplConfig` retourne `XL_ERROR`, cela veut dire que le mapping Vector application -> canal hardware FlexRay n'est pas resolu sur ce PC.

Important:
- cette erreur apparait **avant** tout dialogue utile avec le calculateur.
- le probleme est d'abord cote configuration Vector/PC, pas cote logique ECO.

## 3. Causes les plus frequentes (cas reel)
1. L'application `eco_mode_testVN7610` n'existe pas dans Vector Hardware Config.
2. `app_channel=0` n'est pas mappe au canal FlexRay VN7610 attendu.
3. La carte VN7610 n'est pas detectee (USB/driver/power).
4. XL Driver non installe, ou mismatch 32/64 bits de la DLL.
5. Le canal est reserve par un autre outil (CANoe/CANalyzer ouvert en mode exclusif).
6. Profil Hardware Config different de celui utilise au moment du test.

## 4. Procedure de remediation (recommandee)
### Etape A - Verifier la pile PC/driver
1. Verifier que la carte VN7610 est visible dans Vector Hardware Config.
2. Verifier que XL Driver est installe et fonctionnel.
3. Fermer CANoe/CANalyzer (ou liberer le canal FlexRay).

### Etape B - Corriger le mapping application
1. Ouvrir Vector Hardware Config.
2. Creer/selectionner l'application:
   - `eco_mode_testVN7610`
3. Mapper:
   - `Application Channel = 0`
   - vers le canal FlexRay physique VN7610 cible.
4. Sauvegarder/appliquer la configuration.
5. Redemarrer l'outil si necessaire.

### Etape C - Verifier la config projet
Dans `config/testbench.yaml`, confirmer:

```yaml
buses:
  flexray_pt:
    app_name: eco_mode_testVN7610
    app_channel: 0
    use_appl_config: true
```

Relancer ensuite:

```powershell
python run_tests.py --config config/testbench.yaml --debug
```

## 5. Contournement temporaire (si appl config indisponible)
Si vous ne pouvez pas utiliser `xlGetApplConfig` immediatement:

1. passer `use_appl_config: false`
2. renseigner `channel_index` avec l'index global du canal FlexRay

Exemple:

```yaml
buses:
  flexray_pt:
    use_appl_config: false
    channel_index: 0
```

Note:
- c'est utile pour debloquer rapidement, mais en production banc, le mapping application reste recommande.

## 6. Verification cote calculateur (apres correction XL)
Une fois l'erreur `xlGetApplConfig` corrigee, verifier ensuite:

1. Le reseau FlexRay est actif (clock/sync presents).
2. Le calculateur cible est alimente et present sur le reseau.
3. Le FIBEX charge correspond au reseau reel:
   - cluster
   - slot/base-cycle/repetition
   - noms frame/signal
4. Les conditions ECO sont bien envoyees et les trames de reponse reviennent.

## 7. Symptomes et actions rapides
- Symptom: `xlGetApplConfig ... XL_ERROR`
  - Action: corriger mapping Vector Hardware Config (`app_name/app_channel`).
- Symptom: `xlOpenPort did not grant init permission`
  - Action: canal non accessible/exclusif -> fermer autre outil, verifier permissions.
- Symptom: tests en timeout apres ouverture port OK
  - Action: verifier trafic FlexRay reel, FIBEX, et reponse calculateur.

## 8. Distinction avec le mode emulator
- `config/testbench.yaml` = mode reel VN7610.
- `config/testbench_emulator.yaml` = mode sans carte (UDP + GUI emulator).

Ne pas utiliser `testbench.yaml` si la carte ou le mapping Vector n'est pas pret.
