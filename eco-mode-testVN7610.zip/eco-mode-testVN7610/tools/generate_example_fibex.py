"""Generer un FIBEX d exemple compatible avec la suite de tests.

Ce script construit un FIBEX CAN minimal contenant toutes les trames/signaux
utilises par eco_mode-tests2. Le fichier est destine a la simulation locale
et a l emulateur, pas a un usage production.
"""

from __future__ import annotations

from pathlib import Path
import xml.etree.ElementTree as ET

import canmatrix.canmatrix as cm
import canmatrix.formats as formats


def _add_frame(db: cm.CanMatrix, name: str, frame_id: int, signals: list[tuple[str, int, int]]) -> None:
    """Ajouter une trame simple 8 octets avec signaux non signes little-endian."""

    frame = cm.Frame(
        name=name,
        arbitration_id=cm.ArbitrationId(frame_id, False),
        size=8,
        signals=[],
    )
    for sig_name, start_bit, size in signals:
        signal = cm.Signal(
            name=sig_name,
            start_bit=start_bit,
            size=size,
            is_little_endian=True,
            is_signed=False,
        )
        frame.signals.append(signal)
    db.add_frame(frame)


def build_example_db() -> cm.CanMatrix:
    """Creer le CanMatrix d exemple avec toutes les trames/signaux requis."""

    db = cm.CanMatrix()
    _add_frame(db, "HMI_Request", 0x100, [("DriveModeRequest", 0, 8), ("DriveModeReqValid", 8, 8)])
    _add_frame(db, "Body_Status", 0x110, [("IgnitionState", 0, 8), ("BrakePedal", 8, 8)])
    _add_frame(db, "Chassis_Status", 0x120, [("VehicleSpeed", 0, 16), ("AccelPedalPos", 16, 8)])
    _add_frame(db, "Powertrain_Status", 0x130, [("HVReady", 0, 8)])
    _add_frame(db, "VCU_Status", 0x140, [("VCUFaultLevel", 0, 8), ("DegradedMode", 8, 8)])
    _add_frame(db, "Trans_Status", 0x150, [("GearPosition", 0, 8)])
    _add_frame(db, "Battery_Status", 0x160, [("BatterySOC", 0, 8), ("BatteryTemp", 8, 8)])
    _add_frame(
        db,
        "VCU_Mode",
        0x170,
        [
            ("DrivingModeActive", 0, 8),
            ("DriveModeAccepted", 8, 8),
            ("DriveModeRejectReason", 16, 8),
        ],
    )
    return db


def main() -> int:
    """Ecrire le FIBEX d exemple dans le dossier fibex."""

    root = Path(__file__).resolve().parents[1]
    output = root / "fibex" / "example_vehicle.xml"
    output.parent.mkdir(parents=True, exist_ok=True)
    db = build_example_db()
    with output.open("wb") as handle:
        formats.dump(db, handle, export_type="fibex")
    _inject_emulator_ecu(output)
    print(f"FIBEX genere: {output}")
    return 0


def _inject_emulator_ecu(path: Path) -> None:
    """Injecter une ECU minimale requise par le loader FIBEX canmatrix."""

    ns_fx = "http://www.asam.net/xml/fbx"
    ns_ho = "http://www.asam.net/xml"
    ET.register_namespace("fx", ns_fx)
    ET.register_namespace("ho", ns_ho)

    tree = ET.parse(path)
    root = tree.getroot()
    elements = root.find(f"{{{ns_fx}}}ELEMENTS")
    if elements is None:
        raise ValueError("FIBEX sans section ELEMENTS")

    ecus = elements.find(f"{{{ns_fx}}}ECUS")
    if ecus is None:
        ecus = ET.SubElement(elements, f"{{{ns_fx}}}ECUS")
    else:
        ecus.clear()

    ecu = ET.SubElement(ecus, f"{{{ns_fx}}}ECU", {"ID": "ECU_EMULATOR"})
    short_name = ET.SubElement(ecu, f"{{{ns_ho}}}SHORT-NAME")
    short_name.text = "ECU_EMULATOR"
    desc = ET.SubElement(ecu, f"{{{ns_ho}}}DESC")
    desc.text = "Emulator ECU"
    output_ports = ET.SubElement(ecu, f"{{{ns_fx}}}OUTPUT-PORTS")
    input_ports = ET.SubElement(ecu, f"{{{ns_fx}}}INPUT-PORTS")

    frame_triggers = root.findall(f".//{{{ns_fx}}}FRAME-TRIGGERING")
    for ft in frame_triggers:
        ft_id = ft.attrib.get("ID")
        if not ft_id:
            continue
        output_port = ET.SubElement(output_ports, f"{{{ns_fx}}}OUTPUT-PORT")
        ET.SubElement(output_port, f"{{{ns_fx}}}FRAME-TRIGGERING-REF", {"ID-REF": ft_id})
        pdu_id = "PDU_" + ft_id.replace("FT_", "")
        ET.SubElement(output_port, f"{{{ns_fx}}}PDU-TRIGGERING-REF", {"ID-REF": pdu_id})

    signal_instances = root.findall(f".//{{{ns_fx}}}SIGNAL-INSTANCE")
    for sig_inst in signal_instances:
        sig_id = sig_inst.attrib.get("ID")
        if not sig_id:
            continue
        input_port = ET.SubElement(input_ports, f"{{{ns_fx}}}INPUT-PORT")
        ET.SubElement(input_port, f"{{{ns_fx}}}SIGNAL-INSTANCE-REF", {"ID-REF": sig_id})

    tree.write(path, encoding="utf-8", xml_declaration=False)


if __name__ == "__main__":
    raise SystemExit(main())
