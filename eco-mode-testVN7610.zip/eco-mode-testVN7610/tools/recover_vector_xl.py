"""Recuperation best effort de la visibilite Vector XL sous Windows."""

from __future__ import annotations

import argparse
import ctypes
from pathlib import Path
from typing import Optional

import yaml
from _vector_windows_env import (
    enumerate_vector_devices,
    find_vn7610_instance_id,
    get_service_status,
    registry_key_state,
    run_command,
)

from flexray_vector_lib.vector.backend import _VectorXLLibrary, _decode_c_string, _is_flexray_channel, _unsigned_mask

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "config" / "testbench.yaml"


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Tenter une recuperation de la visibilite VN7610 cote Windows / XL Driver.",
    )
    parser.add_argument("--config", default=str(DEFAULT_CONFIG), help="Chemin du testbench YAML")
    parser.add_argument("--bus", default="flexray_pt", help="Bus a lire dans le testbench")
    parser.add_argument("--scan-devices", action="store_true", help="Executer 'pnputil /scan-devices'")
    parser.add_argument(
        "--restart-vector-service",
        action="store_true",
        help="Redemarrer le service 'Vector Hardware Service'",
    )
    parser.add_argument(
        "--restart-vn7610",
        action="store_true",
        help="Redemarrer le peripherique VN7610 trouve par pnputil",
    )
    parser.add_argument(
        "--device-instance-id",
        default=None,
        help="Instance ID explicite du peripherique a redemarrer",
    )
    return parser.parse_args()


def _is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _load_bus_cfg(config_path: Path, bus_name: str) -> dict:
    if not config_path.is_file():
        return {}
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    buses = cfg.get("buses", {})
    bus_cfg = buses.get(bus_name, {})
    return bus_cfg if isinstance(bus_cfg, dict) else {}

def _probe_vxlapi() -> dict:
    result = {
        "dll_version": None,
        "channel_count": None,
        "flexray_channels": [],
        "error": None,
    }
    library = _VectorXLLibrary(None)
    try:
        library.open_driver()
        driver_config = library.get_driver_config()
        result["dll_version"] = int(driver_config.dllVersion)
        result["channel_count"] = int(driver_config.channelCount)
        for index in range(int(driver_config.channelCount)):
            channel = driver_config.channel[index]
            if not _is_flexray_channel(channel):
                continue
            result["flexray_channels"].append(
                {
                    "channel_index": int(channel.channelIndex),
                    "name": _decode_c_string(channel.name) or "<sans-nom>",
                    "mask": _unsigned_mask(channel.channelMask),
                }
            )
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        try:
            library.close_driver()
        except Exception:
            pass
    return result


def _print_vector_devices(devices: list[dict]) -> None:
    print("Peripheriques Windows de classe 'Vector-Hardware'")
    print("-----------------------------------------------")
    if not devices:
        print("Aucun peripherique 'Vector-Hardware' detecte par pnputil.")
        print()
        return
    for device in devices:
        description = device.get("description", "-")
        status = device.get("status", "-")
        instance_id = device.get("instance_id", "-")
        print(
            f"- description={description}"
            f" status={status}"
            f" instance_id={instance_id}"
        )
    print()


def _print_windows_environment() -> None:
    print("Etat Windows / registre XL")
    print("--------------------------")

    service_status = get_service_status("vHardwareService")
    if service_status is None:
        print("- service vHardwareService: introuvable")
    else:
        print(f"- service vHardwareService: {service_status}")

    for subkey in (r"SOFTWARE\VECTOR\CANDriver 1.0", r"SOFTWARE\VECTOR\CANDriver 1.0\Drivers"):
        state = registry_key_state(subkey)
        status = "present" if bool(state["exists"]) else "absent"
        detail = "" if bool(state["exists"]) else f" ({state['error']})"
        print(f"- registre {state['path']}: {status}{detail}")
    print()


def _print_vxlapi_state(state: dict, header: str) -> None:
    print(header)
    print("-" * len(header))
    if state["error"] is not None:
        print(state["error"])
        print()
        return
    print(f"dllVersion: {state['dll_version']}")
    print(f"channelCount: {state['channel_count']}")
    if state["flexray_channels"]:
        for channel in state["flexray_channels"]:
            print(
                f"- channel_index={channel['channel_index']} "
                f"name={channel['name']} mask=0x{channel['mask']:X}"
            )
    else:
        print("Aucun canal FlexRay visible dans vxlapi.")
    print()


def _try_action(label: str, args: list[str]) -> None:
    print(f"Action: {label}")
    code, stdout, stderr = run_command(args)
    print(f"code retour: {code}")
    if stdout:
        print(stdout)
    if stderr:
        print(stderr)
    print()


def main() -> int:
    args = _parse_args()
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path
    bus_cfg = _load_bus_cfg(config_path, args.bus)

    print("Recuperation Vector XL / VN7610")
    print("-------------------------------")
    print(f"config: {config_path}")
    print(f"bus: {args.bus}")
    print(f"app_name: {bus_cfg.get('app_name', 'eco_mode_testVN7610')}")
    print(f"admin: {_is_admin()}")
    print()

    devices_before = enumerate_vector_devices()
    _print_vector_devices(devices_before)
    _print_windows_environment()
    _print_vxlapi_state(_probe_vxlapi(), "Etat vxlapi avant actions")

    target_instance_id = args.device_instance_id or find_vn7610_instance_id(devices_before)

    if args.scan_devices:
        _try_action("pnputil /scan-devices", ["pnputil", "/scan-devices"])

    if args.restart_vector_service:
        _try_action(
            "Restart-Service vHardwareService",
            [
                "powershell",
                "-NoProfile",
                "-Command",
                "Restart-Service -Name vHardwareService -Force",
            ],
        )

    if args.restart_vn7610:
        if target_instance_id is None:
            print("Action: restart VN7610")
            print("Impossible de choisir automatiquement un instance_id VN7610.")
            print("Relancez avec --device-instance-id \"<ID>\".")
            print()
        else:
            _try_action(
                f"pnputil /restart-device {target_instance_id}",
                ["pnputil", "/restart-device", target_instance_id],
            )

    devices_after = enumerate_vector_devices()
    _print_vector_devices(devices_after)
    _print_windows_environment()
    state_after = _probe_vxlapi()
    _print_vxlapi_state(state_after, "Etat vxlapi apres actions")

    if state_after["channel_count"] == 0:
        print("Conclusion")
        print("----------")
        print("- Le script ne peut pas forcer vxlapi a exposer le VN7610 si le XL Driver ne publie aucun canal.")
        print("- Le peripherique peut etre visible cote Windows tout en restant absent de vxlapi.")
        print("- Si le registre 'HKLM\\SOFTWARE\\VECTOR\\CANDriver 1.0' est absent, le XL Driver n'est pas correctement publie.")
        print("- Si vous voyez encore channelCount=0, la suite est a traiter dans Vector Hardware Config / XL Driver.")
        print("- Les actions de rescan ou restart peuvent exiger un shell lance en administrateur.")
        return 1

    print("Conclusion")
    print("----------")
    print("- Au moins un canal Vector est maintenant visible dans vxlapi.")
    print("- Relancez ensuite: python tools/diagnose_vector_xl.py --config config/testbench.yaml")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
