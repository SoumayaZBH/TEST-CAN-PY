"""Diagnostic local du XL Driver Vector pour le banc FlexRay."""

from __future__ import annotations

import argparse
import ctypes
import sys
from pathlib import Path
from typing import Iterable, Optional

import yaml
from _vector_windows_env import enumerate_vector_devices, get_service_status, registry_key_state

from flexray_vector_lib.vector.backend import (
    XL_BUS_TYPE_FLEXRAY,
    _VectorXLLibrary,
    _XLDriverConfig,
    _decode_c_string,
    _is_flexray_channel,
    _unsigned_mask,
)

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "config" / "testbench.yaml"

BUS_TYPE_LABELS = {
    0: "NONE",
    1: "CAN",
    2: "LIN",
    4: "FLEXRAY",
    8: "AFDX",
    16: "MOST",
    64: "DAIO",
    256: "J1708",
    2048: "KLINE",
    4096: "ETHERNET",
    8192: "A429",
}

BUS_CAPABILITY_LABELS = (
    (1, "CAN"),
    (2, "LIN"),
    (4, "FLEXRAY"),
    (16, "MOST"),
    (64, "DAIO"),
    (256, "J1708"),
    (2048, "KLINE"),
    (4096, "ETHERNET"),
    (8192, "A429"),
)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Lister les canaux vus par vxlapi et suggerer la configuration testbench.",
    )
    parser.add_argument(
        "--config",
        default=str(DEFAULT_CONFIG),
        help="Chemin vers config/testbench.yaml",
    )
    parser.add_argument(
        "--bus",
        default="flexray_pt",
        help="Nom du bus a lire dans testbench.yaml",
    )
    parser.add_argument(
        "--app-name",
        default=None,
        help="Nom d'application Vector a sonder. Ecrase la valeur YAML si renseigne.",
    )
    parser.add_argument(
        "--channel-index",
        type=int,
        default=None,
        help="Channel index a comparer. Ecrase la valeur YAML si renseigne.",
    )
    parser.add_argument(
        "--app-channel",
        type=int,
        default=None,
        help="App channel Vector a comparer. Ecrase la valeur YAML si renseigne.",
    )
    parser.add_argument(
        "--max-app-channel",
        type=int,
        default=8,
        help="Nombre de canaux applicatifs a sonder pour xlGetApplConfig.",
    )
    return parser.parse_args()


def _load_testbench(config_path: Path, bus_name: str) -> dict:
    if not config_path.is_file():
        return {}
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    buses = cfg.get("buses", {})
    bus_cfg = buses.get(bus_name, {})
    return bus_cfg if isinstance(bus_cfg, dict) else {}


def _bus_type_label(value: int) -> str:
    return BUS_TYPE_LABELS.get(value, f"0x{value:X}")


def _bus_capability_labels(value: int) -> str:
    labels = [label for mask, label in BUS_CAPABILITY_LABELS if value & mask]
    return ",".join(labels) if labels else "-"


def _iter_channels(driver_config: _XLDriverConfig) -> Iterable:
    for index in range(int(driver_config.channelCount)):
        yield driver_config.channel[index]


def _probe_app_channel(library: _VectorXLLibrary, app_name: str, app_channel: int) -> dict:
    hw_type = ctypes.c_uint(0)
    hw_index = ctypes.c_uint(0)
    hw_channel = ctypes.c_uint(0)
    status = library.xlGetApplConfig(
        app_name.encode("ascii"),
        ctypes.c_uint(app_channel),
        ctypes.byref(hw_type),
        ctypes.byref(hw_index),
        ctypes.byref(hw_channel),
        XL_BUS_TYPE_FLEXRAY,
    )
    result = {
        "app_channel": app_channel,
        "status": int(status),
        "status_text": library._get_error_text(int(status)),
        "hw_type": int(hw_type.value),
        "hw_index": int(hw_index.value),
        "hw_channel": int(hw_channel.value),
        "channel_index": None,
        "access_mask": None,
    }
    if int(status) == 0:
        result["channel_index"] = int(
            library.xlGetChannelIndex(
                int(hw_type.value),
                int(hw_index.value),
                int(hw_channel.value),
            )
        )
        result["access_mask"] = _unsigned_mask(
            library.xlGetChannelMask(
                int(hw_type.value),
                int(hw_index.value),
                int(hw_channel.value),
            )
        )
    return result


def _print_header(title: str) -> None:
    print(title)
    print("-" * len(title))


def _print_driver_channels(driver_config: _XLDriverConfig) -> list:
    channels = list(_iter_channels(driver_config))
    _print_header("Canaux vus par vxlapi")
    if not channels:
        print("Aucun canal remonte par xlGetDriverConfig.")
        print()
        return []

    for channel in channels:
        name = _decode_c_string(channel.name) or "<sans-nom>"
        transceiver = _decode_c_string(channel.transceiverName) or "-"
        print(
            f"- global_index={int(channel.channelIndex)} name={name} "
            f"mask=0x{_unsigned_mask(channel.channelMask):X} "
            f"hw=({int(channel.hwType)},{int(channel.hwIndex)},{int(channel.hwChannel)}) "
            f"bus_caps={_bus_capability_labels(int(channel.channelBusCapabilities))} "
            f"connected_bus={_bus_type_label(int(channel.connectedBusType))} "
            f"is_on_bus={int(channel.isOnBus)} "
            f"interface_version={int(channel.interfaceVersion)} "
            f"transceiver={transceiver}"
        )
    print()
    return channels


def _print_flexray_channels(channels: Iterable) -> list:
    flexray_channels = [channel for channel in channels if _is_flexray_channel(channel)]
    _print_header("Canaux FlexRay detectes")
    if not flexray_channels:
        print("Aucun canal compatible FlexRay n'est visible par le XL Driver.")
        print()
        return []

    for channel in flexray_channels:
        print(
            f"- channel_index={int(channel.channelIndex)} "
            f"name={_decode_c_string(channel.name) or '<sans-nom>'} "
            f"access_mask=0x{_unsigned_mask(channel.channelMask):X}"
        )
    print()
    return flexray_channels


def _print_application_mappings(library: _VectorXLLibrary, app_name: str, max_app_channel: int) -> list[dict]:
    _print_header(f"Mappings applicatifs pour app_name='{app_name}'")
    mappings: list[dict] = []
    for app_channel in range(max_app_channel):
        result = _probe_app_channel(library, app_name, app_channel)
        mappings.append(result)
        if result["status"] == 0:
            print(
                f"- app_channel={app_channel}: OK "
                f"global_index={result['channel_index']} "
                f"mask=0x{int(result['access_mask']):X} "
                f"hw=({result['hw_type']},{result['hw_index']},{result['hw_channel']})"
            )
        else:
            print(f"- app_channel={app_channel}: {result['status_text']}")
    print()
    return mappings


def _print_windows_environment() -> dict[str, object]:
    _print_header("Environnement Windows / Vector")

    devices = enumerate_vector_devices()
    service_status = get_service_status("vHardwareService")
    driver_registry = registry_key_state(r"SOFTWARE\VECTOR\CANDriver 1.0")
    drivers_registry = registry_key_state(r"SOFTWARE\VECTOR\CANDriver 1.0\Drivers")

    if not devices:
        print("- Aucun peripherique 'Vector-Hardware' visible cote Windows.")
    else:
        print(f"- Peripheriques Windows 'Vector-Hardware': {len(devices)}")
        for device in devices:
            description = device.get("description") or "<sans-description>"
            status = device.get("status") or "-"
            instance_id = device.get("instance_id") or "-"
            print(f"  {description} status={status} instance_id={instance_id}")

    if service_status is None:
        print("- Service vHardwareService: introuvable")
    else:
        print(f"- Service vHardwareService: {service_status}")

    for state in (driver_registry, drivers_registry):
        status = "present" if bool(state["exists"]) else "absent"
        detail = "" if bool(state["exists"]) else f" ({state['error']})"
        print(f"- Registre {state['path']}: {status}{detail}")

    print()
    return {
        "devices": devices,
        "service_status": service_status,
        "driver_registry": driver_registry,
        "drivers_registry": drivers_registry,
    }


def _recommend_channel_index(current_channel_index: Optional[int], flexray_channels: list) -> Optional[int]:
    if current_channel_index is not None:
        for channel in flexray_channels:
            if int(channel.channelIndex) == current_channel_index:
                return current_channel_index
    if len(flexray_channels) == 1:
        return int(flexray_channels[0].channelIndex)
    return None


def _recommend_app_channel(current_app_channel: Optional[int], mappings: list[dict]) -> Optional[int]:
    successful = [mapping for mapping in mappings if mapping["status"] == 0]
    if current_app_channel is not None:
        for mapping in successful:
            if mapping["app_channel"] == current_app_channel:
                return current_app_channel
    if len(successful) == 1:
        return int(successful[0]["app_channel"])
    return None


def _print_recommendation(
    current_channel_index: Optional[int],
    current_app_channel: Optional[int],
    flexray_channels: list,
    mappings: list[dict],
    windows_state: dict[str, object],
) -> None:
    _print_header("Recommandation")
    recommended_channel_index = _recommend_channel_index(current_channel_index, flexray_channels)
    recommended_app_channel = _recommend_app_channel(current_app_channel, mappings)

    if not flexray_channels:
        print("- Ne changez pas `channel_index` a l'aveugle: aucun canal FlexRay n'est visible.")
        print("- Ne renseignez pas `app_channel`: aucun mapping applicatif FlexRay valide n'a ete trouve.")
        print("- Corrigez d'abord la detection du VN7610 dans Vector Hardware Config / XL Driver.")
        print("- Le fait que le boitier ne soit pas connecte au reseau FlexRay n'explique pas `channelCount=0`.")
        print("  L'absence de reseau peut empecher `is_on_bus=1`, mais pas la visibilite du canal dans le driver.")
        devices = windows_state.get("devices") or []
        driver_registry = windows_state.get("driver_registry") or {}
        drivers_registry = windows_state.get("drivers_registry") or {}
        service_status = windows_state.get("service_status")

        if devices:
            print("- Windows voit au moins un peripherique Vector-Hardware: le blocage n'est donc pas uniquement USB/PnP.")
        else:
            print("- Windows ne voit aucun peripherique Vector-Hardware: verifiez le cable USB, l'alimentation et le driver PnP.")

        if not bool(driver_registry.get("exists")) or not bool(drivers_registry.get("exists")):
            print("- Indice fort: la configuration registre du XL Driver est absente.")
            print("  Reparez ou reinstallez 'Vector XL Driver Library' avant de retenter un mapping applicatif.")

        if service_status is None:
            print("- Le service 'vHardwareService' est introuvable: l'installation Vector semble incomplete.")
        elif str(service_status).upper() != "RUNNING":
            print(f"- Le service 'vHardwareService' n'est pas RUNNING ({service_status}): redemarrez-le puis relancez ce diagnostic.")

        print()
        return

    if recommended_channel_index is not None:
        print(f"- Valeur conseillee pour `channel_index`: {recommended_channel_index}")
    else:
        print("- Plusieurs canaux FlexRay sont visibles: choisissez le bon `channel_index` dans la liste ci-dessus.")

    if recommended_app_channel is not None:
        print(f"- Valeur conseillee pour `app_channel`: {recommended_app_channel}")
    else:
        successful = [mapping for mapping in mappings if mapping["status"] == 0]
        if successful:
            print("- Plusieurs mappings applicatifs sont valides: choisissez le bon `app_channel` dans la liste ci-dessus.")
        else:
            print("- Laissez `app_channel` non defini tant que vous n'avez pas cree de mapping applicatif Vector.")

    print()
    print("Exemple de configuration YAML:")
    print("buses:")
    print("  flexray_pt:")
    if recommended_channel_index is not None:
        print(f"    channel_index: {recommended_channel_index}")
    else:
        print("    channel_index: <a choisir>")
    print("    app_name: eco_mode_testVN7610")
    if recommended_app_channel is not None:
        print(f"    app_channel: {recommended_app_channel}")
    else:
        print("    # app_channel: <optionnel>")
    print()


def main() -> int:
    args = _parse_args()
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path

    bus_cfg = _load_testbench(config_path, args.bus)
    app_name = args.app_name or str(bus_cfg.get("app_name", "eco_mode_testVN7610"))
    channel_index = args.channel_index
    if channel_index is None and bus_cfg.get("channel_index") is not None:
        channel_index = int(bus_cfg["channel_index"])
    app_channel = args.app_channel
    if app_channel is None and bus_cfg.get("app_channel") is not None:
        app_channel = int(bus_cfg["app_channel"])

    _print_header("Diagnostic Vector XL / FlexRay")
    print(f"config: {config_path}")
    print(f"bus: {args.bus}")
    print(f"app_name: {app_name}")
    print(f"channel_index configure: {channel_index}")
    print(f"app_channel configure: {app_channel}")
    print()

    library = _VectorXLLibrary(None)
    try:
        library.open_driver()
        driver_config = library.get_driver_config()
        print(f"dllVersion: {int(driver_config.dllVersion)}")
        print(f"channelCount: {int(driver_config.channelCount)}")
        print()

        channels = _print_driver_channels(driver_config)
        flexray_channels = _print_flexray_channels(channels)
        mappings = _print_application_mappings(library, app_name, args.max_app_channel)
        windows_state = _print_windows_environment()
        _print_recommendation(channel_index, app_channel, flexray_channels, mappings, windows_state)
        return 0
    finally:
        try:
            library.close_driver()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
