"""Sondes Windows partagees pour les utilitaires de diagnostic Vector XL."""

from __future__ import annotations

import locale
import re
import subprocess
import unicodedata
import winreg
from typing import Optional


def run_command(args: list[str]) -> tuple[int, str, str]:
    encoding = locale.getpreferredencoding(False) or "cp1252"
    proc = subprocess.run(
        args,
        capture_output=True,
        text=True,
        encoding=encoding,
        errors="replace",
    )
    return proc.returncode, proc.stdout.strip(), proc.stderr.strip()


def _normalize_token(value: str) -> str:
    ascii_value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    return " ".join(re.sub(r"[^a-z0-9]+", " ", ascii_value.lower()).split())


def _extract_device_field(device: dict[str, str], *aliases: str) -> str:
    normalized_aliases = {_normalize_token(alias) for alias in aliases}
    for key, value in device.items():
        if _normalize_token(key) in normalized_aliases:
            return value
    return ""


def enumerate_vector_devices() -> list[dict[str, str]]:
    code, stdout, _ = run_command(["pnputil", "/enum-devices", "/connected", "/class", "Vector-Hardware"])
    if code != 0 or not stdout:
        return []

    raw_devices: list[dict[str, str]] = []
    current: dict[str, str] = {}
    for raw_line in stdout.splitlines():
        line = raw_line.strip()
        if not line:
            if current:
                raw_devices.append(current)
                current = {}
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        current[key.strip()] = value.strip()
    if current:
        raw_devices.append(current)

    devices: list[dict[str, str]] = []
    for device in raw_devices:
        devices.append(
            {
                "description": _extract_device_field(device, "Description de l'appareil", "Device Description"),
                "status": _extract_device_field(device, "Statut", "Status"),
                "instance_id": _extract_device_field(device, "ID d'instance", "Instance ID"),
            }
        )
    return devices


def find_vn7610_instance_id(devices: list[dict[str, str]]) -> Optional[str]:
    for device in devices:
        if "VN7610" in device.get("description", "").upper():
            return device.get("instance_id") or None
    if len(devices) == 1:
        return devices[0].get("instance_id") or None
    return None


def get_service_status(service_name: str) -> Optional[str]:
    code, stdout, _ = run_command(["sc", "query", service_name])
    if code != 0:
        return None

    match = re.search(r"STATE\s*:\s*\d+\s+([A-Z_]+)", stdout)
    if match is None:
        return None
    return match.group(1)


def registry_key_state(subkey: str) -> dict[str, object]:
    path = rf"HKLM\{subkey}"
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, subkey):
            return {"path": path, "exists": True, "error": None}
    except OSError as exc:
        return {"path": path, "exists": False, "error": str(exc)}
