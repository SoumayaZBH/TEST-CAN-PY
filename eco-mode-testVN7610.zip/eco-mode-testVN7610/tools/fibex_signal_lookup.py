"""Lookup a signal in a FIBEX file and show protocol/frame mapping.

Usage:
  python tools/fibex_signal_lookup.py --signal DriveModeRequest
  python tools/fibex_signal_lookup.py --fibex path/to/file.xml --signal BrakePedal
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import argparse
import sys
import xml.etree.ElementTree as ET


NS = {
    "fx": "http://www.asam.net/xml/fbx",
    "ho": "http://www.asam.net/xml",
}


@dataclass
class SignalInstance:
    sig_inst_id: str | None
    signal_ref_id: str | None
    pdu_id: str | None
    bit_position: str | None
    byte_order: str | None


@dataclass
class PduInstance:
    pdu_inst_id: str | None
    pdu_ref_id: str | None
    frame_id: str | None
    bit_position: str | None


@dataclass
class FrameTriggering:
    ft_id: str | None
    frame_ref_id: str | None
    channel_id: str | None
    identifier_value: str | None


def _text(elem: ET.Element | None, path: str) -> str | None:
    if elem is None:
        return None
    found = elem.find(path, NS)
    if found is None or found.text is None:
        return None
    return found.text.strip()


def _format_identifier(val: str | None) -> str:
    if not val:
        return "N/A"
    try:
        number = int(val)
    except ValueError:
        return val
    return f"{number} / 0x{number:X}"


def parse_fibex(path: Path) -> dict[str, object]:
    tree = ET.parse(path)
    root = tree.getroot()

    signals: dict[str, dict[str, str | None]] = {}
    for sig in root.findall(".//fx:SIGNAL", NS):
        sig_id = sig.get("ID")
        if not sig_id:
            continue
        signals[sig_id] = {
            "short_name": _text(sig, "ho:SHORT-NAME"),
            "default": _text(sig, "fx:DEFAULT-VALUE"),
        }

    pdus: dict[str, dict[str, str | None]] = {}
    signal_instances: list[SignalInstance] = []
    for pdu in root.findall(".//fx:PDU", NS):
        pdu_id = pdu.get("ID")
        if not pdu_id:
            continue
        pdus[pdu_id] = {
            "short_name": _text(pdu, "ho:SHORT-NAME"),
            "byte_length": _text(pdu, "fx:BYTE-LENGTH"),
        }
        for sig_inst in pdu.findall(".//fx:SIGNAL-INSTANCE", NS):
            sig_ref = sig_inst.find("fx:SIGNAL-REF", NS)
            signal_instances.append(
                SignalInstance(
                    sig_inst_id=sig_inst.get("ID"),
                    signal_ref_id=sig_ref.get("ID-REF") if sig_ref is not None else None,
                    pdu_id=pdu_id,
                    bit_position=_text(sig_inst, "fx:BIT-POSITION"),
                    byte_order=_text(sig_inst, "fx:IS-HIGH-LOW-BYTE-ORDER"),
                )
            )

    frames: dict[str, dict[str, str | None]] = {}
    pdu_instances: list[PduInstance] = []
    for frame in root.findall(".//fx:FRAME", NS):
        frame_id = frame.get("ID")
        if not frame_id:
            continue
        frames[frame_id] = {
            "short_name": _text(frame, "ho:SHORT-NAME"),
            "byte_length": _text(frame, "fx:BYTE-LENGTH"),
        }
        for pdu_inst in frame.findall(".//fx:PDU-INSTANCE", NS):
            pdu_ref = pdu_inst.find("fx:PDU-REF", NS)
            pdu_instances.append(
                PduInstance(
                    pdu_inst_id=pdu_inst.get("ID"),
                    pdu_ref_id=pdu_ref.get("ID-REF") if pdu_ref is not None else None,
                    frame_id=frame_id,
                    bit_position=_text(pdu_inst, "fx:BIT-POSITION"),
                )
            )

    channels: dict[str, dict[str, str | None]] = {}
    frame_triggerings: list[FrameTriggering] = []
    for channel in root.findall(".//fx:CHANNEL", NS):
        channel_id = channel.get("ID")
        if not channel_id:
            continue
        channels[channel_id] = {"short_name": _text(channel, "ho:SHORT-NAME")}
        for ft in channel.findall(".//fx:FRAME-TRIGGERING", NS):
            frame_ref = ft.find("fx:FRAME-REF", NS)
            frame_triggerings.append(
                FrameTriggering(
                    ft_id=ft.get("ID"),
                    frame_ref_id=frame_ref.get("ID-REF") if frame_ref is not None else None,
                    channel_id=channel_id,
                    identifier_value=_text(ft, ".//fx:IDENTIFIER-VALUE"),
                )
            )

    clusters: dict[str, dict[str, str | None]] = {}
    channel_to_cluster: dict[str, str] = {}
    for cluster in root.findall(".//fx:CLUSTER", NS):
        cluster_id = cluster.get("ID")
        if not cluster_id:
            continue
        clusters[cluster_id] = {
            "short_name": _text(cluster, "ho:SHORT-NAME"),
            "protocol": _text(cluster, "fx:PROTOCOL"),
            "speed": _text(cluster, "fx:SPEED"),
        }
        for cref in cluster.findall(".//fx:CHANNEL-REF", NS):
            channel_id = cref.get("ID-REF")
            if channel_id:
                channel_to_cluster[channel_id] = cluster_id

    return {
        "signals": signals,
        "pdus": pdus,
        "signal_instances": signal_instances,
        "frames": frames,
        "pdu_instances": pdu_instances,
        "channels": channels,
        "frame_triggerings": frame_triggerings,
        "clusters": clusters,
        "channel_to_cluster": channel_to_cluster,
    }


def _match_name(name: str | None, query: str, contains: bool, ignore_case: bool) -> bool:
    if name is None:
        return False
    if ignore_case:
        name_cmp = name.lower()
        query_cmp = query.lower()
    else:
        name_cmp = name
        query_cmp = query
    return query_cmp in name_cmp if contains else name_cmp == query_cmp


def find_signal_ids(
    signals: dict[str, dict[str, str | None]],
    query: str,
    contains: bool,
    ignore_case: bool,
) -> list[str]:
    matches = [
        sig_id
        for sig_id, sig in signals.items()
        if _match_name(sig.get("short_name"), query, contains, ignore_case)
    ]
    if matches:
        return matches
    # Fallback: exact ID match
    if query in signals:
        return [query]
    return []


def main() -> int:
    parser = argparse.ArgumentParser(description="Lookup a signal in a FIBEX file.")
    parser.add_argument("--signal", required=True, help="Signal short name to search for.")
    parser.add_argument(
        "--fibex",
        default=None,
        help="Path to the FIBEX XML file (default: fibex/example_vehicle.xml).",
    )
    parser.add_argument("--contains", action="store_true", help="Substring match on signal name.")
    parser.add_argument("--ignore-case", action="store_true", help="Case-insensitive match.")
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    fibex_path = Path(args.fibex) if args.fibex else root / "fibex" / "example_vehicle.xml"
    if not fibex_path.exists():
        print(f"FIBEX file not found: {fibex_path}", file=sys.stderr)
        return 2

    data = parse_fibex(fibex_path)
    signals = data["signals"]
    signal_instances = data["signal_instances"]
    pdus = data["pdus"]
    pdu_instances = data["pdu_instances"]
    frames = data["frames"]
    frame_triggerings = data["frame_triggerings"]
    channels = data["channels"]
    clusters = data["clusters"]
    channel_to_cluster = data["channel_to_cluster"]

    signal_ids = find_signal_ids(signals, args.signal, args.contains, args.ignore_case)
    if not signal_ids:
        print(f"No signal found for: {args.signal}")
        return 1

    for sig_id in signal_ids:
        sig = signals[sig_id]
        sig_name = sig.get("short_name") or "UNKNOWN"
        print(f"Signal: {sig_name} (ID: {sig_id})")

        sig_insts = [si for si in signal_instances if si.signal_ref_id == sig_id]
        if not sig_insts:
            print("  No SIGNAL-INSTANCE referencing this signal.")
            continue

        match_index = 1
        for sig_inst in sig_insts:
            pdu_id = sig_inst.pdu_id
            pdu = pdus.get(pdu_id or "", {})
            pdu_inst_list = [pi for pi in pdu_instances if pi.pdu_ref_id == pdu_id]
            if not pdu_inst_list:
                print(f"  Match {match_index}:")
                print(f"    PDU      : {pdu.get('short_name') or pdu_id or 'UNKNOWN'}")
                print("    Frame    : N/A (no PDU-INSTANCE found)")
                match_index += 1
                continue

            for pdu_inst in pdu_inst_list:
                frame_id = pdu_inst.frame_id
                frame = frames.get(frame_id or "", {})
                ft_list = [ft for ft in frame_triggerings if ft.frame_ref_id == frame_id]
                if not ft_list:
                    print(f"  Match {match_index}:")
                    print(f"    Protocol : UNKNOWN (no FRAME-TRIGGERING found)")
                    print(f"    Frame    : {frame.get('short_name') or frame_id or 'UNKNOWN'}")
                    print(f"    PDU      : {pdu.get('short_name') or pdu_id or 'UNKNOWN'}")
                    match_index += 1
                    continue

                for ft in ft_list:
                    channel_id = ft.channel_id
                    channel = channels.get(channel_id or "", {})
                    cluster_id = channel_to_cluster.get(channel_id or "")
                    cluster = clusters.get(cluster_id or "", {})
                    protocol = cluster.get("protocol") or "UNKNOWN"
                    cluster_name = cluster.get("short_name") or cluster_id or "UNKNOWN"
                    speed = cluster.get("speed")
                    speed_text = f", Speed: {speed} kbps" if speed else ""

                    print(f"  Match {match_index}:")
                    print(f"    Protocol : {protocol}")
                    print(f"    Cluster  : {cluster_name} (ID: {cluster_id or 'UNKNOWN'}{speed_text})")
                    print(f"    Channel  : {channel.get('short_name') or channel_id or 'UNKNOWN'}")
                    print(
                        "    Frame    : "
                        f"{frame.get('short_name') or frame_id or 'UNKNOWN'} "
                        f"(ID: {frame_id or 'UNKNOWN'}, Byte-Length: {frame.get('byte_length') or 'N/A'})"
                    )
                    print(
                        "    FrameTrig: "
                        f"{ft.ft_id or 'UNKNOWN'} "
                        f"(Identifier: {_format_identifier(ft.identifier_value)})"
                    )
                    print(
                        "    PDU      : "
                        f"{pdu.get('short_name') or pdu_id or 'UNKNOWN'} "
                        f"(ID: {pdu_id or 'UNKNOWN'}, Byte-Length: {pdu.get('byte_length') or 'N/A'})"
                    )
                    print(
                        "    SigInst  : "
                        f"{sig_inst.sig_inst_id or 'UNKNOWN'} "
                        f"(Bit-Pos: {sig_inst.bit_position or 'N/A'}, Byte-Order: {sig_inst.byte_order or 'N/A'})"
                    )
                    match_index += 1

        print("")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
