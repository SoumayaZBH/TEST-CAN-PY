"""Mapper automatiquement une application Vector vers un canal FlexRay visible."""

from __future__ import annotations

import argparse
import ctypes
from pathlib import Path
from typing import Optional

import yaml

from flexray_vector_lib.vector.backend import (
    XL_BUS_TYPE_FLEXRAY,
    _VectorXLLibrary,
    _decode_c_string,
    _is_flexray_channel,
    _unsigned_mask,
)

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "config" / "testbench.yaml"


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Configurer xlSetApplConfig pour une application Vector FlexRay.",
    )
    parser.add_argument("--config", default=str(DEFAULT_CONFIG), help="Chemin vers config/testbench.yaml")
    parser.add_argument("--bus", default="flexray_pt", help="Bus cible dans le testbench")
    parser.add_argument("--app-name", default=None, help="Nom d'application Vector a mapper")
    parser.add_argument("--app-channel", type=int, default=None, help="Canal applicatif a ecrire")
    parser.add_argument("--channel-index", type=int, default=None, help="Canal global visible a utiliser")
    parser.add_argument("--hw-type", type=int, default=None, help="Hardware type explicite")
    parser.add_argument("--hw-index", type=int, default=None, help="Hardware index explicite")
    parser.add_argument("--hw-channel", type=int, default=None, help="Hardware channel explicite")
    parser.add_argument("--apply", action="store_true", help="Appliquer xlSetApplConfig")
    return parser.parse_args()


def _load_bus_cfg(config_path: Path, bus_name: str) -> dict:
    if not config_path.is_file():
        return {}
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    buses = cfg.get("buses", {})
    bus_cfg = buses.get(bus_name, {})
    return bus_cfg if isinstance(bus_cfg, dict) else {}


def _bind_set_appl_config(library: _VectorXLLibrary) -> None:
    if hasattr(library, "xlSetApplConfig"):
        return
    library.xlSetApplConfig = library._dll.xlSetApplConfig
    library.xlSetApplConfig.argtypes = [
        ctypes.c_char_p,
        ctypes.c_uint,
        ctypes.c_uint,
        ctypes.c_uint,
        ctypes.c_uint,
        ctypes.c_uint,
    ]
    library.xlSetApplConfig.restype = ctypes.c_short


def _probe_app_channel(library: _VectorXLLibrary, app_name: str, app_channel: int) -> dict:
    hw_type = ctypes.c_uint(0)
    hw_index = ctypes.c_uint(0)
    hw_channel = ctypes.c_uint(0)
    status = int(
        library.xlGetApplConfig(
            app_name.encode("ascii"),
            ctypes.c_uint(app_channel),
            ctypes.byref(hw_type),
            ctypes.byref(hw_index),
            ctypes.byref(hw_channel),
            XL_BUS_TYPE_FLEXRAY,
        )
    )
    result = {
        "status": status,
        "status_text": library._get_error_text(status),
        "hw_type": int(hw_type.value),
        "hw_index": int(hw_index.value),
        "hw_channel": int(hw_channel.value),
        "channel_index": None,
        "access_mask": None,
    }
    if status == 0:
        result["channel_index"] = int(
            library.xlGetChannelIndex(
                int(hw_type.value),
                int(hw_index.value),
                int(hw_channel.value),
            )
        )
        result["access_mask"] = _unsigned_mask(
            library.xlGetChannelMask(
                int(hw_type.value),
                int(hw_index.value),
                int(hw_channel.value),
            )
        )
    return result


def _collect_flexray_channels(library: _VectorXLLibrary) -> list[dict]:
    driver_config = library.get_driver_config()
    channels: list[dict] = []
    for index in range(int(driver_config.channelCount)):
        channel = driver_config.channel[index]
        if not _is_flexray_channel(channel):
            continue
        channels.append(
            {
                "channel_index": int(channel.channelIndex),
                "name": _decode_c_string(channel.name) or "<sans-nom>",
                "access_mask": _unsigned_mask(channel.channelMask),
                "hw_type": int(channel.hwType),
                "hw_index": int(channel.hwIndex),
                "hw_channel": int(channel.hwChannel),
            }
        )
    return channels


def _select_target_channel(args: argparse.Namespace, bus_cfg: dict, channels: list[dict]) -> Optional[dict]:
    if args.hw_type is not None and args.hw_index is not None and args.hw_channel is not None:
        return {
            "channel_index": None,
            "name": "manuel",
            "access_mask": None,
            "hw_type": int(args.hw_type),
            "hw_index": int(args.hw_index),
            "hw_channel": int(args.hw_channel),
        }

    requested_channel_index = args.channel_index
    if requested_channel_index is None and bus_cfg.get("channel_index") is not None:
        requested_channel_index = int(bus_cfg["channel_index"])

    if requested_channel_index is not None:
        for channel in channels:
            if channel["channel_index"] == requested_channel_index:
                return channel
        return None

    if len(channels) == 1:
        return channels[0]
    return None


def _print_channels(channels: list[dict]) -> None:
    print("Canaux FlexRay visibles")
    print("-----------------------")
    if not channels:
        print("Aucun canal FlexRay visible dans vxlapi.")
        print()
        return
    for channel in channels:
        print(
            f"- channel_index={channel['channel_index']} "
            f"name={channel['name']} "
            f"mask=0x{int(channel['access_mask']):X} "
            f"hw=({channel['hw_type']},{channel['hw_index']},{channel['hw_channel']})"
        )
    print()


def _print_mapping(label: str, mapping: dict, app_channel: int) -> None:
    print(label)
    print("-" * len(label))
    if mapping["status"] != 0:
        print(f"app_channel={app_channel}: {mapping['status_text']}")
    else:
        print(
            f"app_channel={app_channel}: OK "
            f"global_index={mapping['channel_index']} "
            f"mask=0x{int(mapping['access_mask']):X} "
            f"hw=({mapping['hw_type']},{mapping['hw_index']},{mapping['hw_channel']})"
        )
    print()


def main() -> int:
    args = _parse_args()
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path
    bus_cfg = _load_bus_cfg(config_path, args.bus)
    app_name = args.app_name or str(bus_cfg.get("app_name", "eco_mode_testVN7610"))
    app_channel = args.app_channel
    if app_channel is None:
        app_channel = int(bus_cfg.get("app_channel", 0))

    print("Mapping applicatif Vector / FlexRay")
    print("-----------------------------------")
    print(f"config: {config_path}")
    print(f"bus: {args.bus}")
    print(f"app_name: {app_name}")
    print(f"app_channel cible: {app_channel}")
    print(f"mode: {'apply' if args.apply else 'dry-run'}")
    print()

    library = _VectorXLLibrary(None)
    try:
        library.open_driver()
        _bind_set_appl_config(library)

        channels = _collect_flexray_channels(library)
        _print_channels(channels)

        before = _probe_app_channel(library, app_name, app_channel)
        _print_mapping("Mapping avant", before, app_channel)

        target = _select_target_channel(args, bus_cfg, channels)
        if target is None:
            if not channels:
                print("Aucune action possible: aucun canal FlexRay visible dans vxlapi.")
            else:
                print("Impossible de choisir automatiquement un canal cible.")
                print("Relancez avec --channel-index <index> ou --hw-type/--hw-index/--hw-channel.")
            return 1

        print("Cible de mapping")
        print("----------------")
        print(
            f"hw=({target['hw_type']},{target['hw_index']},{target['hw_channel']}) "
            f"channel_index={target['channel_index']} "
            f"name={target['name']}"
        )
        print()

        if not args.apply:
            print("Aucune modification appliquee.")
            print("Pour ecrire le mapping:")
            print(
                f"python tools/map_vector_app.py --config {config_path} --bus {args.bus} "
                f"--app-name {app_name} --app-channel {app_channel} --apply"
            )
            if target["channel_index"] is not None:
                print(f"  --channel-index {target['channel_index']}")
            print()
            return 0

        status = int(
            library.xlSetApplConfig(
                app_name.encode("ascii"),
                ctypes.c_uint(app_channel),
                ctypes.c_uint(int(target["hw_type"])),
                ctypes.c_uint(int(target["hw_index"])),
                ctypes.c_uint(int(target["hw_channel"])),
                ctypes.c_uint(XL_BUS_TYPE_FLEXRAY),
            )
        )
        if status != 0:
            raise RuntimeError(f"xlSetApplConfig a echoue: {library._get_error_text(status)}")

        after = _probe_app_channel(library, app_name, app_channel)
        _print_mapping("Mapping apres", after, app_channel)

        print("Recommendation YAML")
        print("-------------------")
        print("buses:")
        print(f"  {args.bus}:")
        if after["channel_index"] is not None:
            print(f"    channel_index: {after['channel_index']}")
        elif target["channel_index"] is not None:
            print(f"    channel_index: {target['channel_index']}")
        else:
            print("    channel_index: <a confirmer>")
        print(f"    app_name: {app_name}")
        print(f"    app_channel: {app_channel}")
        print()
        return 0
    finally:
        try:
            library.close_driver()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
